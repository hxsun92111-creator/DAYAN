# پروژه تعمیر یخچال اصفهان

این پروژه یک سیستم مدیریت خدمات تعمیر یخچال با **ASP.NET Core 8 + Razor Pages + Clean Architecture + EF Core + MySQL** است.

## چهار لایه پروژه

### 1. Domain
قلب سیستم است. Entity و Enumهای کسب‌وکار اینجا هستند.
این لایه نباید چیزی از MySQL، EF Core، Razor Pages یا HTTP بداند.

### 2. Application
منطق کسب‌وکار اینجاست: DTO، Interface و Service.
مثلاً محاسبه کمیسیون ۲۵٪، کنترل موجودی کیف پول و انتخاب تکنسین‌ها.

### 3. Infrastructure
جزئیات فنی اینجاست: EF Core، MySQL، DbContext، Repository، Identity و درگاه پرداخت.

### 4. Web
لایه ارائه است: Razor Pages، Program.cs، UI، Authentication و Authorization.

## تکنولوژی‌ها

- C#
- ASP.NET Core 8
- Razor Pages
- Entity Framework Core 8
- MySQL
- Pomelo.EntityFrameworkCore.MySql
- ASP.NET Core Identity
- Bootstrap RTL
- Bootstrap Icons
- Vazirmatn
- Leaflet (برای مرحله نقشه)

## Packageهای NuGet

نسخه‌ها داخل فایل‌های csproj تنظیم شده‌اند و لازم نیست همه را دستی اضافه کنید. Visual Studio با Restore آن‌ها را دریافت می‌کند.

مهم‌ترین‌ها:

- Microsoft.AspNetCore.Identity.UI
- Microsoft.AspNetCore.Identity.EntityFrameworkCore
- Microsoft.EntityFrameworkCore
- Microsoft.EntityFrameworkCore.Design
- Pomelo.EntityFrameworkCore.MySql

## اجرای پروژه در Visual Studio 2026

### پیش‌نیازها

در Visual Studio Installer این Workload را نصب کنید:

**ASP.NET and web development**

همچنین باید .NET 8 SDK/Runtime روی سیستم موجود باشد.

### MySQL

MySQL Server را اجرا کنید و مشخصات اتصال را در:

`src/Web/appsettings.json`

قرار دهید.

نمونه:

```text
server=localhost;port=3306;database=refrigerator_repair_esfahan;user=root;password=YOUR_PASSWORD;CharSet=utf8mb4;
```

اگر Database وجود نداشته باشد، برنامه Development با `EnsureCreated` آن را ایجاد می‌کند؛ اگر کاربر MySQL اجازه ساخت Database نداشته باشد، ابتدا Database را دستی بسازید.

### Visual Studio

1. فایل `RefrigeratorRepair.sln` را باز کنید.
2. روی Solution راست‌کلیک و **Restore NuGet Packages** را اجرا کنید.
3. از منوی **Build > Rebuild Solution** استفاده کنید.
4. پروژه `RefrigeratorRepair.Web` را Startup Project کنید.
5. با F5 اجرا کنید.

### حساب مدیر Development

نام کاربری:

`admin`

رمز:

`Admin@12345`

این رمز فقط Development است و قبل از Production باید تغییر کند.

## نکته مهم درباره پرداخت

`FakePaymentGateway` فقط برای تست محلی است. پرداخت واقعی هنوز باید با Provider رسمی، Redirect، Callback و Verify پیاده‌سازی شود.

## نکته مهم درباره Migration

برای نمونه اولیه `EnsureCreated` استفاده شده است. قبل از Production بهتر است Migrationهای EF Core ساخته و مدیریت شوند.

// این Provider فقط برای Development است.
// Provider واقعی باید همین IPaymentGateway را پیاده‌سازی کند و Verify رسمی درگاه را انجام دهد.

using RefrigeratorRepair.Application.Interfaces;
namespace RefrigeratorRepair.Infrastructure.Payments;
// این پیاده‌سازی فقط برای اجرای محلی است؛ درگاه واقعی باید با Provider رسمی جایگزین شود.
public sealed class FakePaymentGateway:IPaymentGateway { public Task<PaymentStartResult> StartAsync(decimal amount,string callbackUrl,CancellationToken ct=default){var authority=Guid.NewGuid().ToString("N"); return Task.FromResult(new PaymentStartResult(true,authority,$"/Technician/Wallet/MockPay?authority={authority}",null));} public Task<PaymentVerifyResult> VerifyAsync(string authority,decimal amount,CancellationToken ct=default)=>Task.FromResult(new PaymentVerifyResult(true,$"MOCK-{authority[..10]}",null)); }

// SeedData داده‌های اولیه Development را می‌سازد: Roleها و کاربر Admin.
// این فایل بخشی از Infrastructure است چون مستقیماً با Identity و DbContext کار می‌کند.

using Microsoft.AspNetCore.Identity; using Microsoft.EntityFrameworkCore; using RefrigeratorRepair.Infrastructure.Data;
namespace RefrigeratorRepair.Infrastructure.Identity;
public static class SeedData
{
 public static async Task InitializeAsync(IServiceProvider services){using var scope=services.CreateScope(); var db=scope.ServiceProvider.GetRequiredService<ApplicationDbContext>(); await db.Database.EnsureCreatedAsync(); var roles=scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>(); foreach(var role in new[]{"Admin","Technician"}) if(!await roles.RoleExistsAsync(role)) await roles.CreateAsync(new IdentityRole(role)); var users=scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>(); var admin=await users.FindByNameAsync("admin"); if(admin is null){admin=new IdentityUser{UserName="admin",Email="admin@localhost",EmailConfirmed=true}; var r=await users.CreateAsync(admin,"Admin@12345"); if(r.Succeeded) await users.AddToRoleAsync(admin,"Admin");} }
}

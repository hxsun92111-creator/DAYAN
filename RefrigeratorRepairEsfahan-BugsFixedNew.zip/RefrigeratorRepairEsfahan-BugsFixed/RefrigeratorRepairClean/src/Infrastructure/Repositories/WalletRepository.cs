using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Infrastructure.Repositories;

// ============================================================================
// WalletRepository
// ----------------------------------------------------------------------------
// این کلاس Implementation قرارداد IWalletRepository است.
// فقط با دیتابیس و Entityها کار می‌کند و Business Rule اصلی کیف پول در
// WalletService قرار دارد.
// ============================================================================
public sealed class WalletRepository(ApplicationDbContext db)
    : IWalletRepository
{
    public Task<Technician?> GetTechnicianAsync(
        int technicianId,
        CancellationToken ct = default)
    {
        return db.Technicians
            .SingleOrDefaultAsync(
                x => x.Id == technicianId,
                ct);
    }

    public void AddTransaction(
        WalletTransaction transaction)
    {
        db.WalletTransactions.Add(transaction);
    }

    public void AddPaymentTransaction(
        PaymentTransaction transaction)
    {
        db.PaymentTransactions.Add(transaction);
    }

    public Task<PaymentTransaction?> GetPaymentTransactionByAuthorityAsync(
        string authority,
        CancellationToken ct = default)
    {
        return db.PaymentTransactions
            .SingleOrDefaultAsync(
                x => x.Authority == authority,
                ct);
    }
}

// ============================================================================
// UnitOfWork
// ----------------------------------------------------------------------------
// UnitOfWork تغییرات چند Entity را در یک عملیات هماهنگ می‌کند.
// در عملیات مالی، اگر یکی از مراحل شکست بخورد، Transaction Rollback می‌شود.
// ============================================================================
public sealed class UnitOfWork(ApplicationDbContext db)
    : IUnitOfWork
{
    public Task<int> SaveChangesAsync(
        CancellationToken ct = default)
    {
        return db.SaveChangesAsync(ct);
    }

    public async Task ExecuteInTransactionAsync(
        Func<Task> action,
        CancellationToken ct = default)
    {
        await using var transaction =
            await db.Database.BeginTransactionAsync(ct);

        try
        {
            await action();
            await db.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);
        }
        catch
        {
            await transaction.RollbackAsync(ct);
            throw;
        }
    }
}

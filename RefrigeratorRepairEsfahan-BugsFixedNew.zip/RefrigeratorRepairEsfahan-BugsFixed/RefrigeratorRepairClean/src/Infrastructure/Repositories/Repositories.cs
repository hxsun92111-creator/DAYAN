using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Infrastructure.Repositories;

// ============================================================================
// Repository Implementations
// ----------------------------------------------------------------------------
// این فایل قراردادهای Application را با EF Core پیاده‌سازی می‌کند.
// اینجا می‌توانیم LINQ، Include، Where و سایر امکانات EF Core را استفاده کنیم.
// ============================================================================

public sealed class RepairRequestRepository(ApplicationDbContext db)
    : IRepairRequestRepository
{
    public Task AddAsync(
        RepairRequest request,
        CancellationToken ct = default)
    {
        return db.RepairRequests
            .AddAsync(request, ct)
            .AsTask();
    }

    public Task<RepairRequest?> GetAsync(
        int id,
        CancellationToken ct = default)
    {
        return db.RepairRequests
            .Include(x => x.Offers)
            .SingleOrDefaultAsync(
                x => x.Id == id,
                ct);
    }

    public Task<List<RepairRequest>> GetActiveAsync(
        CancellationToken ct = default)
    {
        return db.RepairRequests
            .Include(x => x.Customer)
            .Include(x => x.AssignedTechnician)
            .Where(x =>
                x.Status != RepairRequestStatus.Completed &&
                x.Status != RepairRequestStatus.Cancelled)
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync(ct);
    }
}

public sealed class TechnicianRepository(ApplicationDbContext db)
    : ITechnicianRepository
{
    public Task<Technician?> GetAsync(
        int id,
        CancellationToken ct = default)
    {
        return db.Technicians
            .SingleOrDefaultAsync(
                x => x.Id == id,
                ct);
    }

    public Task<List<Technician>> GetAllAsync(
        CancellationToken ct = default)
    {
        return db.Technicians
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync(ct);
    }

    public Task<List<Technician>> GetAvailableAsync(
        CancellationToken ct = default)
    {
        return db.Technicians
            .Where(x =>
                x.IsApproved &&
                x.Availability == TechnicianAvailability.Available &&
                !x.Jobs.Any(j =>
                    j.Request.Status != RepairRequestStatus.Completed &&
                    j.Request.Status != RepairRequestStatus.Cancelled))
            .OrderBy(x => x.CreatedAt)
            .ToListAsync(ct);
    }
}

public sealed class RepairJobRepository(ApplicationDbContext db)
    : IRepairJobRepository
{
    public Task<RepairJob?> GetAsync(
        int id,
        CancellationToken ct = default)
    {
        return db.RepairJobs
            .Include(x => x.Parts)
            .Include(x => x.Request)
            .Include(x => x.Technician)
            .SingleOrDefaultAsync(
                x => x.Id == id,
                ct);
    }

    public Task<List<RepairJob>> GetHistoryAsync(
        int technicianId,
        CancellationToken ct = default)
    {
        return db.RepairJobs
            .Include(x => x.Request)
            .ThenInclude(x => x.Customer)
            .Where(x => x.TechnicianId == technicianId)
            .OrderByDescending(x => x.RepairDate)
            .ToListAsync(ct);
    }
}

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Entities;

namespace RefrigeratorRepair.Infrastructure.Data;

// ============================================================================
// ApplicationDbContext
// ----------------------------------------------------------------------------
// DbContext پل ارتباطی EF Core با دیتابیس است.
// این کلاس عمداً در Infrastructure قرار دارد چون Domain و Application نباید
// وابسته به EF Core یا MySQL باشند.
// ============================================================================
public class ApplicationDbContext(
    DbContextOptions<ApplicationDbContext> options)
    : IdentityDbContext<IdentityUser>(options)
{
    public DbSet<Customer> Customers => Set<Customer>();

    public DbSet<RepairRequest> RepairRequests => Set<RepairRequest>();

    public DbSet<Technician> Technicians => Set<Technician>();

    public DbSet<RepairJob> RepairJobs => Set<RepairJob>();

    public DbSet<RepairPart> RepairParts => Set<RepairPart>();

    public DbSet<TechnicianOffer> TechnicianOffers => Set<TechnicianOffer>();

    public DbSet<TechnicianRegistration> TechnicianRegistrations =>
        Set<TechnicianRegistration>();

    public DbSet<TechnicianDocument> TechnicianDocuments =>
        Set<TechnicianDocument>();

    public DbSet<WalletTransaction> WalletTransactions =>
        Set<WalletTransaction>();

    public DbSet<PaymentTransaction> PaymentTransactions =>
        Set<PaymentTransaction>();

    public DbSet<ServiceCatalog> Services => Set<ServiceCatalog>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        // ابتدا تنظیمات جداول Identity را اجرا می‌کنیم.
        base.OnModelCreating(builder);

        // TrackingCode باید برای رهگیری مشتری یکتا باشد.
        builder.Entity<RepairRequest>()
            .HasIndex(x => x.TrackingCode)
            .IsUnique();

        // کد ملی تکنسین نباید تکراری باشد.
        builder.Entity<Technician>()
            .HasIndex(x => x.NationalId)
            .IsUnique();

        builder.Entity<TechnicianRegistration>()
            .HasIndex(x => x.NationalId);

        builder.Entity<Customer>()
            .HasIndex(x => x.PhoneNumber);

        builder.Entity<RepairRequest>()
            .HasOne(x => x.Customer)
            .WithMany(x => x.Requests)
            .HasForeignKey(x => x.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<RepairRequest>()
            .HasOne(x => x.AssignedTechnician)
            .WithMany()
            .HasForeignKey(x => x.AssignedTechnicianId)
            .OnDelete(DeleteBehavior.SetNull);

        builder.Entity<RepairJob>()
            .HasOne(x => x.Request)
            .WithOne(x => x.RepairJob)
            .HasForeignKey<RepairJob>(x => x.RepairRequestId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<RepairJob>()
            .HasOne(x => x.Technician)
            .WithMany(x => x.Jobs)
            .HasForeignKey(x => x.TechnicianId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<RepairPart>()
            .HasOne(x => x.RepairJob)
            .WithMany(x => x.Parts)
            .HasForeignKey(x => x.RepairJobId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<TechnicianOffer>()
            .HasOne(x => x.Request)
            .WithMany(x => x.Offers)
            .HasForeignKey(x => x.RepairRequestId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<TechnicianOffer>()
            .HasOne(x => x.Technician)
            .WithMany(x => x.Offers)
            .HasForeignKey(x => x.TechnicianId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<WalletTransaction>()
            .HasOne(x => x.Technician)
            .WithMany(x => x.WalletTransactions)
            .HasForeignKey(x => x.TechnicianId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<TechnicianDocument>()
            .HasOne(x => x.Registration)
            .WithMany(x => x.Documents)
            .HasForeignKey(x => x.TechnicianRegistrationId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}

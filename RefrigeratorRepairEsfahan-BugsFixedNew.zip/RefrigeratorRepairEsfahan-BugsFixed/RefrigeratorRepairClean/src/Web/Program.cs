using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Application.Services;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;
using RefrigeratorRepair.Infrastructure.Payments;
using RefrigeratorRepair.Infrastructure.Repositories;

// ============================================================================
// Program.cs
// ----------------------------------------------------------------------------
// این فایل نقطه شروع برنامه ASP.NET Core است.
//
// در این فایل سه کار اصلی انجام می‌دهیم:
// 1) سرویس‌ها را در Dependency Injection ثبت می‌کنیم.
// 2) Middlewareهای HTTP را به ترتیب صحیح فعال می‌کنیم.
// 3) برنامه را اجرا می‌کنیم.
//
// نکته مهم: Program.cs نباید Business Logic داشته باشد.
// فقط باید «اجزای برنامه را به هم وصل کند».
// ============================================================================

var builder = WebApplication.CreateBuilder(args);

// ----------------------------------------------------------------------------
// 1) اتصال به MySQL
// ----------------------------------------------------------------------------
// Connection String از appsettings.json خوانده می‌شود.
// EF Core بین کلاس‌های Domain و جدول‌های MySQL ارتباط برقرار می‌کند.
var connectionString =
    builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException(
        "Connection String با نام DefaultConnection پیدا نشد.");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    options.UseMySql(
        connectionString,
        ServerVersion.AutoDetect(connectionString));
});

// ----------------------------------------------------------------------------
// 2) ASP.NET Core Identity
// ----------------------------------------------------------------------------
// Identity مسئول Login، Password، Cookie و Role است.
//
// AddDefaultIdentity به UI پیش‌فرض Identity نیز دسترسی می‌دهد.
// Package مربوط به آن در پروژه Web اضافه شده است؛ بدون آن ممکن است
// Visual Studio متد AddDefaultIdentity را روی IServiceCollection نشناسد.
// ----------------------------------------------------------------------------
builder.Services
    .AddDefaultIdentity<IdentityUser>(options =>
    {
        // برای محیط Development تأیید ایمیل را اجباری نکرده‌ایم.
        options.SignIn.RequireConfirmedAccount = false;

        // قوانین Password حساب‌های سیستم.
        options.Password.RequiredLength = 8;
        options.Password.RequireDigit = true;
        options.Password.RequireUppercase = true;
        options.Password.RequireLowercase = true;
    })
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();

// ----------------------------------------------------------------------------
// 3) Razor Pages
// ----------------------------------------------------------------------------
// Razor Page مسئول نمایش UI و گرفتن Input کاربر است.
// Business Logic را داخل PageModel انباشته نمی‌کنیم؛ آن منطق در Application است.
builder.Services.AddRazorPages(options =>
{
    // تمام صفحات Admin فقط برای Role=Admin قابل دسترسی هستند.
    options.Conventions.AuthorizeFolder(
        "/Admin",
        "AdminOnly");

    // تمام صفحات Technician فقط برای Role=Technician قابل دسترسی هستند.
    options.Conventions.AuthorizeFolder(
        "/Technician",
        "TechnicianOnly");
});

// ----------------------------------------------------------------------------
// 4) Authorization Policy
// ----------------------------------------------------------------------------
// Policy مشخص می‌کند چه Roleای اجازه ورود به کدام قسمت را دارد.
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy(
        "AdminOnly",
        policy => policy.RequireRole("Admin"));

    options.AddPolicy(
        "TechnicianOnly",
        policy => policy.RequireRole("Technician"));
});

// ----------------------------------------------------------------------------
// 5) Dependency Injection - Repositoryها
// ----------------------------------------------------------------------------
// سمت چپ Interface است و سمت راست Implementation واقعی.
//
// مثال:
// IWalletRepository = قرارداد
// WalletRepository  = پیاده‌سازی با EF Core
//
// بنابراین WalletService فقط IWalletRepository را می‌شناسد و به MySQL وابسته نیست.
// Scoped یعنی برای هر HTTP Request یک نمونه از سرویس ساخته می‌شود.
// ----------------------------------------------------------------------------
builder.Services.AddScoped<
    IRepairRequestRepository,
    RepairRequestRepository>();

builder.Services.AddScoped<
    ITechnicianRepository,
    TechnicianRepository>();

builder.Services.AddScoped<
    IRepairJobRepository,
    RepairJobRepository>();

builder.Services.AddScoped<
    IWalletRepository,
    WalletRepository>();

builder.Services.AddScoped<
    IUnitOfWork,
    UnitOfWork>();

// ----------------------------------------------------------------------------
// 6) Dependency Injection - Application Services
// ----------------------------------------------------------------------------
builder.Services.AddScoped<
    IRepairRequestService,
    RepairRequestService>();

builder.Services.AddScoped<
    IRepairJobService,
    RepairJobService>();

builder.Services.AddScoped<
    IWalletService,
    WalletService>();

// ----------------------------------------------------------------------------
// 7) Payment Gateway
// ----------------------------------------------------------------------------
// فعلاً FakePaymentGateway برای اجرای محلی استفاده می‌شود.
// در Production باید Provider واقعی درگاه جایگزین شود.
builder.Services.AddScoped<
    IPaymentGateway,
    FakePaymentGateway>();

// ============================================================================
// ساخت Application
// ============================================================================
var app = builder.Build();

// ----------------------------------------------------------------------------
// Middlewareهای HTTP
// ----------------------------------------------------------------------------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

// Authentication باید قبل از Authorization اجرا شود.
app.UseAuthentication();
app.UseAuthorization();

// Razor Pages را به Routing متصل می‌کنیم.
app.MapRazorPages();

// داده‌های اولیه مثل Roleها و Admin توسعه‌ای ساخته می‌شوند.
await SeedData.InitializeAsync(app.Services);

// شروع دریافت Requestهای HTTP.
await app.RunAsync();

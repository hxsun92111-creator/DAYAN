using Microsoft.AspNetCore.Identity; using Microsoft.AspNetCore.Mvc.RazorPages; using Microsoft.EntityFrameworkCore; using RefrigeratorRepair.Application.Interfaces; using RefrigeratorRepair.Domain.Entities; using RefrigeratorRepair.Infrastructure.Data;
namespace RefrigeratorRepair.Web.Pages;
// سابقه فقط متعلق به تکنسین واردشده است.
public class TechnicianHistoryModel(ApplicationDbContext db,UserManager<IdentityUser> users,IRepairJobRepository jobs):PageModel { public List<RepairJob> Items{get;set;}=new(); public async Task OnGetAsync(){var u=await users.GetUserAsync(User);if(u is null)return;var t=await db.Technicians.SingleOrDefaultAsync(x=>x.UserId==u.Id);if(t is not null)Items=await jobs.GetHistoryAsync(t.Id);} }

using Microsoft.AspNetCore.Identity; using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.RazorPages; using Microsoft.EntityFrameworkCore; using RefrigeratorRepair.Domain.Entities; using RefrigeratorRepair.Infrastructure.Data;
namespace RefrigeratorRepair.Web.Pages;
// جزئیات تعمیر با بررسی مالکیت تکنسین خوانده می‌شود.
public class TechnicianHistoryDetailsModel(ApplicationDbContext db,UserManager<IdentityUser> users):PageModel { public RepairJob? Job; public async Task<IActionResult> OnGetAsync(int id){var u=await users.GetUserAsync(User);Job=await db.RepairJobs.Include(x=>x.Request).Include(x=>x.Parts).Include(x=>x.Technician).SingleOrDefaultAsync(x=>x.Id==id&&x.Technician.UserId==u!.Id);return Job is null?NotFound():Page();} }

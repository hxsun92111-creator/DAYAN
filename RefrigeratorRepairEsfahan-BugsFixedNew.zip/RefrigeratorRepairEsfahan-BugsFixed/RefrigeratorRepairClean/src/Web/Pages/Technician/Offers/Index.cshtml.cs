using Microsoft.AspNetCore.Identity; using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.RazorPages; using Microsoft.EntityFrameworkCore; using RefrigeratorRepair.Application.Interfaces; using RefrigeratorRepair.Domain.Entities; using RefrigeratorRepair.Domain.Enums; using RefrigeratorRepair.Infrastructure.Data;
namespace RefrigeratorRepair.Web.Pages;
// این صفحه پیشنهادهای فعال را می‌گیرد و با قبول یک مورد، Job ایجاد می‌کند.
public class TechnicianOffersModel(ApplicationDbContext db,UserManager<IdentityUser> users,IUnitOfWork uow):PageModel
{
    public List<TechnicianOffer> Items{get;set;}=new();

    private async Task<Technician?> Current(){var u=await users.GetUserAsync(User);return u is null?null:await db.Technicians.SingleOrDefaultAsync(x=>x.UserId==u.Id);}

    public async Task OnGetAsync(){var t=await Current();if(t is null)return;Items=await db.TechnicianOffers.Include(x=>x.Request).ThenInclude(x=>x.Customer).Where(x=>x.TechnicianId==t.Id&&x.Status==OfferStatus.Pending).OrderBy(x=>x.Request.CreatedAt).Take(3).ToListAsync();}

    public async Task<IActionResult> OnPostAsync(int offerId)
    {
        // نکته: قبلاً اینجا t به‌صورت t! (null-forgiving) استفاده می‌شد؛ اگر کاربر
        // لاگین‌کرده تکنسینی به او متصل نبود، برنامه با NullReferenceException کرش می‌کرد.
        var t = await Current();
        if (t is null)
        {
            return Unauthorized();
        }

        var offer = await db.TechnicianOffers
            .Include(x => x.Request)
            .SingleOrDefaultAsync(x => x.Id == offerId && x.TechnicianId == t.Id && x.Status == OfferStatus.Pending);

        if (offer is null)
        {
            return NotFound();
        }

        if (await db.RepairJobs.AnyAsync(x => x.TechnicianId == t.Id && !x.ReportSubmitted))
        {
            return BadRequest("ابتدا تعمیر فعال فعلی را تکمیل کنید.");
        }

        try
        {
            // قبلاً این عملیات چندمرحله‌ای (پذیرفتن پیشنهاد + ساخت Job + منقضی کردن
            // بقیه پیشنهادها) در یک Transaction نبود، پس اگر وسط راه خطا می‌داد،
            // دیتابیس نیمه‌کاره می‌ماند. حالا همه در یک Transaction اجرا می‌شود.
            await uow.ExecuteInTransactionAsync(async () =>
            {
                offer.Status = OfferStatus.Accepted;
                offer.Request.AssignedTechnicianId = t.Id;
                offer.Request.AssignedAt = DateTime.UtcNow;
                offer.Request.Status = RepairRequestStatus.Assigned;

                db.RepairJobs.Add(new RepairJob
                {
                    RepairRequestId = offer.Request.Id,
                    TechnicianId = t.Id
                });

                await db.TechnicianOffers
                    .Where(x => x.RepairRequestId == offer.Request.Id && x.Id != offer.Id && x.Status == OfferStatus.Pending)
                    .ExecuteUpdateAsync(s => s.SetProperty(x => x.Status, OfferStatus.Expired));
            });
        }
        catch (DbUpdateException)
        {
            // دو تکنسین همزمان یک درخواست را قبول کرده‌اند (RepairJob.RepairRequestId یکتاست).
            return Conflict("این درخواست همین الان توسط تکنسین دیگری پذیرفته شده است.");
        }

        return RedirectToPage();
    }
}

using Microsoft.AspNetCore.Mvc.RazorPages;
using RefrigeratorRepair.Application.Interfaces;
namespace RefrigeratorRepair.Web.Pages;
// Callback واقعی درگاه (یا دکمه شبیه‌سازی MockPay) به اینجا برمی‌گردد؛
// اینجا Authority گرفته می‌شود و از طریق WalletService به‌صورت واقعی Verify و اعمال می‌شود.
public class WalletCallbackModel(IWalletService wallet) : PageModel
{
    public bool Success { get; set; }
    public string? Error { get; set; }

    public async Task OnGetAsync(string? authority)
    {
        if (string.IsNullOrWhiteSpace(authority))
        {
            Error = "شناسه تراکنش نامعتبر است.";
            return;
        }

        var result = await wallet.ApplyTopUpAsync(authority);
        Success = result.Success;
        Error = result.Success ? null : result.Error;
    }
}

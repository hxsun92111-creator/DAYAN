using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.RazorPages; namespace RefrigeratorRepair.Web.Pages;
// MockPay برای تست محلی است و نباید در Production فعال بماند.
public class MockPayModel:PageModel { [BindProperty(SupportsGet = true)] public string? Authority { get; set; } public void OnGet(){} }

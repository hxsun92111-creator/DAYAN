using System.Security.Cryptography; using Microsoft.AspNetCore.Identity; using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.RazorPages; using Microsoft.EntityFrameworkCore; using RefrigeratorRepair.Domain.Entities; using RefrigeratorRepair.Domain.Enums; using RefrigeratorRepair.Infrastructure.Data;
namespace RefrigeratorRepair.Web.Pages;
// مدیر ثبت‌نام را تأیید می‌کند؛ با تأیید، پروفایل تکنسین و حساب Identity ساخته می‌شود.
public class AdminTechniciansModel(ApplicationDbContext db,UserManager<IdentityUser> users):PageModel
{
    public List<TechnicianRegistration> Items{get;set;}=new();

    // قبلاً همه تکنسین‌ها رمز موقت ثابت و یکسان "Temp@12345" می‌گرفتند که یک ریسک
    // امنیتی بود (هرکس این رمز را بداند به هر حساب تازه‌تأییدشده‌ای دسترسی دارد).
    // حالا رمز تصادفی است و فقط همین یک‌بار به مدیر نمایش داده می‌شود.
    [TempData] public string? GeneratedUserName { get; set; }
    [TempData] public string? GeneratedPassword { get; set; }

    public async Task OnGetAsync()=>Items=await db.TechnicianRegistrations.OrderByDescending(x=>x.CreatedAt).ToListAsync();

    public async Task<IActionResult> OnPostAsync(int id,string action)
    {
        var r=await db.TechnicianRegistrations.FindAsync(id);
        if(r is null)return NotFound();

        if(action=="reject")
        {
            r.Status=TechnicianRegistrationStatus.Rejected;
            await db.SaveChangesAsync();
            return RedirectToPage();
        }

        if(action=="approve")
        {
            r.Status=TechnicianRegistrationStatus.Approved;

            var tempPassword=GenerateTempPassword();
            var u=new IdentityUser{UserName=r.PhoneNumber,PhoneNumber=r.PhoneNumber};
            var ur=await users.CreateAsync(u,tempPassword);
            if(!ur.Succeeded)
            {
                ModelState.AddModelError("",string.Join(" ",ur.Errors.Select(e=>e.Description)));
                return await Reload();
            }

            await users.AddToRoleAsync(u,"Technician");
            db.Technicians.Add(new Technician{UserId=u.Id,FirstName=r.FirstName,LastName=r.LastName,NationalId=r.NationalId,PhoneNumber=r.PhoneNumber,Address=r.Address,ExperienceYears=r.ExperienceYears,Specialization=r.Specialization,IsApproved=true,Availability=TechnicianAvailability.Available});
            await db.SaveChangesAsync();

            GeneratedUserName=u.UserName;
            GeneratedPassword=tempPassword;
            return RedirectToPage();
        }

        return RedirectToPage();
    }

    private async Task<IActionResult> Reload(){Items=await db.TechnicianRegistrations.ToListAsync();return Page();}

    private static string GenerateTempPassword()
    {
        // باید سیاست Password در Program.cs را برآورده کند: حداقل ۸ کاراکتر،
        // شامل حرف بزرگ، حرف کوچک، رقم و یک کاراکتر غیرالفبایی‌عددی.
        const string upper="ABCDEFGHJKLMNPQRSTUVWXYZ";
        const string lower="abcdefghijkmnpqrstuvwxyz";
        const string digits="23456789";
        const string symbols="!@#$%";
        const string all=upper+lower+digits+symbols;

        Span<char> chars=stackalloc char[10];
        chars[0]=Pick(upper);
        chars[1]=Pick(lower);
        chars[2]=Pick(digits);
        chars[3]=Pick(symbols);
        for(var i=4;i<chars.Length;i++) chars[i]=Pick(all);

        for(var i=chars.Length-1;i>0;i--)
        {
            var j=RandomNumberGenerator.GetInt32(i+1);
            (chars[i],chars[j])=(chars[j],chars[i]);
        }

        return new string(chars);

        static char Pick(string source)=>source[RandomNumberGenerator.GetInt32(source.Length)];
    }
}

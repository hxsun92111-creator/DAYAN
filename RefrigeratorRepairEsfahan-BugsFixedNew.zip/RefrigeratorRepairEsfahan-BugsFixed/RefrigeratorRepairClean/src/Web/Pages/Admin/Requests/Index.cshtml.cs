using Microsoft.AspNetCore.Mvc.RazorPages; using RefrigeratorRepair.Application.Interfaces; using RefrigeratorRepair.Domain.Entities;
namespace RefrigeratorRepair.Web.Pages;
// فهرست درخواست‌های تکمیل‌نشده برای پیگیری مدیر.
public class AdminRequestsModel(IRepairRequestRepository repo):PageModel { public List<RepairRequest> Items{get;set;}=new(); public async Task OnGetAsync()=>Items=await repo.GetActiveAsync(); }

using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RefrigeratorRepair.Web.Pages;

// صفحه خطای عمومی Production؛ جزئیات Exception را به کاربر نمایش نمی‌دهد.
public class ErrorModel : PageModel
{
    public void OnGet()
    {
    }
}

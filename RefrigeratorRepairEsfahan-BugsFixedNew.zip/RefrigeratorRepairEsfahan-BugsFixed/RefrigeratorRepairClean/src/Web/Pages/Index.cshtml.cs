using Microsoft.AspNetCore.Mvc.RazorPages; namespace RefrigeratorRepair.Web.Pages;
// صفحه خانه فقط معرفی سرویس است و منطق عملیاتی ندارد.
public class IndexModel:PageModel { public void OnGet(){} }

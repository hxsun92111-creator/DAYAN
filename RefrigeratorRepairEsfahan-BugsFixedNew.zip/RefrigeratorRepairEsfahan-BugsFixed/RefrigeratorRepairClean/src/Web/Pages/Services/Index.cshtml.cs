using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.RazorPages; using RefrigeratorRepair.Application.DTOs; using RefrigeratorRepair.Application.Interfaces;
namespace RefrigeratorRepair.Web.Pages;
// این PageModel ورودی فرم را می‌گیرد و آن را به Application Service می‌سپارد.
public class ServicesModel(IRepairRequestService service):PageModel { [BindProperty] public CreateRepairRequestDto Input {get;set;}=new(); public bool Success{get;set;} public string? Ticket{get;set;} public async Task<IActionResult> OnPostAsync(){if(!ModelState.IsValid)return Page();var r=await service.CreateAsync(Input);if(!r.Success){ModelState.AddModelError("",r.Error!);return Page();}Success=true;Ticket=r.Value;return Page();} }

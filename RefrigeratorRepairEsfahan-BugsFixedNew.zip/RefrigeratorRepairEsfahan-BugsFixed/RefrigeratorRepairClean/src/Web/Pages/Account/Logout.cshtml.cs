using Microsoft.AspNetCore.Identity; using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.RazorPages;
namespace RefrigeratorRepair.Web.Pages;
// خروج امن از حساب Identity.
public class LogoutModel(SignInManager<IdentityUser> signInManager):PageModel { public async Task<IActionResult> OnPostAsync(){await signInManager.SignOutAsync();return RedirectToPage("/Index");} }

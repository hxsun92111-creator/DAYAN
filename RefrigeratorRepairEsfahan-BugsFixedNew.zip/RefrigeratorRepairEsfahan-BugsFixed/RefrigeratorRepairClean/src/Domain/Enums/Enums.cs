namespace RefrigeratorRepair.Domain.Enums;

// وضعیت چرخه عمر درخواست تعمیر.
public enum RepairRequestStatus { New, WaitingForAssignment, Assigned, TechnicianOnTheWay, InProgress, Completed, Cancelled }
// وضعیت کاری تکنسین؛ در دسترس بودن واقعی در سرویس Availability محاسبه می‌شود.
public enum TechnicianAvailability { Available, Busy, TemporarilyUnavailable, PendingApproval, Suspended }
// وضعیت بررسی ثبت‌نام تکنسین توسط مدیر.
public enum TechnicianRegistrationStatus { Pending, Approved, Rejected }
// وضعیت پیشنهاد تعمیر برای تکنسین.
public enum OfferStatus { Pending, Accepted, Declined, Expired }
// انواع تراکنش کیف پول.
public enum WalletTransactionType { TopUp, CommissionDebit, Refund, Adjustment }

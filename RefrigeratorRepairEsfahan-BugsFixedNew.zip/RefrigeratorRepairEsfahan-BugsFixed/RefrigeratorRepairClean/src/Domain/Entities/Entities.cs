using RefrigeratorRepair.Domain.Enums;

namespace RefrigeratorRepair.Domain.Entities;

// ============================================================================
// Domain Layer
// ----------------------------------------------------------------------------
// Domain قلب کسب‌وکار است. Entityها و Enumهای اصلی اینجا قرار دارند.
// این لایه نباید به MySQL، EF Core، Razor Pages یا HTTP وابسته باشد.
// ============================================================================

// مشتری که درخواست تعمیر ثبت می‌کند.
public class Customer
{
    public int Id { get; set; }

    public string FirstName { get; set; } = "";

    public string LastName { get; set; } = "";

    public string PhoneNumber { get; set; } = "";

    public ICollection<RepairRequest> Requests { get; set; } =
        new List<RepairRequest>();
}

// پروفایل عملیاتی تکنسین.
public class Technician
{
    public int Id { get; set; }

    public string? UserId { get; set; }

    public string FirstName { get; set; } = "";

    public string LastName { get; set; } = "";

    public string NationalId { get; set; } = "";

    public string PhoneNumber { get; set; } = "";

    public string Address { get; set; } = "";

    public int ExperienceYears { get; set; }

    public string Specialization { get; set; } = "تعمیر یخچال";

    public string? ProfilePhotoPath { get; set; }

    public TechnicianAvailability Availability { get; set; } =
        TechnicianAvailability.PendingApproval;

    public bool IsApproved { get; set; }

    public decimal WalletBalance { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<RepairJob> Jobs { get; set; } =
        new List<RepairJob>();

    public ICollection<TechnicianOffer> Offers { get; set; } =
        new List<TechnicianOffer>();

    public ICollection<WalletTransaction> WalletTransactions { get; set; } =
        new List<WalletTransaction>();
}

// درخواست اولیه مشتری؛ مختصات دقیق محل نیز در آن ذخیره می‌شود.
public class RepairRequest
{
    public int Id { get; set; }

    public string TrackingCode { get; set; } = "";

    public int CustomerId { get; set; }

    public Customer Customer { get; set; } = null!;

    public int? AssignedTechnicianId { get; set; }

    public Technician? AssignedTechnician { get; set; }

    public string ProblemDescription { get; set; } = "";

    public string Address { get; set; } = "";

    public decimal Latitude { get; set; }

    public decimal Longitude { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime? AssignedAt { get; set; }

    public DateTime? CompletedAt { get; set; }

    public RepairRequestStatus Status { get; set; } =
        RepairRequestStatus.New;

    public RepairJob? RepairJob { get; set; }

    public ICollection<TechnicianOffer> Offers { get; set; } =
        new List<TechnicianOffer>();
}

// پرونده اجرایی تعمیر؛ گزارش، هزینه قطعات و مبالغ مالی در اینجا نگهداری می‌شود.
public class RepairJob
{
    public int Id { get; set; }

    public int RepairRequestId { get; set; }

    public RepairRequest Request { get; set; } = null!;

    public int TechnicianId { get; set; }

    public Technician Technician { get; set; } = null!;

    public DateTime? RepairDate { get; set; }

    public string? ServiceDescription { get; set; }

    public string? TechnicianDiagnosis { get; set; }

    public decimal TravelCost { get; set; }

    public decimal LaborCost { get; set; }

    public decimal CustomerTotal { get; set; }

    public decimal PartsCost { get; set; }

    public decimal NetProfitBase { get; set; }

    public decimal CommissionAmount { get; set; }

    public bool ReportSubmitted { get; set; }

    public ICollection<RepairPart> Parts { get; set; } =
        new List<RepairPart>();
}

// هر قطعه مصرفی به صورت یک ردیف ثبت می‌شود.
public class RepairPart
{
    public int Id { get; set; }

    public int RepairJobId { get; set; }

    public RepairJob RepairJob { get; set; } = null!;

    public string PartName { get; set; } = "";

    public int Quantity { get; set; } = 1;

    public decimal UnitPrice { get; set; }

    public decimal TotalPrice => Quantity * UnitPrice;
}

// یک درخواست تعمیر ممکن است همزمان برای حداکثر سه تکنسین پیشنهاد شود.
public class TechnicianOffer
{
    public int Id { get; set; }

    public int RepairRequestId { get; set; }

    public RepairRequest Request { get; set; } = null!;

    public int TechnicianId { get; set; }

    public Technician Technician { get; set; } = null!;

    public DateTime SentAt { get; set; } = DateTime.UtcNow;

    public OfferStatus Status { get; set; } = OfferStatus.Pending;
}

// ثبت‌نام عمومی تکنسین قبل از تأیید مدیر.
public class TechnicianRegistration
{
    public int Id { get; set; }

    public string FirstName { get; set; } = "";

    public string LastName { get; set; } = "";

    public string NationalId { get; set; } = "";

    public string PhoneNumber { get; set; } = "";

    public string Address { get; set; } = "";

    public int ExperienceYears { get; set; }

    public string Specialization { get; set; } = "";

    public string? ProfilePhotoPath { get; set; }

    public TechnicianRegistrationStatus Status { get; set; } =
        TechnicianRegistrationStatus.Pending;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<TechnicianDocument> Documents { get; set; } =
        new List<TechnicianDocument>();
}

// اطلاعات فایل‌های هویتی. فایل فیزیکی نباید در wwwroot عمومی قرار بگیرد.
public class TechnicianDocument
{
    public int Id { get; set; }

    public int TechnicianRegistrationId { get; set; }

    public TechnicianRegistration Registration { get; set; } = null!;

    public string DocumentType { get; set; } = "";

    public string FilePath { get; set; } = "";
}

// دفتر حسابداری کیف پول؛ هر تغییر موجودی باید رکورد داشته باشد.
public class WalletTransaction
{
    public int Id { get; set; }

    public int TechnicianId { get; set; }

    public Technician Technician { get; set; } = null!;

    public WalletTransactionType Type { get; set; }

    public decimal Amount { get; set; }

    public decimal BalanceAfter { get; set; }

    public string Description { get; set; } = "";

    public int? RepairJobId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

// تراکنش پرداخت درگاه؛ Authority و Reference برای پیگیری پرداخت نگهداری می‌شوند.
public class PaymentTransaction
{
    public int Id { get; set; }

    public int TechnicianId { get; set; }

    public decimal Amount { get; set; }

    public string Authority { get; set; } = "";

    public string? ReferenceId { get; set; }

    public string Status { get; set; } = "Pending";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime? VerifiedAt { get; set; }
}

// خدماتی که در سایت قابل نمایش هستند.
public class ServiceCatalog
{
    public int Id { get; set; }

    public string Title { get; set; } = "";

    public string ShortDescription { get; set; } = "";

    public bool IsActive { get; set; } = true;
}

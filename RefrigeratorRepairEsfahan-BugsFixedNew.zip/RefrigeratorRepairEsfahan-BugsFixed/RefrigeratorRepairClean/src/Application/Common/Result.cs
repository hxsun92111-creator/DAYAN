// این فایل Result Pattern را تعریف می‌کند تا Serviceها به جای Exceptionهای بی‌هدف،
// نتیجه موفق/ناموفق را به شکل مشخص به لایه Web برگردانند.

namespace RefrigeratorRepair.Application.Common;
// Result برای جلوگیری از پرتاب Exception در خطاهای قابل انتظار کسب‌وکار استفاده می‌شود.
public sealed class Result<T> { public bool Success {get;} public string? Error {get;} public T? Value {get;} private Result(bool success,T? value,string? error){Success=success;Value=value;Error=error;} public static Result<T> Ok(T value)=>new(true,value,null); public static Result<T> Fail(string error)=>new(false,default,error); }
public sealed class Result { public bool Success {get;} public string? Error {get;} private Result(bool success,string? error){Success=success;Error=error;} public static Result Ok()=>new(true,null); public static Result Fail(string error)=>new(false,error); }

using RefrigeratorRepair.Domain.Entities;

namespace RefrigeratorRepair.Application.Interfaces;

// ============================================================================
// Repository Interfaces
// ----------------------------------------------------------------------------
// این فایل «قرارداد» دسترسی به داده‌ها را تعریف می‌کند.
//
// نکته مهم معماری Clean Architecture:
// Application نباید بداند EF Core یا MySQL دقیقاً چگونه کار می‌کند.
// بنابراین فقط می‌گوید «چه کاری لازم دارم» و Infrastructure می‌گوید
// «این کار را با EF Core و MySQL انجام می‌دهم».
// ============================================================================

// قرارداد دسترسی به درخواست‌های تعمیر.
public interface IRepairRequestRepository
{
    Task AddAsync(
        RepairRequest request,
        CancellationToken ct = default);

    Task<RepairRequest?> GetAsync(
        int id,
        CancellationToken ct = default);

    Task<List<RepairRequest>> GetActiveAsync(
        CancellationToken ct = default);
}

// قرارداد دسترسی به تکنسین‌ها.
public interface ITechnicianRepository
{
    Task<Technician?> GetAsync(
        int id,
        CancellationToken ct = default);

    Task<List<Technician>> GetAvailableAsync(
        CancellationToken ct = default);

    Task<List<Technician>> GetAllAsync(
        CancellationToken ct = default);
}

// قرارداد دسترسی به پرونده‌های تعمیر.
public interface IRepairJobRepository
{
    Task<RepairJob?> GetAsync(
        int id,
        CancellationToken ct = default);

    Task<List<RepairJob>> GetHistoryAsync(
        int technicianId,
        CancellationToken ct = default);
}

// قرارداد مخصوص داده‌های کیف پول تکنسین.
// این Interface قبلاً در نسخه قبلی استفاده شده بود ولی تعریف نشده بود؛
// همین موضوع باعث خطای IWalletRepository در Program.cs و WalletService می‌شد.
public interface IWalletRepository
{
    Task<Technician?> GetTechnicianAsync(
        int technicianId,
        CancellationToken ct = default);

    void AddTransaction(
        WalletTransaction transaction);

    // برای پیگیری و Verify کردن تراکنش شارژ کیف پول لازم است.
    void AddPaymentTransaction(
        PaymentTransaction transaction);

    Task<PaymentTransaction?> GetPaymentTransactionByAuthorityAsync(
        string authority,
        CancellationToken ct = default);
}

// Unit of Work مسئول ذخیره تغییرات و مدیریت تراکنش دیتابیس است.
public interface IUnitOfWork
{
    Task<int> SaveChangesAsync(
        CancellationToken ct = default);

    Task ExecuteInTransactionAsync(
        Func<Task> action,
        CancellationToken ct = default);
}

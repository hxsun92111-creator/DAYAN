using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.DTOs;

namespace RefrigeratorRepair.Application.Interfaces;

// ============================================================================
// Service Interfaces
// ----------------------------------------------------------------------------
// این Interfaceها قرارداد Business Logic هستند.
// Razor Page نباید خودش محاسبه کمیسیون، تخصیص تکنسین یا منطق کیف پول را انجام دهد.
// Page فقط اطلاعات را می‌گیرد و Service را صدا می‌زند.
// ============================================================================

// سرویس ایجاد درخواست تعمیر و پیشنهاد آن به تکنسین‌ها.
public interface IRepairRequestService
{
    Task<Result<string>> CreateAsync(
        CreateRepairRequestDto dto,
        CancellationToken ct = default);

    Task<int> OfferToTechniciansAsync(
        int requestId,
        CancellationToken ct = default);
}

// سرویس ثبت گزارش تعمیر و محاسبه سهم مرکز.
public interface IRepairJobService
{
    Task<Result> CompleteAsync(
        int jobId,
        CompleteRepairJobDto dto,
        CancellationToken ct = default);

    Task<Result> AddPartAsync(
        AddPartDto dto,
        CancellationToken ct = default);
}

// سرویس کیف پول، شارژ و کسر کمیسیون.
public interface IWalletService
{
    Task<Result<string>> CreateTopUpAsync(
        int technicianId,
        decimal amount,
        CancellationToken ct = default);

    Task<Result> ApplyTopUpAsync(
        string authority,
        CancellationToken ct = default);

    Task<Result> DeductCommissionAsync(
        int technicianId,
        decimal amount,
        int jobId,
        string description,
        CancellationToken ct = default);
}

// درگاه پرداخت را از Business Logic جدا می‌کنیم.
// بعداً می‌توانیم درگاه واقعی را جایگزین FakePaymentGateway کنیم.
public interface IPaymentGateway
{
    Task<PaymentStartResult> StartAsync(
        decimal amount,
        string callbackUrl,
        CancellationToken ct = default);

    Task<PaymentVerifyResult> VerifyAsync(
        string authority,
        decimal amount,
        CancellationToken ct = default);
}

public record PaymentStartResult(
    bool Success,
    string? Authority,
    string? PaymentUrl,
    string? Error);

public record PaymentVerifyResult(
    bool Success,
    string? ReferenceId,
    string? Error);

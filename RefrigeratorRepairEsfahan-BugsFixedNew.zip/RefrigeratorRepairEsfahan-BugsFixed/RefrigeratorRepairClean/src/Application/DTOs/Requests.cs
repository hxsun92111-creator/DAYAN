// DTOها داده‌ای هستند که بین Web و Application جابه‌جا می‌شوند.
// Entity دیتابیس را مستقیم به فرم HTML نمی‌بندیم؛ DTO مرز امن و مشخص این ارتباط است.

using System.ComponentModel.DataAnnotations;
namespace RefrigeratorRepair.Application.DTOs;
// داده‌های فرم ثبت درخواست مشتری.
public sealed class CreateRepairRequestDto { [Required,MaxLength(80)] public string FirstName {get;set;}=""; [Required,MaxLength(100)] public string LastName {get;set;}=""; [Required,Phone,MaxLength(20)] public string PhoneNumber {get;set;}=""; [Required,MaxLength(1000)] public string ProblemDescription {get;set;}=""; [Required,MaxLength(1000)] public string Address {get;set;}=""; [Range(-90,90)] public decimal Latitude {get;set;} [Range(-180,180)] public decimal Longitude {get;set;} }
// داده‌های گزارش نهایی تکنسین.
public sealed class CompleteRepairJobDto { public int JobId {get;set;} [Required] public string ServiceDescription {get;set;}=""; [Required] public string TechnicianDiagnosis {get;set;}=""; public decimal TravelCost {get;set;} public decimal LaborCost {get;set;} public decimal CustomerTotal {get;set;} }
// ردیف قطعه مصرفی.
public sealed class AddPartDto { public int JobId {get;set;} [Required] public string PartName {get;set;}=""; [Range(1,1000)] public int Quantity {get;set;}=1; [Range(0,decimal.MaxValue)] public decimal UnitPrice {get;set;} }
// شارژ کیف پول تکنسین.
public sealed class TopUpWalletDto { [Range(2000000,decimal.MaxValue)] public decimal Amount {get;set;} }
// ثبت‌نام تکنسین.
public sealed class TechnicianRegistrationDto { [Required] public string FirstName {get;set;}=""; [Required] public string LastName {get;set;}=""; [Required,MaxLength(10)] public string NationalId {get;set;}=""; [Required,Phone] public string PhoneNumber {get;set;}=""; [Required] public string Address {get;set;}=""; [Range(0,60)] public int ExperienceYears {get;set;} [Required] public string Specialization {get;set;}=""; }

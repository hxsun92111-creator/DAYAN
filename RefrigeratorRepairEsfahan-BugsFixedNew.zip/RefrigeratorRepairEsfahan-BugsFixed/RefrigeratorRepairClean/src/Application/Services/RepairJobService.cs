using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.DTOs;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;

namespace RefrigeratorRepair.Application.Services;

// ============================================================================
// RepairJobService
// ----------------------------------------------------------------------------
// ثبت گزارش تعمیر و محاسبه سهم مرکز در این Service انجام می‌شود.
// عملیات تکمیل تعمیر و کسر کمیسیون داخل Transaction اجرا می‌شود تا اگر
// یکی از مراحل شکست خورد، وضعیت تعمیر و کیف پول نیمه‌کاره باقی نماند.
// ============================================================================
public sealed class RepairJobService(
    IRepairJobRepository jobs,
    IUnitOfWork uow,
    IWalletService wallet) : IRepairJobService
{
    public async Task<Result> AddPartAsync(
        AddPartDto dto,
        CancellationToken ct = default)
    {
        var job = await jobs.GetAsync(dto.JobId, ct);

        if (job is null)
        {
            return Result.Fail("تعمیر پیدا نشد.");
        }

        job.Parts.Add(
            new RepairPart
            {
                PartName = dto.PartName,
                Quantity = dto.Quantity,
                UnitPrice = dto.UnitPrice
            });

        await uow.SaveChangesAsync(ct);

        return Result.Ok();
    }

    public async Task<Result> CompleteAsync(
        int jobId,
        CompleteRepairJobDto dto,
        CancellationToken ct = default)
    {
        try
        {
            Result result = Result.Ok();

            await uow.ExecuteInTransactionAsync(
                async () =>
                {
                    var job = await jobs.GetAsync(jobId, ct);

                    if (job is null)
                    {
                        result = Result.Fail("تعمیر پیدا نشد.");
                        return;
                    }

                    if (job.ReportSubmitted)
                    {
                        result = Result.Fail(
                            "گزارش این تعمیر قبلاً ثبت شده است.");
                        return;
                    }

                    job.ServiceDescription = dto.ServiceDescription;
                    job.TechnicianDiagnosis = dto.TechnicianDiagnosis;
                    job.TravelCost = dto.TravelCost;
                    job.LaborCost = dto.LaborCost;
                    job.CustomerTotal = dto.CustomerTotal;

                    job.PartsCost = job.Parts.Sum(
                        part => part.TotalPrice);

                    // مبنای کمیسیون = مبلغ دریافتی - قطعات - هزینه رفت‌وآمد.
                    job.NetProfitBase = Math.Max(
                        0,
                        job.CustomerTotal
                        - job.PartsCost
                        - job.TravelCost);

                    // سهم مرکز طبق قرارداد ۲۵ درصد است.
                    job.CommissionAmount = Math.Round(
                        job.NetProfitBase * 0.25m,
                        0);

                    result = await wallet.DeductCommissionAsync(
                        job.TechnicianId,
                        job.CommissionAmount,
                        job.Id,
                        $"کسر ۲۵٪ سهم مرکز از تعمیر {job.Request.TrackingCode}",
                        ct);

                    if (!result.Success)
                    {
                        return;
                    }

                    job.ReportSubmitted = true;
                    job.RepairDate = DateTime.UtcNow;
                    job.Request.Status = RepairRequestStatus.Completed;
                    job.Request.CompletedAt = DateTime.UtcNow;
                },
                ct);

            return result;
        }
        catch (Exception ex)
        {
            return Result.Fail(
                $"ثبت گزارش تعمیر انجام نشد: {ex.Message}");
        }
    }
}

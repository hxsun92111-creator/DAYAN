using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.DTOs;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;

namespace RefrigeratorRepair.Application.Services;

// ============================================================================
// RepairRequestService
// ----------------------------------------------------------------------------
// منطق ثبت درخواست مشتری و انتخاب حداکثر سه تکنسین مناسب در این Service است.
// Razor Page فقط DTO را می‌فرستد و نتیجه را نمایش می‌دهد.
// ============================================================================
public sealed class RepairRequestService(
    IRepairRequestRepository requests,
    ITechnicianRepository technicians,
    IUnitOfWork uow) : IRepairRequestService
{
    public async Task<Result<string>> CreateAsync(
        CreateRepairRequestDto dto,
        CancellationToken ct = default)
    {
        // Tracking Code مستقل از Id دیتابیس است و برای ارائه به مشتری مناسب است.
        var code =
            $"ESF-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid():N}"
                [..24]
                .ToUpperInvariant();

        var customer = new Customer
        {
            FirstName = dto.FirstName,
            LastName = dto.LastName,
            PhoneNumber = dto.PhoneNumber
        };

        var request = new RepairRequest
        {
            TrackingCode = code,
            Customer = customer,
            ProblemDescription = dto.ProblemDescription,
            Address = dto.Address,
            Latitude = dto.Latitude,
            Longitude = dto.Longitude
        };

        await requests.AddAsync(request, ct);
        await uow.SaveChangesAsync(ct);

        // بعد از ایجاد درخواست، حداکثر سه تکنسین آزاد پیشنهاد دریافت می‌کنند.
        await OfferToTechniciansAsync(request.Id, ct);

        return Result<string>.Ok(code);
    }

    public async Task<int> OfferToTechniciansAsync(
        int requestId,
        CancellationToken ct = default)
    {
        var request = await requests.GetAsync(requestId, ct)
            ?? throw new InvalidOperationException(
                "درخواست تعمیر پیدا نشد.");

        var availableTechnicians =
            await technicians.GetAvailableAsync(ct);

        var selectedTechnicians =
            availableTechnicians
                .Take(3)
                .ToList();

        foreach (var technician in selectedTechnicians)
        {
            request.Offers.Add(
                new TechnicianOffer
                {
                    TechnicianId = technician.Id,
                    Request = request
                });
        }

        request.Status =
            selectedTechnicians.Count > 0
                ? RepairRequestStatus.WaitingForAssignment
                : RepairRequestStatus.New;

        await uow.SaveChangesAsync(ct);

        return selectedTechnicians.Count;
    }
}

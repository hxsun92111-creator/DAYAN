using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;

namespace RefrigeratorRepair.Application.Services;

// ============================================================================
// WalletService
// ----------------------------------------------------------------------------
// این کلاس Business Ruleهای کیف پول را اجرا می‌کند.
// Repository فقط داده را می‌خواند/ثبت می‌کند؛ تصمیم‌هایی مثل «حداقل شارژ» و
// «کافی بودن موجودی برای کمیسیون» در این Service قرار دارند.
// ============================================================================
public sealed class WalletService(
    IWalletRepository wallet,
    IPaymentGateway gateway,
    IUnitOfWork uow) : IWalletService
{
    public async Task<Result<string>> CreateTopUpAsync(
        int technicianId,
        decimal amount,
        CancellationToken ct = default)
    {
        // طبق قانون کسب‌وکار، حداقل مبلغ شارژ ۲ میلیون تومان است.
        if (amount < 2_000_000)
        {
            return Result<string>.Fail(
                "حداقل شارژ کیف پول ۲,۰۰۰,۰۰۰ تومان است.");
        }

        // درگاه مسئول ایجاد تراکنش و برگرداندن Authority است.
        var result = await gateway.StartAsync(
            amount,
            "/Technician/Wallet/Callback",
            ct);

        if (!result.Success || result.Authority is null)
        {
            return Result<string>.Fail(
                result.Error ?? "خطای درگاه پرداخت.");
        }

        // تراکنش Pending را ذخیره می‌کنیم تا در Callback بتوانیم مبلغ و
        // مالک صحیح را پیدا کرده و Verify کنیم.
        wallet.AddPaymentTransaction(
            new PaymentTransaction
            {
                TechnicianId = technicianId,
                Amount = amount,
                Authority = result.Authority,
                Status = "Pending"
            });

        await uow.SaveChangesAsync(ct);

        return Result<string>.Ok(result.PaymentUrl!);
    }

    public async Task<Result> ApplyTopUpAsync(
        string authority,
        CancellationToken ct = default)
    {
        var transaction = await wallet.GetPaymentTransactionByAuthorityAsync(
            authority,
            ct);

        if (transaction is null)
        {
            return Result.Fail("تراکنش پرداخت پیدا نشد.");
        }

        // Idempotent: اگر این تراکنش قبلاً Verify و اعمال شده، دوباره موجودی
        // را افزایش نمی‌دهیم (مثلاً وقتی کاربر صفحه Callback را رفرش می‌کند).
        if (transaction.Status == "Verified")
        {
            return Result.Ok();
        }

        var verify = await gateway.VerifyAsync(
            authority,
            transaction.Amount,
            ct);

        if (!verify.Success)
        {
            transaction.Status = "Failed";
            await uow.SaveChangesAsync(ct);

            return Result.Fail(verify.Error ?? "پرداخت تأیید نشد.");
        }

        Result result = Result.Ok();

        await uow.ExecuteInTransactionAsync(
            async () =>
            {
                var technician = await wallet.GetTechnicianAsync(
                    transaction.TechnicianId,
                    ct);

                if (technician is null)
                {
                    result = Result.Fail("تکنسین پیدا نشد.");
                    return;
                }

                technician.WalletBalance += transaction.Amount;

                wallet.AddTransaction(
                    new WalletTransaction
                    {
                        TechnicianId = technician.Id,
                        Type = WalletTransactionType.TopUp,
                        Amount = transaction.Amount,
                        BalanceAfter = technician.WalletBalance,
                        Description = $"شارژ کیف پول - Authority {authority}"
                    });

                transaction.Status = "Verified";
                transaction.ReferenceId = verify.ReferenceId;
                transaction.VerifiedAt = DateTime.UtcNow;
            },
            ct);

        return result;
    }

    public async Task<Result> DeductCommissionAsync(
        int technicianId,
        decimal amount,
        int jobId,
        string description,
        CancellationToken ct = default)
    {
        if (amount <= 0)
        {
            return Result.Ok();
        }

        var technician = await wallet.GetTechnicianAsync(
            technicianId,
            ct);

        if (technician is null)
        {
            return Result.Fail("تکنسین پیدا نشد.");
        }

        if (technician.WalletBalance < amount)
        {
            return Result.Fail(
                "موجودی کیف پول برای کسر کمیسیون کافی نیست.");
        }

        technician.WalletBalance -= amount;

        // علاوه بر تغییر Balance، یک سند حسابداری نیز ثبت می‌کنیم.
        wallet.AddTransaction(
            new WalletTransaction
            {
                TechnicianId = technician.Id,
                Type = WalletTransactionType.CommissionDebit,
                Amount = -amount,
                BalanceAfter = technician.WalletBalance,
                Description = description,
                RepairJobId = jobId
            });

        return Result.Ok();
    }
}

// Repository کیف پول؛ موجودی از روی دفتر تراکنش‌ها محاسبه می‌شود.
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Infrastructure.Repositories;

public sealed class WalletRepository(ApplicationDbContext db) : IWalletRepository
{
    public Task<Technician?> GetTechnicianAsync(int technicianId, CancellationToken ct = default)
        => db.Technicians.SingleOrDefaultAsync(x => x.Id == technicianId, ct);

    public async Task<decimal> GetBalanceAsync(int technicianId, CancellationToken ct = default)
    {
        var value = await db.WalletTransactions
            .Where(x => x.TechnicianId == technicianId)
            .SumAsync(x => (decimal?)x.Amount, ct);

        return value ?? 0m;
    }

    public void AddTransaction(WalletTransaction transaction)
        => db.WalletTransactions.Add(transaction);

    public Task<PaymentTransaction?> GetPaymentByAuthorityAsync(string authority, CancellationToken ct = default)
        => db.PaymentTransactions.SingleOrDefaultAsync(x => x.Authority == authority, ct);

    public void AddPayment(PaymentTransaction payment)
        => db.PaymentTransactions.Add(payment);
}

// Unit of Work مسئول SaveChanges و Transaction دیتابیس است.
public sealed class UnitOfWork(ApplicationDbContext db) : IUnitOfWork
{
    public Task<int> SaveChangesAsync(CancellationToken ct = default)
        => db.SaveChangesAsync(ct);

    public async Task ExecuteInTransactionAsync(Func<Task> action, CancellationToken ct = default)
    {
        await using var tx = await db.Database.BeginTransactionAsync(
            System.Data.IsolationLevel.Serializable, ct);

        try
        {
            await action();
            await db.SaveChangesAsync(ct);
            await tx.CommitAsync(ct);
        }
        catch
        {
            await tx.RollbackAsync(ct);
            throw;
        }
    }
}

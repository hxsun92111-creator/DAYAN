// Repositoryهای EF Core. اینجا تنها لایه‌ای است که مستقیماً Queryهای دیتابیس را می‌نویسد.
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Infrastructure.Repositories;

public sealed class CustomerRepository(ApplicationDbContext db) : ICustomerRepository
{
    public Task<Customer?> FindByPhoneAsync(string phone, CancellationToken ct = default)
        => db.Customers.SingleOrDefaultAsync(x => x.PhoneNumber == phone, ct);

    public Task<List<Customer>> GetAllAsync(CancellationToken ct = default)
        => db.Customers.OrderByDescending(x => x.LastOrderAt).ToListAsync(ct);

    public Task<Customer?> GetWithHistoryAsync(int id, CancellationToken ct = default)
        => db.Customers.Include(x => x.Requests).ThenInclude(x => x.ServiceCatalog).Include(x => x.Requests).ThenInclude(x => x.RepairJob)
            .SingleOrDefaultAsync(x => x.Id == id, ct);
}


public sealed class ServiceCatalogRepository(ApplicationDbContext db) : IServiceCatalogRepository
{
    public Task<List<ServiceCatalog>> GetActiveAsync(CancellationToken ct = default)
        => db.Services.AsNoTracking()
            .Where(x => x.IsActive)
            .OrderBy(x => x.Id)
            .ToListAsync(ct);

    public Task<ServiceCatalog?> GetActiveByIdAsync(int id, CancellationToken ct = default)
        => db.Services.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == id && x.IsActive, ct);
}

public sealed class RepairRequestRepository(ApplicationDbContext db) : IRepairRequestRepository
{
    public Task AddAsync(RepairRequest request, CancellationToken ct = default)
        => db.RepairRequests.AddAsync(request, ct).AsTask();

    public Task<RepairRequest?> GetAsync(int id, CancellationToken ct = default)
        => db.RepairRequests
            .Include(x => x.Offers)
            .Include(x => x.Customer)
            .Include(x => x.ServiceCatalog)
            .Include(x => x.AssignedTechnician)
            .Include(x => x.RepairJob)
            .SingleOrDefaultAsync(x => x.Id == id, ct);

    public Task<List<RepairRequest>> GetActiveAsync(CancellationToken ct = default)
        => db.RepairRequests
            .Include(x => x.Customer)
            .Include(x => x.ServiceCatalog)
            .Include(x => x.AssignedTechnician)
            .Where(x => x.Status != RepairRequestStatus.Completed && x.Status != RepairRequestStatus.Cancelled)
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync(ct);
}

public sealed class TechnicianRepository(ApplicationDbContext db) : ITechnicianRepository
{
    public Task<Technician?> GetAsync(int id, CancellationToken ct = default)
        => db.Technicians.SingleOrDefaultAsync(x => x.Id == id, ct);

    public Task<List<Technician>> GetAllAsync(CancellationToken ct = default)
        => db.Technicians
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync(ct);

    // فقط تکنسین‌های تأییدشده و آزاد را برمی‌گردانیم.
    // «مشغول بودن» با وجود Job تکمیل‌نشده هم کنترل می‌شود.
    public Task<List<Technician>> GetAvailableAsync(CancellationToken ct = default)
        => db.Technicians
            .Where(x => x.AccountStatus == TechnicianAccountStatus.Active)
            .Where(x => x.Availability == TechnicianAvailability.Available)
            .Where(x => !x.Jobs.Any(j =>
                j.Request.Status != RepairRequestStatus.Completed &&
                j.Request.Status != RepairRequestStatus.Cancelled))
            .OrderBy(x => x.CreatedAt)
            .ToListAsync(ct);

    public Task<List<Technician>> GetAvailableForOfferAsync(DateTime utcDayStart, int count, CancellationToken ct = default)
        => db.Technicians
            .Where(x => x.AccountStatus == TechnicianAccountStatus.Active)
            .Where(x => x.Availability == TechnicianAvailability.Available)
            .Where(x => !x.Jobs.Any(j =>
                j.Request.Status != RepairRequestStatus.Completed &&
                j.Request.Status != RepairRequestStatus.Cancelled))
            .Where(x => !x.Offers.Any(o => o.SentAt >= utcDayStart))
            .OrderBy(x => x.CreatedAt)
            .Take(count)
            .ToListAsync(ct);
}

public sealed class RepairJobRepository(ApplicationDbContext db) : IRepairJobRepository
{
    public Task<RepairJob?> GetAsync(int id, CancellationToken ct = default)
        => db.RepairJobs
            .Include(x => x.Parts)
            .Include(x => x.Request).ThenInclude(x => x.Customer)
            .Include(x => x.Technician)
            .SingleOrDefaultAsync(x => x.Id == id, ct);

    public Task<List<RepairJob>> GetHistoryAsync(int technicianId, CancellationToken ct = default)
        => db.RepairJobs
            .Include(x => x.Request).ThenInclude(x => x.Customer)
            .Where(x => x.TechnicianId == technicianId && x.ReportSubmitted)
            .OrderByDescending(x => x.RepairDate)
            .ToListAsync(ct);
}

// درگاه جعلی فقط برای تست محلی است و در Production نباید استفاده شود.
using Microsoft.Extensions.Hosting;
using RefrigeratorRepair.Application.Interfaces;

namespace RefrigeratorRepair.Infrastructure.Payments;

public sealed class FakePaymentGateway : IPaymentGateway
{
    private readonly IHostEnvironment environment;

    public FakePaymentGateway(IHostEnvironment environment)
    {
        this.environment = environment;

        if (!environment.IsDevelopment())
        {
            throw new InvalidOperationException(
                "FakePaymentGateway فقط باید در محیط Development استفاده شود.");
        }
    }

    public Task<PaymentStartResult> StartAsync(
        decimal amount,
        string callbackUrl,
        CancellationToken ct = default)
    {
        var authority = Guid.NewGuid().ToString("N");
        // درگاه واقعی callbackUrl را فراخوانی می‌کند؛ برای Fake، authority تولیدشده را مستقیماً به Callback می‌فرستیم.
        var url = $"/Technician/Wallet/MockPay?authority={authority}&callback=/Technician/Wallet/Callback";
        return Task.FromResult(new PaymentStartResult(true, authority, url, null));
    }

    public Task<PaymentVerifyResult> VerifyAsync(
        string authority,
        decimal amount,
        CancellationToken ct = default)
        => Task.FromResult(new PaymentVerifyResult(
            true,
            $"MOCK-{authority[..10]}",
            null));
}

// درگاه Fail-Safe برای Production تا زمانی که درگاه واقعی پیکربندی نشده است.
// این کلاس عمداً هیچ پرداختی را موفق اعلام نمی‌کند.
using RefrigeratorRepair.Application.Interfaces;

namespace RefrigeratorRepair.Infrastructure.Payments;

public sealed class DisabledPaymentGateway : IPaymentGateway
{
    public Task<PaymentStartResult> StartAsync(
        decimal amount,
        string callbackUrl,
        CancellationToken ct = default)
    {
        return Task.FromResult(new PaymentStartResult(
            false,
            null,
            null,
            "درگاه پرداخت واقعی هنوز برای محیط Production پیکربندی نشده است."));
    }

    public Task<PaymentVerifyResult> VerifyAsync(
        string authority,
        decimal amount,
        CancellationToken ct = default)
    {
        return Task.FromResult(new PaymentVerifyResult(
            false,
            null,
            "درگاه پرداخت واقعی هنوز برای محیط Production پیکربندی نشده است."));
    }
}

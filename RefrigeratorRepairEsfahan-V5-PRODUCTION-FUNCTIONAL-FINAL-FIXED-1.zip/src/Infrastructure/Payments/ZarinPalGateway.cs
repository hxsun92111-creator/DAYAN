using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.Interfaces;

namespace RefrigeratorRepair.Infrastructure.Payments;

// درگاه واقعی زرین‌پال.
// مبلغ‌های سیستم تومان هستند؛ API درگاه مبلغ را به ریال دریافت می‌کند،
// بنابراین قبل از ارسال ×10 می‌شود. پاسخ Verify منبع نهایی موفقیت پرداخت است.
public sealed class ZarinPalGateway(
    HttpClient http,
    IOptions<PaymentOptions> options,
    ILogger<ZarinPalGateway> logger) : IPaymentGateway
{
    private readonly PaymentOptions _options = options.Value;

    public async Task<PaymentStartResult> StartAsync(decimal amount, string callbackUrl, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(_options.MerchantId) || string.IsNullOrWhiteSpace(_options.PublicBaseUrl))
            return new(false, null, null, "تنظیمات درگاه پرداخت کامل نیست. MerchantId و PublicBaseUrl را تنظیم کنید.");

        if (amount <= 0 || amount > 100_000_000_000m)
            return new(false, null, null, "مبلغ پرداخت نامعتبر است.");

        var callback = callbackUrl.StartsWith("http", StringComparison.OrdinalIgnoreCase)
            ? callbackUrl
            : new Uri(new Uri(_options.PublicBaseUrl.TrimEnd('/') + "/"), callbackUrl.TrimStart('/')).ToString();

        var payload = new
        {
            merchant_id = _options.MerchantId,
            amount = checked((long)Math.Round(amount * 10m, 0, MidpointRounding.AwayFromZero)),
            callback_url = callback,
            description = "شارژ کیف پول تکنسین تعمیرات یخچال اصفهان",
            currency = "IRR"
        };

        try
        {
            using var response = await http.PostAsJsonAsync(
                _options.ApiBaseUrl.TrimEnd('/') + "/request.json", payload, ct);

            var body = await response.Content.ReadAsStringAsync(ct);
            if (!response.IsSuccessStatusCode)
                return new(false, null, null, "درگاه پرداخت در دسترس نیست.");

            using var json = JsonDocument.Parse(body);
            var data = json.RootElement.GetProperty("data");
            var code = data.GetProperty("code").GetInt32();
            var authority = data.GetProperty("authority").GetString();

            if (code != 100 || string.IsNullOrWhiteSpace(authority))
            {
                var message = json.RootElement.TryGetProperty("errors", out var errors)
                    ? errors.ToString()
                    : "درخواست پرداخت توسط درگاه پذیرفته نشد.";
                return new(false, null, null, message);
            }

            var url = string.Format(_options.StartPayUrl, authority);
            return new(true, authority, url, null);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "ZarinPal payment request failed.");
            return new(false, null, null, "ارتباط با درگاه پرداخت برقرار نشد.");
        }
    }

    public async Task<PaymentVerifyResult> VerifyAsync(string authority, decimal amount, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(_options.MerchantId) || string.IsNullOrWhiteSpace(authority))
            return new(false, null, "اطلاعات Verify پرداخت کامل نیست.");

        var payload = new
        {
            merchant_id = _options.MerchantId,
            amount = checked((long)Math.Round(amount * 10m, 0, MidpointRounding.AwayFromZero)),
            authority
        };

        try
        {
            using var response = await http.PostAsJsonAsync(
                _options.ApiBaseUrl.TrimEnd('/') + "/verify.json", payload, ct);

            var body = await response.Content.ReadAsStringAsync(ct);
            if (!response.IsSuccessStatusCode)
                return new(false, null, "تأیید پرداخت از درگاه ناموفق بود.");

            using var json = JsonDocument.Parse(body);
            var data = json.RootElement.GetProperty("data");
            var code = data.GetProperty("code").GetInt32();
            var reference = data.TryGetProperty("ref_id", out var refId)
                ? refId.ToString()
                : null;

            // 100 = پرداخت موفق جدید، 101 = قبلاً Verify شده و موفق است.
            if (code is 100 or 101 && !string.IsNullOrWhiteSpace(reference))
                return new(true, reference, null);

            return new(false, null, "پرداخت توسط درگاه تأیید نشد.");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "ZarinPal payment verification failed for {Authority}.", authority);
            return new(false, null, "ارتباط با درگاه برای تأیید پرداخت برقرار نشد.");
        }
    }
}

# EF Core Migration

Migration `202609120001_InitialMySqlSchema` برای MySQL 8 اضافه شده است.

- در هر Startup، برنامه `Database.MigrateAsync()` را اجرا می‌کند.
- در دیتابیس جدید، جدول‌های Identity و جداول کسب‌وکار ساخته می‌شوند.
- در دیتابیس قدیمی، ستون‌های جدید RepairRequests نیز با `ADD COLUMN IF NOT EXISTS` اضافه می‌شوند.
- قبل از Production از دیتابیس Backup بگیرید و Migration را روی یک محیط Staging اجرا کنید.

نکته: این Migration برای MySQL پروژه نوشته شده است و SQL آن عمداً provider-specific است.

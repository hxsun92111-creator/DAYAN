using Microsoft.EntityFrameworkCore.Migrations;
using System;

#nullable disable

namespace RefrigeratorRepair.Infrastructure.Migrations;

// Migration پایه MySQL پروژه.
// این Migration عمداً SQL شفاف دارد تا روی MySQL 8 قابل اجرای مستقیم باشد.
// در اولین اجرای Production، EF آن را در __EFMigrationsHistory ثبت می‌کند.
[Migration("202609120001_InitialMySqlSchema")]
public partial class InitialMySqlSchema : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"
CREATE TABLE IF NOT EXISTS AspNetRoles (
    Id varchar(255) NOT NULL,
    Name varchar(256) NULL,
    NormalizedName varchar(256) NULL,
    ConcurrencyStamp longtext NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_AspNetRoles_NormalizedName (NormalizedName)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS AspNetUsers (
    Id varchar(255) NOT NULL,
    UserName varchar(256) NULL,
    NormalizedUserName varchar(256) NULL,
    Email varchar(256) NULL,
    NormalizedEmail varchar(256) NULL,
    EmailConfirmed tinyint(1) NOT NULL,
    PasswordHash longtext NULL,
    SecurityStamp longtext NULL,
    ConcurrencyStamp longtext NULL,
    PhoneNumber longtext NULL,
    PhoneNumberConfirmed tinyint(1) NOT NULL,
    TwoFactorEnabled tinyint(1) NOT NULL,
    LockoutEnd datetime(6) NULL,
    LockoutEnabled tinyint(1) NOT NULL,
    AccessFailedCount int NOT NULL,
    IsActive tinyint(1) NOT NULL,
    CreatedAt datetime(6) NOT NULL,
    PRIMARY KEY (Id),
    KEY EmailIndex (NormalizedEmail),
    UNIQUE KEY UserNameIndex (NormalizedUserName)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS AspNetRoleClaims (
    Id int NOT NULL AUTO_INCREMENT,
    RoleId varchar(255) NOT NULL,
    ClaimType longtext NULL,
    ClaimValue longtext NULL,
    PRIMARY KEY (Id),
    KEY IX_AspNetRoleClaims_RoleId (RoleId),
    CONSTRAINT FK_AspNetRoleClaims_AspNetRoles_RoleId FOREIGN KEY (RoleId) REFERENCES AspNetRoles (Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS AspNetUserClaims (
    Id int NOT NULL AUTO_INCREMENT,
    UserId varchar(255) NOT NULL,
    ClaimType longtext NULL,
    ClaimValue longtext NULL,
    PRIMARY KEY (Id),
    KEY IX_AspNetUserClaims_UserId (UserId),
    CONSTRAINT FK_AspNetUserClaims_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES AspNetUsers (Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS AspNetUserLogins (
    LoginProvider varchar(128) NOT NULL,
    ProviderKey varchar(128) NOT NULL,
    ProviderDisplayName longtext NULL,
    UserId varchar(255) NOT NULL,
    PRIMARY KEY (LoginProvider, ProviderKey),
    KEY IX_AspNetUserLogins_UserId (UserId),
    CONSTRAINT FK_AspNetUserLogins_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES AspNetUsers (Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS AspNetUserRoles (
    UserId varchar(255) NOT NULL,
    RoleId varchar(255) NOT NULL,
    PRIMARY KEY (UserId, RoleId),
    KEY IX_AspNetUserRoles_RoleId (RoleId),
    CONSTRAINT FK_AspNetUserRoles_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES AspNetUsers (Id) ON DELETE CASCADE,
    CONSTRAINT FK_AspNetUserRoles_AspNetRoles_RoleId FOREIGN KEY (RoleId) REFERENCES AspNetRoles (Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS AspNetUserTokens (
    UserId varchar(255) NOT NULL,
    LoginProvider varchar(128) NOT NULL,
    Name varchar(128) NOT NULL,
    Value longtext NULL,
    PRIMARY KEY (UserId, LoginProvider, Name),
    CONSTRAINT FK_AspNetUserTokens_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES AspNetUsers (Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Customers (
    Id int NOT NULL AUTO_INCREMENT,
    UserId varchar(450) NULL,
    FirstName varchar(80) NOT NULL,
    LastName varchar(100) NOT NULL,
    PhoneNumber varchar(20) NOT NULL,
    CreatedAt datetime(6) NOT NULL,
    LastOrderAt datetime(6) NOT NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_Customers_PhoneNumber (PhoneNumber),
    UNIQUE KEY IX_Customers_UserId (UserId)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS AdminProfiles (
    Id int NOT NULL AUTO_INCREMENT,
    UserId varchar(450) NOT NULL,
    DisplayName varchar(150) NOT NULL,
    IsActive tinyint(1) NOT NULL,
    CreatedAt datetime(6) NOT NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_AdminProfiles_UserId (UserId)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Technicians (
    Id int NOT NULL AUTO_INCREMENT,
    UserId varchar(450) NOT NULL,
    FirstName varchar(80) NOT NULL,
    LastName varchar(100) NOT NULL,
    NationalId varchar(10) NOT NULL,
    PhoneNumber varchar(20) NOT NULL,
    Address varchar(1000) NOT NULL,
    ExperienceYears int NOT NULL,
    Specialization varchar(200) NOT NULL,
    ProfilePhotoPath varchar(500) NULL,
    AccountStatus int NOT NULL,
    Availability int NOT NULL,
    CreatedAt datetime(6) NOT NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_Technicians_UserId (UserId),
    UNIQUE KEY IX_Technicians_NationalId (NationalId),
    KEY IX_Technicians_AccountStatus_Availability (AccountStatus, Availability)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS Services (
    Id int NOT NULL AUTO_INCREMENT,
    Title varchar(150) NOT NULL,
    ShortDescription varchar(1000) NOT NULL,
    IsActive tinyint(1) NOT NULL,
    PRIMARY KEY (Id),
    KEY IX_Services_IsActive_Title (IsActive, Title)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS RepairRequests (
    Id int NOT NULL AUTO_INCREMENT,
    TrackingCode varchar(50) NOT NULL,
    CustomerId int NOT NULL,
    ServiceCatalogId int NULL,
    DeviceBrand varchar(80) NULL,
    DeviceType varchar(100) NULL,
    PreferredVisitDate date NULL,
    PreferredVisitWindow varchar(80) NULL,
    AssignedTechnicianId int NULL,
    ProblemDescription varchar(1000) NOT NULL,
    Address varchar(1000) NOT NULL,
    Latitude decimal(9,6) NOT NULL,
    Longitude decimal(9,6) NOT NULL,
    CreatedAt datetime(6) NOT NULL,
    AssignedAt datetime(6) NULL,
    CompletedAt datetime(6) NULL,
    Status int NOT NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_RepairRequests_TrackingCode (TrackingCode),
    KEY IX_RepairRequests_ServiceCatalogId_CreatedAt (ServiceCatalogId, CreatedAt),
    KEY IX_RepairRequests_Status_CreatedAt (Status, CreatedAt),
    KEY IX_RepairRequests_AssignedTechnicianId_Status (AssignedTechnicianId, Status),
    CONSTRAINT FK_RepairRequests_Customers_CustomerId FOREIGN KEY (CustomerId) REFERENCES Customers (Id) ON DELETE RESTRICT,
    CONSTRAINT FK_RepairRequests_Services_ServiceCatalogId FOREIGN KEY (ServiceCatalogId) REFERENCES Services (Id) ON DELETE SET NULL,
    CONSTRAINT FK_RepairRequests_Technicians_AssignedTechnicianId FOREIGN KEY (AssignedTechnicianId) REFERENCES Technicians (Id) ON DELETE SET NULL
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS RepairJobs (
    Id int NOT NULL AUTO_INCREMENT,
    RepairRequestId int NOT NULL,
    TechnicianId int NOT NULL,
    RepairDate datetime(6) NULL,
    ServiceDescription varchar(2000) NULL,
    TechnicianDiagnosis varchar(3000) NULL,
    TravelCost decimal(18,2) NOT NULL,
    LaborCost decimal(18,2) NOT NULL,
    CustomerTotal decimal(18,2) NOT NULL,
    PartsCost decimal(18,2) NOT NULL,
    NetProfitBase decimal(18,2) NOT NULL,
    CommissionAmount decimal(18,2) NOT NULL,
    ReportSubmitted tinyint(1) NOT NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_RepairJobs_RepairRequestId (RepairRequestId),
    KEY IX_RepairJobs_TechnicianId (TechnicianId),
    CONSTRAINT FK_RepairJobs_RepairRequests_RepairRequestId FOREIGN KEY (RepairRequestId) REFERENCES RepairRequests (Id) ON DELETE CASCADE,
    CONSTRAINT FK_RepairJobs_Technicians_TechnicianId FOREIGN KEY (TechnicianId) REFERENCES Technicians (Id) ON DELETE RESTRICT
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS RepairParts (
    Id int NOT NULL AUTO_INCREMENT,
    RepairJobId int NOT NULL,
    PartName varchar(200) NOT NULL,
    Quantity int NOT NULL,
    UnitPrice decimal(18,2) NOT NULL,
    PRIMARY KEY (Id),
    KEY IX_RepairParts_RepairJobId (RepairJobId),
    CONSTRAINT FK_RepairParts_RepairJobs_RepairJobId FOREIGN KEY (RepairJobId) REFERENCES RepairJobs (Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS TechnicianOffers (
    Id int NOT NULL AUTO_INCREMENT,
    RepairRequestId int NOT NULL,
    TechnicianId int NOT NULL,
    SentAt datetime(6) NOT NULL,
    ExpiresAt datetime(6) NOT NULL,
    Status int NOT NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_TechnicianOffers_Request_Technician (RepairRequestId, TechnicianId),
    KEY IX_TechnicianOffers_Technician_SentAt (TechnicianId, SentAt),
    KEY IX_TechnicianOffers_Status_ExpiresAt (Status, ExpiresAt),
    CONSTRAINT FK_TechnicianOffers_RepairRequests_RepairRequestId FOREIGN KEY (RepairRequestId) REFERENCES RepairRequests (Id) ON DELETE CASCADE,
    CONSTRAINT FK_TechnicianOffers_Technicians_TechnicianId FOREIGN KEY (TechnicianId) REFERENCES Technicians (Id) ON DELETE RESTRICT
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS TechnicianDocuments (
    Id int NOT NULL AUTO_INCREMENT,
    TechnicianId int NOT NULL,
    DocumentType varchar(100) NOT NULL,
    FilePath varchar(500) NOT NULL,
    UploadedAt datetime(6) NOT NULL,
    PRIMARY KEY (Id),
    KEY IX_TechnicianDocuments_Technician_DocumentType (TechnicianId, DocumentType),
    CONSTRAINT FK_TechnicianDocuments_Technicians_TechnicianId FOREIGN KEY (TechnicianId) REFERENCES Technicians (Id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS PaymentTransactions (
    Id int NOT NULL AUTO_INCREMENT,
    TechnicianId int NOT NULL,
    Amount decimal(18,2) NOT NULL,
    Authority varchar(200) NULL,
    ReferenceId varchar(200) NULL,
    Status int NOT NULL,
    CreatedAt datetime(6) NOT NULL,
    VerifiedAt datetime(6) NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_PaymentTransactions_Authority (Authority),
    KEY IX_PaymentTransactions_Technician_CreatedAt (TechnicianId, CreatedAt),
    CONSTRAINT FK_PaymentTransactions_Technicians_TechnicianId FOREIGN KEY (TechnicianId) REFERENCES Technicians (Id) ON DELETE RESTRICT
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS WalletTransactions (
    Id int NOT NULL AUTO_INCREMENT,
    TechnicianId int NOT NULL,
    Type int NOT NULL,
    Amount decimal(18,2) NOT NULL,
    BalanceAfter decimal(18,2) NOT NULL,
    Description varchar(500) NOT NULL,
    RepairJobId int NULL,
    PaymentTransactionId int NULL,
    CreatedAt datetime(6) NOT NULL,
    PRIMARY KEY (Id),
    UNIQUE KEY IX_WalletTransactions_PaymentTransactionId (PaymentTransactionId),
    UNIQUE KEY IX_WalletTransactions_RepairJobId (RepairJobId),
    KEY IX_WalletTransactions_Technician_CreatedAt (TechnicianId, CreatedAt),
    CONSTRAINT FK_WalletTransactions_Technicians_TechnicianId FOREIGN KEY (TechnicianId) REFERENCES Technicians (Id) ON DELETE RESTRICT,
    CONSTRAINT FK_WalletTransactions_PaymentTransactions_PaymentTransactionId FOREIGN KEY (PaymentTransactionId) REFERENCES PaymentTransactions (Id) ON DELETE SET NULL
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
");

        // برای دیتابیس‌های قدیمی، ستون‌های نسخه جدید سفارش را نیز اضافه می‌کنیم.
        migrationBuilder.Sql(@"
ALTER TABLE Customers ADD COLUMN IF NOT EXISTS UserId varchar(450) NULL;
ALTER TABLE RepairRequests ADD COLUMN IF NOT EXISTS ServiceCatalogId int NULL;
ALTER TABLE RepairRequests ADD COLUMN IF NOT EXISTS DeviceBrand varchar(80) NULL;
ALTER TABLE RepairRequests ADD COLUMN IF NOT EXISTS DeviceType varchar(100) NULL;
ALTER TABLE RepairRequests ADD COLUMN IF NOT EXISTS PreferredVisitDate date NULL;
ALTER TABLE RepairRequests ADD COLUMN IF NOT EXISTS PreferredVisitWindow varchar(80) NULL;
");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(@"
DROP TABLE IF EXISTS WalletTransactions;
DROP TABLE IF EXISTS PaymentTransactions;
DROP TABLE IF EXISTS TechnicianDocuments;
DROP TABLE IF EXISTS TechnicianOffers;
DROP TABLE IF EXISTS RepairParts;
DROP TABLE IF EXISTS RepairJobs;
DROP TABLE IF EXISTS RepairRequests;
DROP TABLE IF EXISTS Services;
DROP TABLE IF EXISTS Technicians;
DROP TABLE IF EXISTS AdminProfiles;
DROP TABLE IF EXISTS Customers;
DROP TABLE IF EXISTS AspNetUserTokens;
DROP TABLE IF EXISTS AspNetUserRoles;
DROP TABLE IF EXISTS AspNetUserLogins;
DROP TABLE IF EXISTS AspNetUserClaims;
DROP TABLE IF EXISTS AspNetRoleClaims;
DROP TABLE IF EXISTS AspNetUsers;
DROP TABLE IF EXISTS AspNetRoles;
");
    }
}

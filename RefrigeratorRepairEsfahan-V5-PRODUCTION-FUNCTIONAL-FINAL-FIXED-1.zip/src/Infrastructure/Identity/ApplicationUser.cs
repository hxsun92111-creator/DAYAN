// User سفارشی Identity برای توسعه‌پذیری آینده.
// PasswordHash و اطلاعات احراز هویت همچنان توسط ASP.NET Core Identity مدیریت می‌شوند.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Infrastructure.Identity;

public class ApplicationUser : IdentityUser
{
    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

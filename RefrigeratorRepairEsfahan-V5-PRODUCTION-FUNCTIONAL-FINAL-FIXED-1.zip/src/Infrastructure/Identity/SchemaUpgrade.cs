// ارتقای کوچک و idempotent برای دیتابیس‌های Development قدیمی.
// چرا این فایل وجود دارد؟ چون نسخه‌های قبلی پروژه با EnsureCreated ساخته شده‌اند و
// EnsureCreated روی دیتابیس موجود ستون جدید اضافه نمی‌کند. این کد فقط فیلدهای جدید
// ثبت سفارش را در MySQL بررسی و در صورت نبودن اضافه می‌کند. هیچ ورودی کاربر در SQL قرار نمی‌گیرد.
using System.Data;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Infrastructure.Identity;

internal static class SchemaUpgrade
{
    public static async Task EnsureAsync(ApplicationDbContext db)
    {
        // فقط وقتی جدول سفارش وجود دارد ادامه می‌دهیم؛ در دیتابیس تازه EnsureCreated آن را ساخته است.
        if (!await TableExistsAsync(db, "RepairRequests"))
            return;

        await AddColumnIfMissingAsync(db, "ServiceCatalogId", "INT NULL");
        await AddColumnIfMissingAsync(db, "DeviceBrand", "VARCHAR(80) NULL");
        await AddColumnIfMissingAsync(db, "DeviceType", "VARCHAR(100) NULL");
        await AddColumnIfMissingAsync(db, "PreferredVisitDate", "DATE NULL");
        await AddColumnIfMissingAsync(db, "PreferredVisitWindow", "VARCHAR(80) NULL");

        await AddIndexIfMissingAsync(db, "IX_RepairRequests_ServiceCatalogId_CreatedAt",
            "CREATE INDEX `IX_RepairRequests_ServiceCatalogId_CreatedAt` ON `RepairRequests` (`ServiceCatalogId`, `CreatedAt`)");

        // اگر سفارش‌های نسخه قدیمی با [نام خدمت] ذخیره شده باشند، آن‌ها را به کاتالوگ واقعی وصل می‌کنیم.
        if (await TableExistsAsync(db, "Services"))
        {
            await ExecuteAsync(db, """
                UPDATE `RepairRequests` r
                INNER JOIN `Services` s ON r.`ProblemDescription` LIKE CONCAT('[', s.`Title`, ']%')
                SET r.`ServiceCatalogId` = s.`Id`
                WHERE r.`ServiceCatalogId` IS NULL
                """);

            await AddForeignKeyIfMissingAsync(db);
        }
    }

    private static async Task<bool> TableExistsAsync(ApplicationDbContext db, string table)
    {
        var connection = db.Database.GetDbConnection();
        if (connection.State != ConnectionState.Open)
            await connection.OpenAsync();

        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @table";
        var parameter = command.CreateParameter();
        parameter.ParameterName = "@table";
        parameter.Value = table;
        command.Parameters.Add(parameter);
        return Convert.ToInt32(await command.ExecuteScalarAsync()) > 0;
    }

    private static async Task<bool> ColumnExistsAsync(ApplicationDbContext db, string column)
    {
        var connection = db.Database.GetDbConnection();
        if (connection.State != ConnectionState.Open)
            await connection.OpenAsync();

        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'RepairRequests' AND COLUMN_NAME = @column";
        var parameter = command.CreateParameter();
        parameter.ParameterName = "@column";
        parameter.Value = column;
        command.Parameters.Add(parameter);
        return Convert.ToInt32(await command.ExecuteScalarAsync()) > 0;
    }

    private static async Task AddColumnIfMissingAsync(ApplicationDbContext db, string column, string sqlType)
    {
        if (!await ColumnExistsAsync(db, column))
            await ExecuteAsync(db, $"ALTER TABLE `RepairRequests` ADD COLUMN `{column}` {sqlType}");
    }

    private static async Task<bool> IndexExistsAsync(ApplicationDbContext db, string indexName)
    {
        var connection = db.Database.GetDbConnection();
        if (connection.State != ConnectionState.Open)
            await connection.OpenAsync();

        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'RepairRequests' AND INDEX_NAME = @indexName";
        var parameter = command.CreateParameter();
        parameter.ParameterName = "@indexName";
        parameter.Value = indexName;
        command.Parameters.Add(parameter);
        return Convert.ToInt32(await command.ExecuteScalarAsync()) > 0;
    }

    private static async Task AddIndexIfMissingAsync(ApplicationDbContext db, string indexName, string sql)
    {
        if (!await IndexExistsAsync(db, indexName))
            await ExecuteAsync(db, sql);
    }

    private static async Task AddForeignKeyIfMissingAsync(ApplicationDbContext db)
    {
        var connection = db.Database.GetDbConnection();
        if (connection.State != ConnectionState.Open)
            await connection.OpenAsync();

        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'RepairRequests' AND COLUMN_NAME = 'ServiceCatalogId' AND REFERENCED_TABLE_NAME = 'Services'";
        if (Convert.ToInt32(await command.ExecuteScalarAsync()) == 0)
            await ExecuteAsync(db, "ALTER TABLE `RepairRequests` ADD CONSTRAINT `FK_RepairRequests_Services_ServiceCatalogId` FOREIGN KEY (`ServiceCatalogId`) REFERENCES `Services` (`Id`) ON DELETE SET NULL");
    }

    private static async Task ExecuteAsync(ApplicationDbContext db, string sql)
        => await db.Database.ExecuteSqlRawAsync(sql);
}

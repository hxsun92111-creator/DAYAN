// SeedData فقط داده‌های اولیه محیط Development را می‌سازد.
// Password مدیر از Secret/Environment خوانده می‌شود و داخل Source Code ذخیره نمی‌شود.
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Infrastructure.Identity;

public static class SeedData
{
    public static async Task InitializeAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        var configuration = scope.ServiceProvider.GetRequiredService<IConfiguration>();

        // خدمات پایه سایت؛ فقط در صورت خالی بودن جدول ServiceCatalog ثبت می‌شوند.
        if (!await db.Services.AnyAsync())
        {
            db.Services.AddRange(
                new ServiceCatalog { Title = "تعمیر یخچال فریزر", ShortDescription = "عیب‌یابی و تعمیر در محل", IsActive = true },
                new ServiceCatalog { Title = "تعمیر ساید بای ساید", ShortDescription = "بررسی برد، کمپرسور و سرمایش", IsActive = true },
                new ServiceCatalog { Title = "شارژ گاز و رفع نشتی", ShortDescription = "سرویس مدار سرمایش", IsActive = true },
                new ServiceCatalog { Title = "عیب‌یابی و سرویس", ShortDescription = "تشخیص و سرویس دوره‌ای", IsActive = true });
            await db.SaveChangesAsync();
        }

        var roles = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

        foreach (var role in new[] { AppRoles.Admin, AppRoles.Technician, AppRoles.Customer })
        {
            if (!await roles.RoleExistsAsync(role))
            {
                await roles.CreateAsync(new IdentityRole(role));
            }
        }

        var users = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var admin = await users.FindByNameAsync("admin");

        if (admin is null)
        {
            var password = configuration["SeedAdmin:Password"];

            if (string.IsNullOrWhiteSpace(password))
            {
                throw new InvalidOperationException(
                    "SeedAdmin:Password برای Development تنظیم نشده است. آن را در User Secrets قرار دهید.");
            }

            admin = new ApplicationUser
            {
                UserName = "admin",
                Email = "admin@localhost",
                EmailConfirmed = true,
                IsActive = true
            };

            var result = await users.CreateAsync(admin, password);

            if (!result.Succeeded)
            {
                var errors = string.Join(" | ", result.Errors.Select(x => x.Description));
                throw new InvalidOperationException($"ساخت Admin توسعه ناموفق بود: {errors}");
            }

            await users.AddToRoleAsync(admin, AppRoles.Admin);
        }

        if (admin is not null && !await db.AdminProfiles.AnyAsync(x => x.UserId == admin.Id))
        {
            db.AdminProfiles.Add(new AdminProfile
            {
                UserId = admin.Id,
                DisplayName = "مدیر اصلی",
                IsActive = true
            });

            await db.SaveChangesAsync();
        }
    }
}

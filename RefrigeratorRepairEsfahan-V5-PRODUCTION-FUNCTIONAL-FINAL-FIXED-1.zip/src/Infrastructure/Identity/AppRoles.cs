// Roleهای سیستم در یک محل مرکزی تعریف می‌شوند تا خطای تایپی در Policyها و عملیات Identity کم شود.
namespace RefrigeratorRepair.Infrastructure.Identity;

public static class AppRoles
{
    public const string Admin = "Admin";
    public const string Technician = "Technician";
    public const string Customer = "Customer";
}

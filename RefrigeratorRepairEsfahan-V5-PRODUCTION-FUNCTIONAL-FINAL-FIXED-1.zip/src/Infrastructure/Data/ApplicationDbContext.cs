// DbContext پل بین Domain و MySQL است. فقط Infrastructure مستقیماً EF Core را می‌شناسد.
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Infrastructure.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
    : IdentityDbContext<ApplicationUser>(options)
{
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<AdminProfile> AdminProfiles => Set<AdminProfile>();
    public DbSet<RepairRequest> RepairRequests => Set<RepairRequest>();
    public DbSet<Technician> Technicians => Set<Technician>();
    public DbSet<RepairJob> RepairJobs => Set<RepairJob>();
    public DbSet<RepairPart> RepairParts => Set<RepairPart>();
    public DbSet<TechnicianOffer> TechnicianOffers => Set<TechnicianOffer>();
    public DbSet<TechnicianDocument> TechnicianDocuments => Set<TechnicianDocument>();
    public DbSet<WalletTransaction> WalletTransactions => Set<WalletTransaction>();
    public DbSet<PaymentTransaction> PaymentTransactions => Set<PaymentTransaction>();
    public DbSet<ServiceCatalog> Services => Set<ServiceCatalog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // -------------------------------------------------------
        // طول فیلدهای متنی
        // -------------------------------------------------------
        b.Entity<Customer>(e =>
        {
            e.Property(x => x.FirstName).HasMaxLength(80).IsRequired();
            e.Property(x => x.LastName).HasMaxLength(100).IsRequired();
            e.Property(x => x.PhoneNumber).HasMaxLength(20).IsRequired();
            e.Property(x => x.UserId).HasMaxLength(450);
            e.HasIndex(x => x.PhoneNumber).IsUnique();
            e.HasIndex(x => x.UserId).IsUnique();
        });

        b.Entity<Technician>(e =>
        {
            e.Property(x => x.UserId).HasMaxLength(450).IsRequired();
            e.Property(x => x.FirstName).HasMaxLength(80).IsRequired();
            e.Property(x => x.LastName).HasMaxLength(100).IsRequired();
            e.Property(x => x.NationalId).HasMaxLength(10).IsRequired();
            e.Property(x => x.PhoneNumber).HasMaxLength(20).IsRequired();
            e.Property(x => x.Address).HasMaxLength(1000).IsRequired();
            e.Property(x => x.Specialization).HasMaxLength(200).IsRequired();
            e.Property(x => x.ProfilePhotoPath).HasMaxLength(500);

            e.HasIndex(x => x.NationalId).IsUnique();
            e.HasIndex(x => x.UserId).IsUnique();
            e.HasIndex(x => new { x.AccountStatus, x.Availability });
        });

        b.Entity<AdminProfile>(e =>
        {
            e.Property(x => x.UserId).HasMaxLength(450).IsRequired();
            e.Property(x => x.DisplayName).HasMaxLength(150).IsRequired();
            e.HasIndex(x => x.UserId).IsUnique();
        });

        b.Entity<RepairRequest>(e =>
        {
            e.Property(x => x.TrackingCode).HasMaxLength(50).IsRequired();
            e.Property(x => x.DeviceBrand).HasMaxLength(80);
            e.Property(x => x.DeviceType).HasMaxLength(100);
            e.Property(x => x.PreferredVisitWindow).HasMaxLength(80);
            e.Property(x => x.PreferredVisitDate).HasColumnType("date");
            e.Property(x => x.ProblemDescription).HasMaxLength(1000).IsRequired();
            e.Property(x => x.Address).HasMaxLength(1000).IsRequired();
            e.Property(x => x.Latitude).HasPrecision(9, 6);
            e.Property(x => x.Longitude).HasPrecision(9, 6);

            e.HasIndex(x => x.TrackingCode).IsUnique();
            e.HasIndex(x => new { x.ServiceCatalogId, x.CreatedAt });
            e.HasIndex(x => new { x.Status, x.CreatedAt });
            e.HasIndex(x => new { x.AssignedTechnicianId, x.Status });

            e.HasOne(x => x.Customer)
                .WithMany(x => x.Requests)
                .HasForeignKey(x => x.CustomerId)
                .OnDelete(DeleteBehavior.Restrict);

            // ارتباط سفارش با کاتالوگ خدمت؛ اگر خدمت بعداً غیرفعال شود،
            // سفارش‌های قدیمی همچنان عنوان/شناسه خدمت خود را حفظ می‌کنند.
            e.HasOne(x => x.ServiceCatalog)
                .WithMany()
                .HasForeignKey(x => x.ServiceCatalogId)
                .OnDelete(DeleteBehavior.SetNull);

            e.HasOne(x => x.AssignedTechnician)
                .WithMany()
                .HasForeignKey(x => x.AssignedTechnicianId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<RepairJob>(e =>
        {
            e.Property(x => x.ServiceDescription).HasMaxLength(2000);
            e.Property(x => x.TechnicianDiagnosis).HasMaxLength(3000);
            ConfigureMoney(e.Property(x => x.TravelCost));
            ConfigureMoney(e.Property(x => x.LaborCost));
            ConfigureMoney(e.Property(x => x.CustomerTotal));
            ConfigureMoney(e.Property(x => x.PartsCost));
            ConfigureMoney(e.Property(x => x.NetProfitBase));
            ConfigureMoney(e.Property(x => x.CommissionAmount));

            e.HasOne(x => x.Request)
                .WithOne(x => x.RepairJob)
                .HasForeignKey<RepairJob>(x => x.RepairRequestId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.Technician)
                .WithMany(x => x.Jobs)
                .HasForeignKey(x => x.TechnicianId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<RepairPart>(e =>
        {
            e.Property(x => x.PartName).HasMaxLength(200).IsRequired();
            e.Property(x => x.Quantity).IsRequired();
            ConfigureMoney(e.Property(x => x.UnitPrice));

            e.HasOne(x => x.RepairJob)
                .WithMany(x => x.Parts)
                .HasForeignKey(x => x.RepairJobId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<TechnicianOffer>(e =>
        {
            e.HasIndex(x => new { x.RepairRequestId, x.TechnicianId }).IsUnique();
            e.HasIndex(x => new { x.TechnicianId, x.SentAt });
            e.HasIndex(x => new { x.Status, x.ExpiresAt });

            e.HasOne(x => x.Request)
                .WithMany(x => x.Offers)
                .HasForeignKey(x => x.RepairRequestId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.Technician)
                .WithMany(x => x.Offers)
                .HasForeignKey(x => x.TechnicianId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<TechnicianDocument>(e =>
        {
            e.Property(x => x.DocumentType).HasMaxLength(100).IsRequired();
            e.Property(x => x.FilePath).HasMaxLength(500).IsRequired();

            e.HasIndex(x => new { x.TechnicianId, x.DocumentType });

            e.HasOne(x => x.Technician)
                .WithMany(x => x.Documents)
                .HasForeignKey(x => x.TechnicianId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<WalletTransaction>(e =>
        {
            e.Property(x => x.Description).HasMaxLength(500).IsRequired();
            ConfigureMoney(e.Property(x => x.Amount));
            ConfigureMoney(e.Property(x => x.BalanceAfter));

            e.HasIndex(x => new { x.TechnicianId, x.CreatedAt });
            e.HasIndex(x => x.PaymentTransactionId).IsUnique();

            // هر Job حداکثر یک CommissionDebit دارد؛ این Unique Index
            // یک لایه دفاعی دیتابیسی در برابر دوبار کسر شدن کمیسیون است.
            e.HasIndex(x => x.RepairJobId)
                .IsUnique();

            e.HasOne(x => x.Technician)
                .WithMany(x => x.WalletTransactions)
                .HasForeignKey(x => x.TechnicianId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x => x.PaymentTransaction)
                .WithMany(x => x.WalletTransactions)
                .HasForeignKey(x => x.PaymentTransactionId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<PaymentTransaction>(e =>
        {
            e.Property(x => x.Authority).HasMaxLength(200);
            e.Property(x => x.ReferenceId).HasMaxLength(200);
            ConfigureMoney(e.Property(x => x.Amount));

            // Authority درگاه باید یکتا باشد. Nullable بودن آن برای Pending
            // مشکلی ایجاد نمی‌کند چون MySQL چند NULL را در Unique Index می‌پذیرد.
            e.HasIndex(x => x.Authority).IsUnique();
            e.HasIndex(x => new { x.TechnicianId, x.CreatedAt });

            e.HasOne(x => x.Technician)
                .WithMany(x => x.PaymentTransactions)
                .HasForeignKey(x => x.TechnicianId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<ServiceCatalog>(e =>
        {
            // نام جدول را صریحاً ثابت می‌کنیم تا با Migration و SeedData یکسان بماند.
            e.ToTable("Services");
            e.Property(x => x.Title).HasMaxLength(150).IsRequired();
            e.Property(x => x.ShortDescription).HasMaxLength(1000).IsRequired();
            e.HasIndex(x => new { x.IsActive, x.Title });
        });
    }

    private static void ConfigureMoney(PropertyBuilder<decimal> property)
    {
        property.HasPrecision(18, 2);
    }
}

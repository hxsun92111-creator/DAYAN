// PageModel فرم ثبت سفارش.
// نکته آموزشی: UI فقط اطلاعات را جمع می‌کند؛ اعتبارسنجی اصلی و ثبت دیتابیس
// در سمت سرور و در Application Service انجام می‌شود تا JavaScript قابل اعتماد فرض نشود.
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RefrigeratorRepair.Application.DTOs;
using RefrigeratorRepair.Application.Interfaces;

namespace RefrigeratorRepair.Web.Pages;

public sealed class ServicesModel(
    IRepairRequestService service,
    ICustomerRepository customers,
    IServiceCatalogRepository serviceCatalog) : PageModel
{
    public sealed record ServiceOption(int Id, string Title, string Description, string Icon);

    public List<ServiceOption> ServiceOptions { get; private set; } = [];

    // بازه‌های مجاز از پیش تعریف شده‌اند تا مقدار دلخواه از مرورگر وارد دیتابیس نشود.
    public static IReadOnlyList<string> VisitWindows { get; } =
    [
        "صبح ۹ تا ۱۲",
        "ظهر ۱۲ تا ۱۵",
        "عصر ۱۵ تا ۱۸",
        "شب ۱۸ تا ۲۱"
    ];

    [BindProperty]
    public CreateRepairRequestDto Input { get; set; } = new()
    {
        Latitude = 32.6546m,
        Longitude = 51.6680m,
        PreferredVisitWindow = VisitWindows[0]
    };

    [BindProperty]
    public int SelectedServiceId { get; set; }

    public bool Success { get; private set; }
    public bool ReturningCustomer { get; private set; }
    public string? Ticket { get; private set; }

    public async Task OnGetAsync(string? service, CancellationToken ct)
    {
        await LoadServicesAsync(ct);

        // لینک‌های صفحه اصلی عنوان خدمت را می‌فرستند؛ در اینجا آن عنوان به ID واقعی جدول تبدیل می‌شود.
        if (!string.IsNullOrWhiteSpace(service))
        {
            var selected = ServiceOptions.FirstOrDefault(x => x.Title == service);
            if (selected is not null)
                SelectedServiceId = selected.Id;
        }
    }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        await LoadServicesAsync(ct);

        // مقدار انتخاب‌شده در UI باید قبل از اعتبارسنجی به DTO منتقل شود.
        Input.ServiceCatalogId = SelectedServiceId;
        ModelState.Remove("Input.ServiceCatalogId");

        var selectedService = ServiceOptions.FirstOrDefault(x => x.Id == SelectedServiceId);
        if (selectedService is null)
            ModelState.AddModelError(nameof(SelectedServiceId), "لطفاً یک خدمت معتبر انتخاب کنید.");

        if (Input.PreferredVisitDate is not null && Input.PreferredVisitDate.Value.Date < DateTime.Today)
            ModelState.AddModelError("Input.PreferredVisitDate", "تاریخ مراجعه نمی‌تواند در گذشته باشد.");

        if (!string.IsNullOrWhiteSpace(Input.PreferredVisitWindow) &&
            !VisitWindows.Contains(Input.PreferredVisitWindow, StringComparer.Ordinal))
            ModelState.AddModelError("Input.PreferredVisitWindow", "بازه زمانی انتخاب‌شده معتبر نیست.");

        if (!ModelState.IsValid)
            return Page();

        ReturningCustomer = await customers.FindByPhoneAsync(NormalizePhone(Input.PhoneNumber), ct) is not null;

        // Application Service دوباره ServiceCatalogId را از دیتابیس بررسی می‌کند.
        // بنابراین حتی اگر کاربر POST را دستی تغییر دهد، خدمت جعلی ثبت نمی‌شود.
        var result = await service.CreateAsync(Input, ct);
        if (!result.Success)
        {
            ModelState.AddModelError(string.Empty, result.Error ?? "ثبت درخواست انجام نشد.");
            return Page();
        }

        Success = true;
        Ticket = result.Value;
        return Page();
    }

    private async Task LoadServicesAsync(CancellationToken ct)
    {
        var services = await serviceCatalog.GetActiveAsync(ct);
        ServiceOptions = services.Select(x => new ServiceOption(
            x.Id,
            x.Title,
            x.ShortDescription,
            GetIcon(x.Title))).ToList();
    }

    private static string GetIcon(string title) => title switch
    {
        "تعمیر یخچال فریزر" => "bi bi-box-seam",
        "تعمیر ساید بای ساید" => "bi bi-layout-split",
        "شارژ گاز و رفع نشتی" => "bi bi-snow2",
        "عیب‌یابی و سرویس" => "bi bi-wrench-adjustable-circle",
        _ => "bi bi-tools"
    };

    private static string NormalizePhone(string value)
    {
        var phone = value.Trim()
            .Replace("۰", "0").Replace("۱", "1").Replace("۲", "2").Replace("۳", "3")
            .Replace("۴", "4").Replace("۵", "5").Replace("۶", "6").Replace("۷", "7")
            .Replace("۸", "8").Replace("۹", "9");

        if (phone.StartsWith("+98", StringComparison.Ordinal))
            phone = "0" + phone[3..];
        else if (phone.StartsWith("0098", StringComparison.Ordinal))
            phone = "0" + phone[4..];

        return phone;
    }
}

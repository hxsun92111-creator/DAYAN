using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Web.Pages.Account;

[Authorize(Roles = AppRoles.Customer)]
public sealed class ProfileModel(UserManager<ApplicationUser> users, ApplicationDbContext db) : PageModel
{
    public CustomerInfo? Customer { get; set; }
    public List<OrderInfo> Orders { get; set; } = [];
    public sealed record CustomerInfo(string FirstName, string LastName, string Phone, string Email);
    public sealed record OrderInfo(string TrackingCode, string Service, string Status, DateTime CreatedAt);

    public async Task OnGetAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return;
        var customer = await db.Customers.AsNoTracking().SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (customer is null) return;
        Customer = new(customer.FirstName, customer.LastName, customer.PhoneNumber, user.Email ?? "—");
        Orders = await db.RepairRequests.AsNoTracking().Where(x => x.CustomerId == customer.Id).OrderByDescending(x => x.CreatedAt).Take(10)
            .Select(x => new OrderInfo(x.TrackingCode, x.ServiceCatalog != null ? x.ServiceCatalog.Title : "خدمت", x.Status.ToString(), x.CreatedAt)).ToListAsync(ct);
    }
}

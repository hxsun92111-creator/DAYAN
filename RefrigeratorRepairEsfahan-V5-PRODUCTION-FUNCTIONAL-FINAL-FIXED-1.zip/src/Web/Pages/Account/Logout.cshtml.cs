// PageModel منطق پشت همین Razor Page را نگهداری می‌کند؛ UI در فایل .cshtml است.
// متدهایی مثل OnGet و OnPost با چرخه درخواست HTTP/Razor Pages اجرا می‌شوند.

using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity; using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.RazorPages;
namespace RefrigeratorRepair.Web.Pages;
// خروج امن از حساب Identity.
public class LogoutModel(SignInManager<ApplicationUser> signInManager):PageModel { public async Task<IActionResult> OnPostAsync(){await signInManager.SignOutAsync();return RedirectToPage("/Index");} }

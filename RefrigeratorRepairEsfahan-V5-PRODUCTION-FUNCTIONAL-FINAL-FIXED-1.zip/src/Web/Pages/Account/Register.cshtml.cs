using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Web.Pages.Account;

// ثبت‌نام مشتری؛ حساب مشتری فقط برای مشاهده سفارش‌ها و پروفایل خودش استفاده می‌شود.
public sealed class RegisterModel(
    UserManager<ApplicationUser> users,
    SignInManager<ApplicationUser> signIn,
    ApplicationDbContext db) : PageModel
{
    [BindProperty] public InputModel Input { get; set; } = new();

    public sealed class InputModel
    {
        [Required, MaxLength(80)] public string FirstName { get; set; } = "";
        [Required, MaxLength(100)] public string LastName { get; set; } = "";
        [Required, Phone, MaxLength(20)] public string PhoneNumber { get; set; } = "";
        [Required, EmailAddress, MaxLength(256)] public string Email { get; set; } = "";
        [Required, StringLength(100, MinimumLength = 12)] public string Password { get; set; } = "";
        [Required, Compare(nameof(Password))] public string ConfirmPassword { get; set; } = "";
    }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        if (!ModelState.IsValid) return Page();

        var phone = NormalizePhone(Input.PhoneNumber);
        if (await db.Customers.AnyAsync(x => x.PhoneNumber == phone, ct))
        {
            ModelState.AddModelError(nameof(Input.PhoneNumber), "این شماره قبلاً ثبت شده است.");
            return Page();
        }

        var user = new ApplicationUser
        {
            UserName = phone,
            PhoneNumber = phone,
            Email = Input.Email.Trim(),
            EmailConfirmed = false,
            IsActive = true
        };

        var created = await users.CreateAsync(user, Input.Password);
        if (!created.Succeeded)
        {
            foreach (var error in created.Errors)
                ModelState.AddModelError(string.Empty, error.Description);
            return Page();
        }

        await users.AddToRoleAsync(user, AppRoles.Customer);
        db.Customers.Add(new Customer
        {
            UserId = user.Id,
            FirstName = Input.FirstName.Trim(),
            LastName = Input.LastName.Trim(),
            PhoneNumber = phone,
            CreatedAt = DateTime.UtcNow,
            LastOrderAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync(ct);
        await signIn.SignInAsync(user, isPersistent: false);

        return RedirectToPage("/Index");
    }

    private static string NormalizePhone(string value)
    {
        var phone = value.Trim().Replace("۰", "0").Replace("۱", "1").Replace("۲", "2")
            .Replace("۳", "3").Replace("۴", "4").Replace("۵", "5").Replace("۶", "6")
            .Replace("۷", "7").Replace("۸", "8").Replace("۹", "9");
        if (phone.StartsWith("+98", StringComparison.Ordinal)) phone = "0" + phone[3..];
        if (phone.StartsWith("0098", StringComparison.Ordinal)) phone = "0" + phone[4..];
        return phone;
    }
}

// صفحه ورود مشترک مدیر/تکنسین.
// Radio فقط انتخاب مسیر UI است؛ مجوز واقعی از Role و وضعیت حساب خوانده می‌شود.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Account;

[EnableRateLimiting("Auth")]
public class LoginModel(
    SignInManager<ApplicationUser> signInManager,
    UserManager<ApplicationUser> users,
    ApplicationDbContext db) : PageModel
{
    [BindProperty]
    public InputModel Input { get; set; } = new();

    public class InputModel
    {
        [Required] public string UserName { get; set; } = "";
        [Required] public string Password { get; set; } = "";
        [Required] public string AccountType { get; set; } = "Technician";
    }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        if (!ModelState.IsValid)
            return Page();

        var user = await users.FindByNameAsync(Input.UserName);
        if (user is null)
        {
            ModelState.AddModelError("", "نام کاربری یا رمز عبور صحیح نیست.");
            return Page();
        }

        var signIn = await signInManager.PasswordSignInAsync(
            user,
            Input.Password,
            isPersistent: false,
            lockoutOnFailure: true);

        if (!signIn.Succeeded)
        {
            ModelState.AddModelError("", "نام کاربری یا رمز عبور صحیح نیست یا حساب قفل شده است.");
            return Page();
        }

        if (!user.IsActive)
        {
            await signInManager.SignOutAsync();
            ModelState.AddModelError("", "این حساب غیرفعال است.");
            return Page();
        }

        if (Input.AccountType == "Admin")
        {
            if (!await users.IsInRoleAsync(user, AppRoles.Admin))
            {
                await signInManager.SignOutAsync();
                ModelState.AddModelError("", "این حساب دسترسی مدیر ندارد.");
                return Page();
            }

            var admin = await db.AdminProfiles.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
            if (admin is not null && !admin.IsActive)
            {
                await signInManager.SignOutAsync();
                ModelState.AddModelError("", "حساب مدیر غیرفعال است.");
                return Page();
            }

            return RedirectToPage("/Admin/Index");
        }

        if (Input.AccountType == "Customer")
        {
            if (!await users.IsInRoleAsync(user, AppRoles.Customer))
            {
                await signInManager.SignOutAsync();
                ModelState.AddModelError("", "این حساب مشتری نیست.");
                return Page();
            }

            return RedirectToPage("/Index");
        }

        if (Input.AccountType == "Technician")
        {
            var technician = await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);

            if (technician is null || !await users.IsInRoleAsync(user, AppRoles.Technician))
            {
                await signInManager.SignOutAsync();
                ModelState.AddModelError("", "این حساب تکنسین تأیید نشده است.");
                return Page();
            }

            if (technician.AccountStatus != TechnicianAccountStatus.Active)
            {
                await signInManager.SignOutAsync();
                ModelState.AddModelError("", "حساب شما هنوز توسط مدیر تأیید نشده یا مسدود شده است.");
                return Page();
            }

            return RedirectToPage("/Technician/Index");
        }

        await signInManager.SignOutAsync();
        ModelState.AddModelError("", "نوع حساب نامعتبر است.");
        return Page();
    }
}

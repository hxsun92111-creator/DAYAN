// ثبت‌نام عمومی تکنسین.
// حساب Identity ساخته می‌شود اما تا تأیید مدیر، امکان ورود عملیاتی ندارد.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RefrigeratorRepair.Application.DTOs;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages;

public class TechnicianRegisterModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users,
    ILogger<TechnicianRegisterModel> logger) : PageModel
{
    [BindProperty]
    public TechnicianRegistrationDto Input { get; set; } = new();

    [BindProperty]
    public IFormFile? NationalCardFile { get; set; }

    [BindProperty]
    public IFormFile? ExperienceDocumentFile { get; set; }

    [BindProperty]
    public IFormFile? ProfilePhotoFile { get; set; }

    public bool Success { get; private set; }
    public string? TrackingMessage { get; private set; }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        if (!ModelState.IsValid)
            return Page();

        Input.NationalId = NormalizeDigits(Input.NationalId).Trim();
        Input.PhoneNumber = NormalizePhone(Input.PhoneNumber);

        if (Input.NationalId.Length != 10 || !Input.NationalId.All(char.IsDigit))
        {
            ModelState.AddModelError("Input.NationalId", "کد ملی باید ۱۰ رقم باشد.");
            return Page();
        }

        if (!IsValidIranianMobile(Input.PhoneNumber))
        {
            ModelState.AddModelError("Input.PhoneNumber", "شماره موبایل معتبر نیست.");
            return Page();
        }

        if (NationalCardFile is null || NationalCardFile.Length == 0)
            ModelState.AddModelError(nameof(NationalCardFile), "تصویر کارت ملی الزامی است.");

        if (ExperienceDocumentFile is null || ExperienceDocumentFile.Length == 0)
            ModelState.AddModelError(nameof(ExperienceDocumentFile), "مدرک یا سابقه مهارت الزامی است.");

        if (!ModelState.IsValid)
            return Page();

        if (await db.Technicians.AnyAsync(x => x.NationalId == Input.NationalId, ct))
        {
            ModelState.AddModelError("", "این کد ملی قبلاً در سیستم ثبت شده است.");
            return Page();
        }

        // برای جلوگیری از ثبت چند حساب Identity با یک کد ملی، Username همان کد ملی است.
        if (await users.FindByNameAsync(Input.NationalId) is not null)
        {
            ModelState.AddModelError("", "برای این کد ملی قبلاً حساب کاربری ساخته شده است.");
            return Page();
        }

        await using var transaction = await db.Database.BeginTransactionAsync(ct);

        try
        {
            var identityUser = new ApplicationUser
            {
                UserName = Input.NationalId,
                PhoneNumber = Input.PhoneNumber
            };

            var createResult = await users.CreateAsync(identityUser, Input.Password);

            if (!createResult.Succeeded)
            {
                foreach (var error in createResult.Errors)
                    ModelState.AddModelError("", error.Description);

                await transaction.RollbackAsync(ct);
                return Page();
            }

            var technician = new Technician
            {
                UserId = identityUser.Id,
                FirstName = Input.FirstName,
                LastName = Input.LastName,
                NationalId = Input.NationalId,
                PhoneNumber = Input.PhoneNumber,
                Address = Input.Address,
                ExperienceYears = Input.ExperienceYears,
                Specialization = Input.Specialization,
                AccountStatus = TechnicianAccountStatus.PendingApproval,
                Availability = TechnicianAvailability.PendingApproval
            };

            db.Technicians.Add(technician);
            await db.SaveChangesAsync(ct);

            technician.ProfilePhotoPath = await SavePrivateFileAsync(ProfilePhotoFile, "ProfilePhotos", ct);

            // مدارک در wwwroot قرار نمی‌گیرند؛ فایل عمومی نباید مستقیماً قابل دانلود باشد.
            await SaveDocumentAsync(technician.Id, NationalCardFile, "کارت ملی", ct);
            await SaveDocumentAsync(technician.Id, ExperienceDocumentFile, "سابقه یا مدرک مهارت", ct);

            await db.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);

            Success = true;
            TrackingMessage = "ثبت‌نام شما دریافت شد و پس از بررسی مدیر، نتیجه اعلام می‌شود.";
            return Page();
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync(ct);
            logger.LogError(ex, "Technician registration failed.");
            ModelState.AddModelError("", "ثبت‌نام انجام نشد. لطفاً اطلاعات را بررسی و دوباره تلاش کنید.");
            return Page();
        }
    }

    private static string NormalizeDigits(string value)
        => value.Trim()
            .Replace("۰", "0").Replace("۱", "1").Replace("۲", "2")
            .Replace("۳", "3").Replace("۴", "4").Replace("۵", "5")
            .Replace("۶", "6").Replace("۷", "7").Replace("۸", "8")
            .Replace("۹", "9");

    private static string NormalizePhone(string value)
    {
        var phone = NormalizeDigits(value);
        if (phone.StartsWith("+98", StringComparison.Ordinal))
            phone = "0" + phone[3..];
        else if (phone.StartsWith("0098", StringComparison.Ordinal))
            phone = "0" + phone[4..];
        return phone;
    }

    private static bool IsValidIranianMobile(string phone)
        => phone.Length == 11 && phone.StartsWith("09", StringComparison.Ordinal) && phone.All(char.IsDigit);

    private async Task<string?> SavePrivateFileAsync(IFormFile? file, string folder, CancellationToken ct)
    {
        if (file is null || file.Length == 0) return null;
        const long maxPhotoBytes = 5 * 1024 * 1024;
        if (file.Length > maxPhotoBytes)
            throw new InvalidOperationException("حجم عکس پروفایل نباید بیشتر از ۵ مگابایت باشد.");

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        var allowed = new[] { ".jpg", ".jpeg", ".png" };
        if (!allowed.Contains(extension) || !await HasExpectedSignatureAsync(file, extension, ct)) throw new InvalidOperationException("فرمت تصویر مجاز نیست.");
        var root = Path.Combine(AppContext.BaseDirectory, "App_Data", folder);
        Directory.CreateDirectory(root);
        var physicalPath = Path.Combine(root, $"{Guid.NewGuid():N}{extension}");
        await using var stream = System.IO.File.Create(physicalPath);
        await file.CopyToAsync(stream, ct);
        return physicalPath;
    }

    private static async Task<bool> HasExpectedSignatureAsync(IFormFile file, string extension, CancellationToken ct)
    {
        await using var stream = file.OpenReadStream();
        var header = new byte[8];
        var read = await stream.ReadAsync(header, ct);

        return extension switch
        {
            ".pdf" => read >= 4 && header[0] == 0x25 && header[1] == 0x50 && header[2] == 0x44 && header[3] == 0x46,
            ".png" => read >= 8 && header.SequenceEqual(new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A }),
            ".jpg" or ".jpeg" => read >= 3 && header[0] == 0xFF && header[1] == 0xD8 && header[2] == 0xFF,
            _ => false
        };
    }

    private async Task SaveDocumentAsync(
        int technicianId,
        IFormFile? file,
        string documentType,
        CancellationToken ct)
    {
        if (file is null || file.Length == 0)
            return;

        // در Production بهتر است StorageService و Antivirus/Content Validation جدا داشته باشیم.
        var root = Path.Combine(AppContext.BaseDirectory, "App_Data", "TechnicianDocuments");
        Directory.CreateDirectory(root);

        const long maxDocumentBytes = 10 * 1024 * 1024;
        if (file.Length > maxDocumentBytes)
            throw new InvalidOperationException("حجم مدرک نباید بیشتر از ۱۰ مگابایت باشد.");

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        var allowed = new[] { ".jpg", ".jpeg", ".png", ".pdf" };

        if (!allowed.Contains(extension) || !await HasExpectedSignatureAsync(file, extension, ct))
            throw new InvalidOperationException("فرمت مدرک مجاز نیست. فقط JPG، PNG و PDF پذیرفته می‌شود.");

        var safeName = $"{Guid.NewGuid():N}{extension}";
        var physicalPath = Path.Combine(root, safeName);

        await using (var stream = System.IO.File.Create(physicalPath))
            await file.CopyToAsync(stream, ct);

        db.TechnicianDocuments.Add(new TechnicianDocument
        {
            TechnicianId = technicianId,
            DocumentType = documentType,
            FilePath = physicalPath
        });
    }
}

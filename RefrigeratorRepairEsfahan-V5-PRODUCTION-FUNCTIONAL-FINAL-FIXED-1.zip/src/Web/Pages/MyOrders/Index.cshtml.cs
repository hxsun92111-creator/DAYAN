using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.MyOrders;

public sealed class IndexModel(ApplicationDbContext db) : PageModel
{
    [BindProperty(SupportsGet = true)] public string? Ticket { get; set; }
    [BindProperty(SupportsGet = true)] public string? Phone { get; set; }
    public bool SearchPerformed { get; private set; }
    public OrderView? Order { get; private set; }

    public async Task OnGetAsync(CancellationToken ct)
    {
        SearchPerformed = !string.IsNullOrWhiteSpace(Ticket) || !string.IsNullOrWhiteSpace(Phone);
        if (!SearchPerformed || string.IsNullOrWhiteSpace(Ticket) || string.IsNullOrWhiteSpace(Phone)) return;

        var phone = NormalizePhone(Phone);
        var request = await db.RepairRequests
            .AsNoTracking()
            .Include(x => x.Customer)
            .Include(x => x.ServiceCatalog)
            .Include(x => x.AssignedTechnician)
            .SingleOrDefaultAsync(x => x.TrackingCode == Ticket.Trim() && x.Customer.PhoneNumber == phone, ct);

        if (request is null) return;

        Order = new OrderView
        {
            TrackingCode = request.TrackingCode,
            CustomerName = $"{request.Customer.FirstName} {request.Customer.LastName}",
            Phone = request.Customer.PhoneNumber,
            Address = request.Address,
            ProblemDescription = request.ProblemDescription,
            ServiceTitle = request.ServiceCatalog?.Title ?? "خدمت ثبت‌شده",
            DeviceBrand = request.DeviceBrand ?? "-",
            DeviceType = request.DeviceType ?? "-",
            PreferredVisitDate = request.PreferredVisitDate,
            PreferredVisitWindow = request.PreferredVisitWindow,
            TechnicianName = request.AssignedTechnician is null ? null : $"{request.AssignedTechnician.FirstName} {request.AssignedTechnician.LastName}",
            StatusText = ToStatusText(request.Status),
            CreatedAt = request.CreatedAt,
            Steps = BuildSteps(request.Status)
        };
    }

    public sealed class OrderView
    {
        public string TrackingCode { get; init; } = "";
        public string CustomerName { get; init; } = "";
        public string Phone { get; init; } = "";
        public string Address { get; init; } = "";
        public string ProblemDescription { get; init; } = "";
        public string ServiceTitle { get; init; } = "";
        public string DeviceBrand { get; init; } = "";
        public string DeviceType { get; init; } = "";
        public DateTime? PreferredVisitDate { get; init; }
        public string? PreferredVisitWindow { get; init; }
        public string? TechnicianName { get; init; }
        public string StatusText { get; init; } = "";
        public DateTime CreatedAt { get; init; }
        public List<TrackingStep> Steps { get; init; } = [];
    }

    public sealed record TrackingStep(string Title, string Description, bool IsDone, bool IsCurrent);

    private static List<TrackingStep> BuildSteps(RepairRequestStatus status)
    {
        var current = status switch
        {
            RepairRequestStatus.New => 1,
            RepairRequestStatus.WaitingForAssignment => 2,
            RepairRequestStatus.Assigned => 3,
            RepairRequestStatus.TechnicianOnTheWay => 4,
            RepairRequestStatus.InProgress => 5,
            RepairRequestStatus.Completed => 6,
            _ => 1
        };

        var titles = new[]
        {
            ("ثبت درخواست", "درخواست شما با موفقیت ثبت شده است."),
            ("در انتظار پذیرش", "درخواست برای تکنسین‌های واجد شرایط ارسال شده است."),
            ("تکنسین انتخاب شد", "هماهنگی و آماده‌سازی سفارش در حال انجام است."),
            ("تکنسین در مسیر", "تکنسین برای حضور در محل در حال حرکت است."),
            ("در حال تعمیر", "فرایند عیب‌یابی و تعمیر در محل انجام می‌شود."),
            ("تکمیل شد", "تعمیر با موفقیت به پایان رسیده است.")
        };

        return titles.Select((x, i) => new TrackingStep(x.Item1, x.Item2, i + 1 < current || status == RepairRequestStatus.Completed, i + 1 == current)).ToList();
    }

    private static string ToStatusText(RepairRequestStatus status) => status switch
    {
        RepairRequestStatus.New => "ثبت شده",
        RepairRequestStatus.WaitingForAssignment => "در انتظار تکنسین",
        RepairRequestStatus.Assigned => "تکنسین انتخاب شد",
        RepairRequestStatus.TechnicianOnTheWay => "تکنسین در مسیر",
        RepairRequestStatus.InProgress => "در حال تعمیر",
        RepairRequestStatus.Completed => "تکمیل شده",
        RepairRequestStatus.Cancelled => "لغو شده",
        _ => status.ToString()
    };

    private static string NormalizePhone(string value)
    {
        var phone = value.Trim()
            .Replace("۰", "0").Replace("۱", "1").Replace("۲", "2").Replace("۳", "3")
            .Replace("۴", "4").Replace("۵", "5").Replace("۶", "6").Replace("۷", "7")
            .Replace("۸", "8").Replace("۹", "9");
        if (phone.StartsWith("+98", StringComparison.Ordinal)) phone = "0" + phone[3..];
        else if (phone.StartsWith("0098", StringComparison.Ordinal)) phone = "0" + phone[4..];
        return phone;
    }
}

// مدیریت مدیران سیستم.
// نکته امنیتی: این صفحه هیچ Password را در جدول سفارشی ذخیره نمی‌کند.
// ASP.NET Core Identity مسئول PasswordHash، Lockout و Authentication است.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.AdminUsers;

public class IndexModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users) : PageModel
{
    [BindProperty]
    public InputModel Input { get; set; } = new();

    public List<Row> Items { get; set; } = new();

    public sealed class InputModel
    {
        public string UserName { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public string Password { get; set; } = "";
    }

    public sealed class Row
    {
        public string UserName { get; init; } = "";
        public string DisplayName { get; init; } = "";
        public bool IsActive { get; init; }
    }

    public async Task OnGetAsync(CancellationToken ct)
    {
        Items = await db.AdminProfiles
            .Join(db.Users,
                p => p.UserId,
                u => u.Id,
                (p, u) => new Row
                {
                    UserName = u.UserName ?? "",
                    DisplayName = p.DisplayName,
                    IsActive = p.IsActive
                })
            .OrderBy(x => x.DisplayName)
            .ToListAsync(ct);
    }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(Input.UserName) ||
            string.IsNullOrWhiteSpace(Input.DisplayName) ||
            string.IsNullOrWhiteSpace(Input.Password))
        {
            ModelState.AddModelError("", "نام کاربری، نام نمایشی و رمز عبور الزامی است.");
            await OnGetAsync(ct);
            return Page();
        }

        var adminCount = await db.AdminProfiles.CountAsync(x => x.IsActive, ct);
        if (adminCount >= 3)
        {
            ModelState.AddModelError("", "حداکثر ۳ مدیر فعال برای این سیستم در نظر گرفته شده است.");
            await OnGetAsync(ct);
            return Page();
        }

        if (await users.FindByNameAsync(Input.UserName) is not null)
        {
            ModelState.AddModelError("", "این نام کاربری قبلاً استفاده شده است.");
            await OnGetAsync(ct);
            return Page();
        }

        await using var transaction = await db.Database.BeginTransactionAsync(
            System.Data.IsolationLevel.Serializable, ct);

        try
        {
            // شمارش داخل Transaction انجام می‌شود تا دو درخواست همزمان
            // نتوانند محدودیت «حداکثر ۳ مدیر فعال» را دور بزنند.
            var activeAdminCount = await db.AdminProfiles
                .CountAsync(x => x.IsActive, ct);

            if (activeAdminCount >= 3)
            {
                await transaction.RollbackAsync(ct);
                ModelState.AddModelError("", "حداکثر ۳ مدیر فعال برای این سیستم در نظر گرفته شده است.");
                await OnGetAsync(ct);
                return Page();
            }

            var user = new ApplicationUser
            {
                UserName = Input.UserName.Trim(),
                Email = $"{Input.UserName.Trim()}@localhost",
                EmailConfirmed = true
            };

            var result = await users.CreateAsync(user, Input.Password);
            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                    ModelState.AddModelError("", error.Description);

                await transaction.RollbackAsync(ct);
                await OnGetAsync(ct);
                return Page();
            }

            var roleResult = await users.AddToRoleAsync(user, AppRoles.Admin);
            if (!roleResult.Succeeded)
            {
                await transaction.RollbackAsync(ct);
                ModelState.AddModelError("", "نقش مدیر ایجاد نشد؛ عملیات لغو شد.");
                await OnGetAsync(ct);
                return Page();
            }

            db.AdminProfiles.Add(new AdminProfile
            {
                UserId = user.Id,
                DisplayName = Input.DisplayName.Trim()
            });

            await db.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);

            TempData["Success"] = "مدیر جدید با موفقیت ساخته شد. 🔐";
            return RedirectToPage();
        }
        catch (Exception)
        {
            await transaction.RollbackAsync(ct);
            ModelState.AddModelError("", "ایجاد مدیر انجام نشد. لطفاً دوباره تلاش کنید.");
            await OnGetAsync(ct);
            return Page();
        }
    }
}

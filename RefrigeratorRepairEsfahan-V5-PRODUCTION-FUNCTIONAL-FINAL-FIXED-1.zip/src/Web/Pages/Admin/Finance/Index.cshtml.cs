// PageModel منطق پشت همین Razor Page را نگهداری می‌کند؛ UI در فایل .cshtml است.
// متدهایی مثل OnGet و OnPost با چرخه درخواست HTTP/Razor Pages اجرا می‌شوند.

using Microsoft.AspNetCore.Mvc.RazorPages; using Microsoft.EntityFrameworkCore; using RefrigeratorRepair.Domain.Enums; using RefrigeratorRepair.Infrastructure.Data;
namespace RefrigeratorRepair.Web.Pages;
// گزارش مالی کمیسیون را از دفتر تراکنش کیف پول می‌خواند.
public class AdminFinanceModel(ApplicationDbContext db):PageModel { public decimal Today,Week,Month,Year; public async Task OnGetAsync(){var q=db.WalletTransactions.Where(x=>x.Type==WalletTransactionType.CommissionDebit);var now=DateTime.UtcNow;Today=await q.Where(x=>x.CreatedAt>=now.Date).SumAsync(x=>(decimal?)-x.Amount)??0;Week=await q.Where(x=>x.CreatedAt>=now.Date.AddDays(-(int)now.DayOfWeek)).SumAsync(x=>(decimal?)-x.Amount)??0;Month=await q.Where(x=>x.CreatedAt>=new DateTime(now.Year,now.Month,1)).SumAsync(x=>(decimal?)-x.Amount)??0;Year=await q.Where(x=>x.CreatedAt>=new DateTime(now.Year,1,1)).SumAsync(x=>(decimal?)-x.Amount)??0;} }

using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages;

// داشبورد مدیریت از Queryهای واقعی دیتابیس تغذیه می‌شود؛ هیچ عدد آماری در View هاردکد نشده است.
public sealed class AdminIndexModel(ApplicationDbContext db) : PageModel
{
    public int TotalRequests { get; set; }
    public int CompletedRequests { get; set; }
    public int InProgressRequests { get; set; }
    public int CancelledRequests { get; set; }
    public int PendingTechnicians { get; set; }
    public int ActiveTechnicians { get; set; }
    public int Customers { get; set; }
    public decimal TotalCommission { get; set; }
    public List<RecentRequest> RecentRequests { get; set; } = [];
    public List<MapPoint> MapPoints { get; set; } = [];
    public List<DayStat> DailyStats { get; set; } = [];

    public sealed record RecentRequest(int Id, string TrackingCode, string Customer, string Service, string Status, string Technician, DateTime CreatedAt);
    public sealed record MapPoint(decimal Lat, decimal Lng, string TrackingCode, string Status);
    public sealed record DayStat(string Label, int Count);

    public async Task OnGetAsync(CancellationToken ct)
    {
        var requests = db.RepairRequests.AsNoTracking();
        TotalRequests = await requests.CountAsync(ct);
        CompletedRequests = await requests.CountAsync(x => x.Status == RepairRequestStatus.Completed, ct);
        CancelledRequests = await requests.CountAsync(x => x.Status == RepairRequestStatus.Cancelled, ct);
        InProgressRequests = await requests.CountAsync(x => x.Status == RepairRequestStatus.Assigned || x.Status == RepairRequestStatus.TechnicianOnTheWay || x.Status == RepairRequestStatus.InProgress, ct);
        PendingTechnicians = await db.Technicians.CountAsync(x => x.AccountStatus == TechnicianAccountStatus.PendingApproval, ct);
        ActiveTechnicians = await db.Technicians.CountAsync(x => x.AccountStatus == TechnicianAccountStatus.Active, ct);
        Customers = await db.Customers.CountAsync(ct);
        TotalCommission = await db.WalletTransactions.Where(x => x.Type == WalletTransactionType.CommissionDebit).SumAsync(x => (decimal?)-x.Amount, ct) ?? 0m;

        RecentRequests = await requests
            .OrderByDescending(x => x.CreatedAt)
            .Take(8)
            .Select(x => new RecentRequest(
                x.Id,
                x.TrackingCode,
                x.Customer.FirstName + " " + x.Customer.LastName,
                x.ServiceCatalog != null ? x.ServiceCatalog.Title : "خدمت ثبت‌نشده",
                x.Status.ToString(),
                x.AssignedTechnician != null ? x.AssignedTechnician.FirstName + " " + x.AssignedTechnician.LastName : "—",
                x.CreatedAt))
            .ToListAsync(ct);

        MapPoints = await requests
            .Where(x => x.Latitude != 0 && x.Longitude != 0)
            .OrderByDescending(x => x.CreatedAt)
            .Take(30)
            .Select(x => new MapPoint(x.Latitude, x.Longitude, x.TrackingCode, x.Status.ToString()))
            .ToListAsync(ct);

        var start = DateTime.UtcNow.Date.AddDays(-6);
        var raw = await requests.Where(x => x.CreatedAt >= start).GroupBy(x => x.CreatedAt.Date).Select(g => new { Day = g.Key, Count = g.Count() }).ToListAsync(ct);
        DailyStats = Enumerable.Range(0, 7).Select(i =>
        {
            var day = start.AddDays(i);
            return new DayStat(day.ToString("MM/dd"), raw.FirstOrDefault(x => x.Day == day)?.Count ?? 0);
        }).ToList();
    }
}

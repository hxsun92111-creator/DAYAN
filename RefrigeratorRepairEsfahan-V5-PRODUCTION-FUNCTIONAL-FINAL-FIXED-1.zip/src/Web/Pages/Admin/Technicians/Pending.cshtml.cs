// صف تأیید تکنسین‌ها. مدیر می‌تواند قبل از تأیید اطلاعات را در صفحه جزئیات اصلاح کند.
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.Technicians;

public class PendingModel(ApplicationDbContext db) : PageModel
{
    public List<RefrigeratorRepair.Domain.Entities.Technician> Items { get; set; } = new();

    public async Task OnGetAsync(CancellationToken ct)
        => Items = await db.Technicians
            .Include(x => x.Documents)
            .Where(x => x.AccountStatus == RefrigeratorRepair.Domain.Enums.TechnicianAccountStatus.PendingApproval)
            .OrderBy(x => x.CreatedAt)
            .ToListAsync(ct);
}

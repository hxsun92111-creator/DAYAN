// مدیریت تکنسین‌ها: صف تأیید + فهرست تکنسین‌های تأییدشده.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.Technicians;

public class IndexModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users) : PageModel
{
    public List<Row> Items { get; set; } = new();
    public string? Search { get; set; }

    public sealed class Row
    {
        public int Id { get; init; }
        public string Name { get; init; } = "";
        public string Phone { get; init; } = "";
        public string NationalId { get; init; } = "";
        public TechnicianAccountStatus AccountStatus { get; init; }
        public TechnicianAvailability Availability { get; init; }
        public int CompletedJobs { get; init; }
        public int ActiveJobs { get; init; }
    }

    public async Task OnGetAsync(string? search, CancellationToken ct)
    {
        Search = search;
        var query = db.Technicians.AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            query = query.Where(x =>
                (x.FirstName + " " + x.LastName).Contains(search) ||
                x.PhoneNumber.Contains(search));
        }

        Items = await query
            .Select(x => new Row
            {
                Id = x.Id,
                Name = x.FirstName + " " + x.LastName,
                Phone = x.PhoneNumber,
                NationalId = x.NationalId,
                AccountStatus = x.AccountStatus,
                Availability = x.Availability,
                CompletedJobs = x.Jobs.Count(j => j.ReportSubmitted),
                ActiveJobs = x.Jobs.Count(j => !j.ReportSubmitted &&
                    j.Request.Status != RepairRequestStatus.Cancelled)
            })
            .OrderBy(x => x.AccountStatus == TechnicianAccountStatus.PendingApproval ? 0 : 1)
            .ThenBy(x => x.Name)
            .ToListAsync(ct);
    }

    public async Task<IActionResult> OnPostAsync(int id, string action, CancellationToken ct)
    {
        var technician = await db.Technicians.SingleOrDefaultAsync(x => x.Id == id, ct);
        if (technician is null)
            return NotFound();

        switch (action)
        {
            case "approve":
                technician.AccountStatus = TechnicianAccountStatus.Active;
                technician.Availability = TechnicianAvailability.Available;
                var user = await users.FindByIdAsync(technician.UserId);
                if (user is not null && !await users.IsInRoleAsync(user, AppRoles.Technician))
                {
                    var roleResult = await users.AddToRoleAsync(user, AppRoles.Technician);
                    if (!roleResult.Succeeded)
                    {
                        TempData["Error"] = "افزودن نقش تکنسین انجام نشد؛ تأیید حساب لغو شد.";
                        return RedirectToPage(new { search = Search });
                    }
                }
                if (user is not null)
                {
                    user.IsActive = true;
                }
                break;

            case "suspend":
                technician.AccountStatus = TechnicianAccountStatus.Suspended;
                technician.Availability = TechnicianAvailability.Suspended;
                var suspendedUser = await users.FindByIdAsync(technician.UserId);
                if (suspendedUser is not null)
                {
                    suspendedUser.IsActive = false;
                }
                break;

            case "activate":
                technician.AccountStatus = TechnicianAccountStatus.Active;
                technician.Availability = TechnicianAvailability.Available;
                var activeUser = await users.FindByIdAsync(technician.UserId);
                if (activeUser is not null)
                {
                    activeUser.IsActive = true;
                }
                break;

            case "delete":
                // حذف کامل برای تکنسینی که سابقه تعمیر دارد مناسب نیست؛ سابقه مالی/عملیاتی باید بماند.
                if (await db.RepairJobs.AnyAsync(x => x.TechnicianId == id, ct))
                {
                    TempData["Error"] = "این تکنسین سابقه تعمیر دارد؛ برای حفظ سوابق، حساب را مسدود کنید نه حذف کامل.";
                    return RedirectToPage(new { search = Search });
                }

                var identityUser = await users.FindByIdAsync(technician.UserId);
                db.Technicians.Remove(technician);
                await db.SaveChangesAsync(ct);
                if (identityUser is not null)
                    await users.DeleteAsync(identityUser);
                return RedirectToPage(new { search = Search });
        }

        await db.SaveChangesAsync(ct);
        return RedirectToPage(new { search = Search });
    }
}

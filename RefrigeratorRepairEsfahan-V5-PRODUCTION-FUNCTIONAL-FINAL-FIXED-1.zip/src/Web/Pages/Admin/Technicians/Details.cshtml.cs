// جزئیات کامل تکنسین برای مدیر.
// مدیر می‌تواند اطلاعات را اصلاح، مدرک جدید اضافه، وضعیت حساب را کنترل و کیف پول را شارژ کند.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.Technicians;

public class DetailsModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users) : PageModel
{
    [BindProperty]
    public Technician Input { get; set; } = null!;

    [BindProperty]
    public IFormFile? DocumentFile { get; set; }

    [BindProperty]
    public string DocumentType { get; set; } = "مدرک مهارت";

    [BindProperty]
    public decimal WalletTopUp { get; set; }

    public List<WalletTransaction> Transactions { get; set; } = new();
    public List<TechnicianDocument> Documents { get; set; } = new();
    public decimal Balance { get; set; }
    public List<RepairJob> Jobs { get; set; } = new();

    public async Task<IActionResult> OnGetAsync(int id, CancellationToken ct)
    {
        var technician = await db.Technicians
            .Include(x => x.Documents)
            .SingleOrDefaultAsync(x => x.Id == id, ct);

        if (technician is null)
            return NotFound();

        Input = technician;
        Documents = technician.Documents.OrderByDescending(x => x.UploadedAt).ToList();
        Transactions = await db.WalletTransactions
            .Where(x => x.TechnicianId == id)
            .OrderByDescending(x => x.CreatedAt)
            .Take(20)
            .ToListAsync(ct);
        Balance = await db.WalletTransactions
            .Where(x => x.TechnicianId == id)
            .SumAsync(x => (decimal?)x.Amount, ct) ?? 0m;
        Jobs = await db.RepairJobs
            .Include(x => x.Request).ThenInclude(x => x.Customer)
            .Where(x => x.TechnicianId == id)
            .OrderByDescending(x => x.RepairDate)
            .Take(30)
            .ToListAsync(ct);

        return Page();
    }

    public async Task<IActionResult> OnPostSaveAsync(int id, CancellationToken ct)
    {
        var technician = await db.Technicians.SingleOrDefaultAsync(x => x.Id == id, ct);
        if (technician is null)
            return NotFound();

        if (await db.Technicians.AnyAsync(x => x.NationalId == Input.NationalId && x.Id != id, ct))
        {
            ModelState.AddModelError("Input.NationalId", "کد ملی تکراری است.");
            return await ReloadAsync(id, ct);
        }

        technician.FirstName = Input.FirstName;
        technician.LastName = Input.LastName;
        technician.NationalId = Input.NationalId;
        technician.PhoneNumber = Input.PhoneNumber;
        technician.Address = Input.Address;
        technician.ExperienceYears = Input.ExperienceYears;
        technician.Specialization = Input.Specialization;

        await db.SaveChangesAsync(ct);
        TempData["Success"] = "اطلاعات تکنسین با موفقیت اصلاح شد. ✅";
        return RedirectToPage(new { id });
    }

    public async Task<IActionResult> OnPostStatusAsync(
        int id,
        string status,
        CancellationToken ct)
    {
        var technician = await db.Technicians
            .SingleOrDefaultAsync(x => x.Id == id, ct);

        if (technician is null)
            return NotFound();

        if (!Enum.TryParse<TechnicianAccountStatus>(status, true, out var parsed) ||
            parsed is not TechnicianAccountStatus.Active and not TechnicianAccountStatus.Suspended)
        {
            TempData["Error"] = "وضعیت انتخاب‌شده مجاز نیست.";
            return RedirectToPage(new { id });
        }

        await using var transaction = await db.Database.BeginTransactionAsync(ct);

        try
        {
            var user = await users.FindByIdAsync(technician.UserId);
            if (user is null)
            {
                await transaction.RollbackAsync(ct);
                TempData["Error"] = "حساب Identity تکنسین پیدا نشد.";
                return RedirectToPage(new { id });
            }

            technician.AccountStatus = parsed;
            technician.Availability = parsed == TechnicianAccountStatus.Active
                ? TechnicianAvailability.Available
                : TechnicianAvailability.Suspended;
            user.IsActive = parsed == TechnicianAccountStatus.Active;

            if (parsed == TechnicianAccountStatus.Active &&
                !await users.IsInRoleAsync(user, AppRoles.Technician))
            {
                var roleResult = await users.AddToRoleAsync(user, AppRoles.Technician);
                if (!roleResult.Succeeded)
                {
                    await transaction.RollbackAsync(ct);
                    TempData["Error"] = "افزودن نقش تکنسین انجام نشد.";
                    return RedirectToPage(new { id });
                }
            }

            await db.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);
        }
        catch (Exception)
        {
            await transaction.RollbackAsync(ct);
            TempData["Error"] = "تغییر وضعیت تکنسین انجام نشد.";
        }

        return RedirectToPage(new { id });
    }

    public async Task<IActionResult> OnPostUploadAsync(int id, CancellationToken ct)
    {
        var technician = await db.Technicians.FindAsync(new object[] { id }, ct);
        if (technician is null)
            return NotFound();

        if (DocumentFile is null || DocumentFile.Length == 0)
        {
            TempData["Error"] = "فایلی برای آپلود انتخاب نشده است.";
            return RedirectToPage(new { id });
        }

        const long maxDocumentBytes = 10 * 1024 * 1024;
        if (DocumentFile.Length > maxDocumentBytes)
        {
            TempData["Error"] = "حجم مدرک نباید بیشتر از ۱۰ مگابایت باشد.";
            return RedirectToPage(new { id });
        }

        var extension = Path.GetExtension(DocumentFile.FileName).ToLowerInvariant();
        var allowed = new[] { ".jpg", ".jpeg", ".png", ".pdf" };
        if (!allowed.Contains(extension) || !await HasExpectedSignatureAsync(DocumentFile, extension, ct))
        {
            TempData["Error"] = "فرمت فایل مجاز نیست.";
            return RedirectToPage(new { id });
        }

        var root = Path.Combine(AppContext.BaseDirectory, "App_Data", "TechnicianDocuments");
        Directory.CreateDirectory(root);
        var physicalPath = Path.Combine(root, $"{Guid.NewGuid():N}{extension}");

        await using (var stream = System.IO.File.Create(physicalPath))
            await DocumentFile.CopyToAsync(stream, ct);

        db.TechnicianDocuments.Add(new TechnicianDocument
        {
            TechnicianId = id,
            DocumentType = string.IsNullOrWhiteSpace(DocumentType) ? "مدرک" : DocumentType,
            FilePath = physicalPath
        });

        await db.SaveChangesAsync(ct);
        TempData["Success"] = "مدرک با موفقیت اضافه شد. 📎";
        return RedirectToPage(new { id });
    }

    public async Task<IActionResult> OnPostTopUpAsync(int id, CancellationToken ct)
    {
        if (WalletTopUp <= 0)
        {
            TempData["Error"] = "مبلغ شارژ باید بیشتر از صفر باشد.";
            return RedirectToPage(new { id });
        }

        var technician = await db.Technicians.FindAsync(new object[] { id }, ct);
        if (technician is null)
            return NotFound();

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        try
        {
            var balance = await db.WalletTransactions
                .Where(x => x.TechnicianId == id)
                .SumAsync(x => (decimal?)x.Amount, ct) ?? 0m;

            db.WalletTransactions.Add(new WalletTransaction
            {
                TechnicianId = id,
                Type = WalletTransactionType.Adjustment,
                Amount = WalletTopUp,
                BalanceAfter = balance + WalletTopUp,
                Description = "شارژ کیف پول توسط مدیر"
            });

            await db.SaveChangesAsync(ct);
            await tx.CommitAsync(ct);
            TempData["Success"] = "کیف پول تکنسین شارژ شد. 💳";
        }
        catch
        {
            await tx.RollbackAsync(ct);
            TempData["Error"] = "شارژ کیف پول انجام نشد.";
        }

        return RedirectToPage(new { id });
    }

    private static async Task<bool> HasExpectedSignatureAsync(IFormFile file, string extension, CancellationToken ct)
    {
        await using var stream = file.OpenReadStream();
        var header = new byte[8];
        var read = await stream.ReadAsync(header, ct);

        return extension switch
        {
            ".pdf" => read >= 4 && header[0] == 0x25 && header[1] == 0x50 && header[2] == 0x44 && header[3] == 0x46,
            ".png" => read >= 8 && header.SequenceEqual(new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A }),
            ".jpg" or ".jpeg" => read >= 3 && header[0] == 0xFF && header[1] == 0xD8 && header[2] == 0xFF,
            _ => false
        };
    }

    private async Task<IActionResult> ReloadAsync(int id, CancellationToken ct)
    {
        var technician = await db.Technicians.Include(x => x.Documents).SingleOrDefaultAsync(x => x.Id == id, ct);
        if (technician is null) return NotFound();
        Input = technician;
        Documents = technician.Documents.ToList();
        Transactions = await db.WalletTransactions.Where(x => x.TechnicianId == id).OrderByDescending(x => x.CreatedAt).Take(20).ToListAsync(ct);
        Balance = await db.WalletTransactions.Where(x => x.TechnicianId == id).SumAsync(x => (decimal?)x.Amount, ct) ?? 0m;
        Jobs = await db.RepairJobs.Include(x => x.Request).ThenInclude(x => x.Customer).Where(x => x.TechnicianId == id).OrderByDescending(x => x.RepairDate).Take(30).ToListAsync(ct);
        return Page();
    }
}

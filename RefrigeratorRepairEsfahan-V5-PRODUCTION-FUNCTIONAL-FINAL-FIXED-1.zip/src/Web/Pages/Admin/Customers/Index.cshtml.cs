// فهرست مشتریان بر اساس آخرین سفارش.
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.Customers;

public class IndexModel(ApplicationDbContext db) : PageModel
{
    public List<RefrigeratorRepair.Domain.Entities.Customer> Items { get; set; } = new();
    public string? Search { get; set; }

    public async Task OnGetAsync(string? search, CancellationToken ct)
    {
        Search = search;
        var query = db.Customers.AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(x => (x.FirstName + " " + x.LastName).Contains(search) || x.PhoneNumber.Contains(search));

        Items = await query.OrderByDescending(x => x.LastOrderAt).ToListAsync(ct);
    }
}

// جزئیات مشتری و تمام سفارش‌ها/تعمیرات او.
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.Customers;

public class DetailsModel(ApplicationDbContext db) : PageModel
{
    public RefrigeratorRepair.Domain.Entities.Customer? Customer { get; set; }

    public async Task OnGetAsync(int id, CancellationToken ct)
    {
        Customer = await db.Customers
            .Include(x => x.Requests).ThenInclude(x => x.RepairJob)
            .SingleOrDefaultAsync(x => x.Id == id, ct);
    }
}

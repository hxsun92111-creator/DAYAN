// جزئیات یک درخواست فعال برای مدیر.
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.Requests;

public class DetailsModel(ApplicationDbContext db) : PageModel
{
    public RefrigeratorRepair.Domain.Entities.RepairRequest? Item { get; set; }
    public async Task OnGetAsync(int id, CancellationToken ct)
        => Item = await db.RepairRequests
            .Include(x => x.Customer).Include(x => x.ServiceCatalog)
            .Include(x => x.AssignedTechnician)
            .Include(x => x.RepairJob).ThenInclude(x => x.Parts)
            .SingleOrDefaultAsync(x => x.Id == id, ct);
}

// درخواست‌های فعال برای پیگیری مدیر.
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.Requests;

public class IndexModel(ApplicationDbContext db) : PageModel
{
    public List<RefrigeratorRepair.Domain.Entities.RepairRequest> Items { get; set; } = new();
    public async Task OnGetAsync(CancellationToken ct)
        => Items = await db.RepairRequests
            .Include(x => x.Customer).Include(x => x.ServiceCatalog)
            .Include(x => x.AssignedTechnician)
            .Where(x => x.Status != RepairRequestStatus.Completed && x.Status != RepairRequestStatus.Cancelled)
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync(ct);
}

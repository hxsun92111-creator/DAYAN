using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Admin.Services;

// CRUD ساده خدمات؛ تغییر این جدول بلافاصله در صفحه اصلی و Wizard مشتری دیده می‌شود.
public sealed class IndexModel(ApplicationDbContext db) : PageModel
{
    public List<ServiceCatalog> Items { get; set; } = [];
    [BindProperty] public InputModel Input { get; set; } = new();
    public sealed class InputModel
    {
        public int Id { get; set; }
        [Required, MaxLength(150)] public string Title { get; set; } = "";
        [Required, MaxLength(1000)] public string ShortDescription { get; set; } = "";
        public bool IsActive { get; set; } = true;
    }

    public async Task OnGetAsync(CancellationToken ct) => await LoadAsync(ct);

    public async Task<IActionResult> OnPostSaveAsync(CancellationToken ct)
    {
        if (!ModelState.IsValid) { await LoadAsync(ct); return Page(); }
        ServiceCatalog item;
        if (Input.Id == 0)
        {
            item = new ServiceCatalog();
            db.Services.Add(item);
        }
        else
        {
            item = await db.Services.SingleOrDefaultAsync(x => x.Id == Input.Id, ct) ?? throw new InvalidOperationException("خدمت پیدا نشد.");
        }
        item.Title = Input.Title.Trim(); item.ShortDescription = Input.ShortDescription.Trim(); item.IsActive = Input.IsActive;
        await db.SaveChangesAsync(ct);
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostToggleAsync(int id, CancellationToken ct)
    {
        var item = await db.Services.FindAsync([id], ct);
        if (item is null) return NotFound();
        item.IsActive = !item.IsActive;
        await db.SaveChangesAsync(ct);
        return RedirectToPage();
    }

    private async Task LoadAsync(CancellationToken ct) => Items = await db.Services.AsNoTracking().OrderBy(x => x.Title).ToListAsync(ct);
}

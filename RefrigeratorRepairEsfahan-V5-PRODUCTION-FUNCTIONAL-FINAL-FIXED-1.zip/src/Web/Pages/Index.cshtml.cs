// PageModel صفحه اصلی.
// خدماتی که روی صفحه اصلی نمایش داده می‌شوند از ServiceCatalog خوانده می‌شوند؛
// بنابراین UI تبلیغاتی از داده‌های واقعی سیستم جدا نیست.
using Microsoft.AspNetCore.Mvc.RazorPages;
using RefrigeratorRepair.Application.Interfaces;

namespace RefrigeratorRepair.Web.Pages;

public sealed class IndexModel(IServiceCatalogRepository serviceCatalog) : PageModel
{
    public sealed record ServiceCard(int Id, string Title, string Description, string Icon);

    public IReadOnlyList<ServiceCard> Services { get; private set; } = [];

    public async Task OnGetAsync(CancellationToken ct)
    {
        var items = await serviceCatalog.GetActiveAsync(ct);
        Services = items.Select(x => new ServiceCard(
            x.Id,
            x.Title,
            x.ShortDescription,
            GetIcon(x.Title))).ToList();
    }

    private static string GetIcon(string title) => title switch
    {
        "تعمیر یخچال فریزر" => "bi bi-box-seam",
        "تعمیر ساید بای ساید" => "bi bi-layout-split",
        "شارژ گاز و رفع نشتی" => "bi bi-snow2",
        "عیب‌یابی و سرویس" => "bi bi-wrench-adjustable-circle",
        _ => "bi bi-tools"
    };
}

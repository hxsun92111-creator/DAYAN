// صفحه تماس اطلاعات ثابت عمومی را نمایش می‌دهد و به عملیات دیتابیس نیاز ندارد.
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace RefrigeratorRepair.Web.Pages;
public sealed class ContactModel : PageModel { }

// تغییر وضعیت کاری تکنسین با رعایت وضعیت حساب و وجود تعمیر جاری.
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Web.Pages;

public class TechnicianStatusModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users) : PageModel
{
    public TechnicianAvailability Status { get; private set; }

    public async Task OnGetAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        var technician = user is null
            ? null
            : await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);

        Status = technician?.Availability ?? TechnicianAvailability.PendingApproval;
    }

    public async Task<IActionResult> OnPostAsync(
        string status,
        CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null)
            return Unauthorized();

        var technician = await db.Technicians
            .SingleOrDefaultAsync(x => x.UserId == user.Id, ct);

        if (technician is null)
            return Unauthorized();

        if (technician.AccountStatus != TechnicianAccountStatus.Active)
            return Forbid();

        if (technician.Availability == TechnicianAvailability.Busy ||
            await db.RepairJobs.AnyAsync(
                x => x.TechnicianId == technician.Id &&
                     !x.ReportSubmitted &&
                     x.Request.Status != RepairRequestStatus.Cancelled,
                ct))
        {
            TempData["Error"] = "تا پایان تعمیر جاری، تغییر وضعیت کاری ممکن نیست.";
            return RedirectToPage();
        }

        if (!Enum.TryParse<TechnicianAvailability>(status, true, out var parsed) ||
            parsed is not TechnicianAvailability.Available and not TechnicianAvailability.TemporarilyUnavailable)
        {
            TempData["Error"] = "وضعیت انتخاب‌شده مجاز نیست.";
            return RedirectToPage();
        }

        technician.Availability = parsed;
        await db.SaveChangesAsync(ct);
        return RedirectToPage();
    }
}

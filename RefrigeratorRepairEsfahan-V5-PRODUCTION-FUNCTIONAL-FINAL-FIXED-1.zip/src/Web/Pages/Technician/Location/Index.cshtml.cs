using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Web.Pages.Technician.Location;

/// <summary>موقعیت آخرین سفارش فعال را از مختصات موجود در RepairRequest نمایش می‌دهد.</summary>
public class IndexModel(ApplicationDbContext db, UserManager<ApplicationUser> users) : PageModel
{
    public bool HasActiveLocation { get; private set; }
    public string Address { get; private set; } = "";
    public string MapUrl { get; private set; } = "https://www.openstreetmap.org/export/embed.html?bbox=51.60%2C32.58%2C51.72%2C32.72&layer=mapnik";
    public string ExternalMapUrl { get; private set; } = "https://www.openstreetmap.org/";

    public async Task OnGetAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return;
        var technician = await db.Technicians.AsNoTracking().SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (technician is null) return;

        var request = await db.RepairJobs.AsNoTracking()
            .Where(x => x.TechnicianId == technician.Id && !x.ReportSubmitted && x.Request.Status != Domain.Enums.RepairRequestStatus.Cancelled)
            .OrderByDescending(x => x.Id)
            .Select(x => new { x.Request.Address, x.Request.Latitude, x.Request.Longitude })
            .FirstOrDefaultAsync(ct);
        if (request is null) return;

        HasActiveLocation = true;
        Address = request.Address;
        var lat = request.Latitude.ToString(System.Globalization.CultureInfo.InvariantCulture);
        var lon = request.Longitude.ToString(System.Globalization.CultureInfo.InvariantCulture);
        MapUrl = $"https://www.openstreetmap.org/export/embed.html?marker={lat}%2C{lon}&zoom=15";
        ExternalMapUrl = $"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=17/{lat}/{lon}";
    }
}

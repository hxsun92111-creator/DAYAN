// جزئیات سفارش پذیرفته‌شده و فرم تکمیل تعمیر.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.DTOs;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Technician.Orders;

public class DetailsModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users,
    Microsoft.Extensions.Options.IOptions<CommissionOptions> commissionOptions,
    IRepairJobService repairJobService) : PageModel
{
    public RepairJob? Job { get; set; }
    public decimal CurrentBalance { get; set; }
    public decimal EstimatedCommission { get; set; }
    public decimal EstimatedFinalProfit { get; set; }
    public decimal CommissionRatePercent => commissionOptions.Value.TechnicianRate * 100m;

    [BindProperty]
    public CompleteRepairJobDto Input { get; set; } = new();

    public async Task<IActionResult> OnGetAsync(int jobId, CancellationToken ct)
    {
        return await LoadAsync(jobId, ct);
    }

    public async Task<IActionResult> OnPostAsync(int jobId, CancellationToken ct)
    {
        Job = await db.RepairJobs
            .Include(x => x.Parts)
            .Include(x => x.Request).ThenInclude(x => x.Customer)
            .SingleOrDefaultAsync(x => x.Id == jobId, ct);

        if (Job is null) return NotFound();
        if (Job.ReportSubmitted) return BadRequest("این سفارش قبلاً تکمیل شده است.");

        var user = await users.GetUserAsync(User);
        if (user is null) return Unauthorized();
        var technician = await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (technician is null || Job.TechnicianId != technician.Id) return Forbid();

        var partsCost = Input.Parts.Sum(x => x.Quantity * x.UnitPrice);
        var netBase = Math.Max(0m, Input.CustomerTotal - partsCost - Input.TravelCost);
        EstimatedCommission = Math.Round(netBase * commissionOptions.Value.TechnicianRate, 0);
        EstimatedFinalProfit = netBase - EstimatedCommission;
        CurrentBalance = await db.WalletTransactions.Where(x => x.TechnicianId == technician.Id).SumAsync(x => (decimal?)x.Amount, ct) ?? 0m;

        if (CurrentBalance < EstimatedCommission)
        {
            ModelState.AddModelError("", $"موجودی کافی نیست. برای تکمیل سفارش باید حداقل {EstimatedCommission:N0} تومان شارژ کنید.");
            return Page();
        }

        if (!ModelState.IsValid)
            return Page();

        // تأیید نهایی را با JavaScript هم در UI انجام می‌دهیم؛
        // اما منطق امنیتی به JavaScript وابسته نیست و Service دوباره همه چیز را بررسی می‌کند.
        var result = await repairJobService.CompleteAsync(jobId, Input, ct);
        if (!result.Success)
        {
            ModelState.AddModelError("", result.Error ?? "تکمیل سفارش انجام نشد.");
            return Page();
        }

        TempData["CompletedProfit"] = EstimatedFinalProfit.ToString("N0");
        return RedirectToPage("/Technician/History/Details", new { id = jobId });
    }

    private async Task<IActionResult> LoadAsync(int jobId, CancellationToken ct)
    {
        Job = await db.RepairJobs
            .Include(x => x.Parts)
            .Include(x => x.Request).ThenInclude(x => x.Customer)
            .SingleOrDefaultAsync(x => x.Id == jobId, ct);

        if (Job is null) return NotFound();

        var user = await users.GetUserAsync(User);
        var technician = user is null ? null : await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (technician is null || Job.TechnicianId != technician.Id) return Forbid();

        CurrentBalance = await db.WalletTransactions.Where(x => x.TechnicianId == technician.Id).SumAsync(x => (decimal?)x.Amount, ct) ?? 0m;
        return Page();
    }
}

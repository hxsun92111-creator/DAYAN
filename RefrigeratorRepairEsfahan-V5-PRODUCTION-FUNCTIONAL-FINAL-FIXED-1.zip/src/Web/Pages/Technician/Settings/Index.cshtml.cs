using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Web.Pages.Technician.Settings;

// تنظیمات تکنسین بدون جدول اضافه: تغییر رمز با Identity و وضعیت دریافت سفارش با Technician انجام می‌شود.
public sealed class IndexModel(UserManager<ApplicationUser> users, RefrigeratorRepair.Infrastructure.Data.ApplicationDbContext db) : PageModel
{
    [BindProperty] public PasswordInput Password { get; set; } = new();
    public string? Message { get; set; }
    public string? Error { get; set; }

    public sealed class PasswordInput
    {
        [Required, StringLength(100, MinimumLength = 12)] public string Current { get; set; } = "";
        [Required, StringLength(100, MinimumLength = 12)] public string New { get; set; } = "";
        [Required, Compare(nameof(New))] public string Confirm { get; set; } = "";
    }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        if (!ModelState.IsValid) return Page();
        var user = await users.GetUserAsync(User);
        if (user is null) return Unauthorized();
        var result = await users.ChangePasswordAsync(user, Password.Current, Password.New);
        if (!result.Succeeded)
        {
            Error = string.Join(" | ", result.Errors.Select(x => x.Description));
            return Page();
        }
        Message = "رمز عبور با موفقیت تغییر کرد.";
        Password = new();
        return Page();
    }
}

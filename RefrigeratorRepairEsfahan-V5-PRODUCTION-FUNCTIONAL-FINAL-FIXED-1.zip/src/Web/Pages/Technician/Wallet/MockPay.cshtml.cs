// صفحه پرداخت آزمایشی؛ فقط برای Development.
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Hosting;

namespace RefrigeratorRepair.Web.Pages.Technician.Wallet;

public class MockPayModel(IHostEnvironment environment) : PageModel
{
    public IActionResult OnGet()
    {
        if (!environment.IsDevelopment())
        {
            return NotFound();
        }

        return Page();
    }

    [BindProperty(SupportsGet = true)] public string Authority { get; set; } = "";
    [BindProperty(SupportsGet = true)] public string Callback { get; set; } = "";

    public IActionResult OnPost()
    {
        if (!environment.IsDevelopment())
        {
            return NotFound();
        }

        // درگاه واقعی بعداً Callback را از سمت Provider فراخوانی می‌کند.
        var callbackUrl = string.IsNullOrWhiteSpace(Callback)
            ? "/Technician/Wallet/Callback"
            : Callback;
        var separator = callbackUrl.Contains('?') ? "&" : "?";
        var redirectUrl = $"{callbackUrl}{separator}authority={Uri.EscapeDataString(Authority)}&referenceId=MOCK-PAID&status=OK";
        return Redirect(redirectUrl);
    }
}

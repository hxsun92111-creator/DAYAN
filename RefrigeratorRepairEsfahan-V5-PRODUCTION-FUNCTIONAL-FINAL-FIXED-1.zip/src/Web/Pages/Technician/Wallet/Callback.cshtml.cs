// Callback درگاه: پرداخت را Verify می‌کنیم و سپس Ledger کیف پول را افزایش می‌دهیم.
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RefrigeratorRepair.Application.Interfaces;

namespace RefrigeratorRepair.Web.Pages.Technician.Wallet;

[AllowAnonymous]
public class CallbackModel(IWalletService wallet) : PageModel
{
    public bool Success { get; private set; }
    public string Message { get; private set; } = "";

    public async Task<IActionResult> OnGetAsync(string authority, string? referenceId, string? status, CancellationToken ct)
    {
        // Status ارسالی کاربر را منبع موفقیت نمی‌دانیم؛ فقط برای جلوگیری از Verify بی‌مورد
        // در حالت Cancel استفاده می‌شود. تأیید نهایی داخل WalletService و خود درگاه انجام می‌شود.
        if (!string.Equals(status, "OK", StringComparison.OrdinalIgnoreCase))
        {
            Success = false;
            Message = "پرداخت لغو شد یا توسط درگاه موفق اعلام نشد.";
            return Page();
        }

        var result = await wallet.ApplyTopUpAsync(authority, referenceId ?? "", ct);
        Success = result.Success;
        Message = result.Success
            ? "پرداخت تأیید شد و کیف پول شارژ شد."
            : result.Error ?? "پرداخت تأیید نشد.";
        return Page();
    }
}

// صفحه کیف پول تکنسین: موجودی از مجموع WalletTransactions محاسبه می‌شود.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Application.DTOs;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Technician.Wallet;

public class IndexModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users,
    IWalletService wallet) : PageModel
{
    [BindProperty] public TopUpWalletDto Input { get; set; } = new();
    public decimal Balance { get; set; }
    public List<WalletTransaction> Transactions { get; set; } = new();
    public string? Error { get; set; }

    public async Task OnGetAsync(CancellationToken ct)
    {
        await LoadAsync(ct);
    }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return Unauthorized();

        var technician = await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (technician is null) return Unauthorized();

        if (!ModelState.IsValid)
        {
            await LoadAsync(ct);
            return Page();
        }

        var result = await wallet.CreateTopUpAsync(technician.Id, Input.Amount, ct);
        if (!result.Success)
        {
            Error = result.Error;
            await LoadAsync(ct);
            return Page();
        }

        return Redirect(result.Value!);
    }

    private async Task LoadAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return;

        var technician = await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (technician is null) return;

        Balance = await wallet.GetBalanceAsync(technician.Id, ct);
        Transactions = await db.WalletTransactions
            .Where(x => x.TechnicianId == technician.Id)
            .OrderByDescending(x => x.CreatedAt)
            .Take(30)
            .ToListAsync(ct);
    }
}

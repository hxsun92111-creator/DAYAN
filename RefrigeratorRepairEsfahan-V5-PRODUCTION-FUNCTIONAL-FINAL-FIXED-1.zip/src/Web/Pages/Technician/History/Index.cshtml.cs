// PageModel منطق پشت همین Razor Page را نگهداری می‌کند؛ UI در فایل .cshtml است.
// متدهایی مثل OnGet و OnPost با چرخه درخواست HTTP/Razor Pages اجرا می‌شوند.

using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity; using Microsoft.AspNetCore.Mvc.RazorPages; using Microsoft.EntityFrameworkCore; using RefrigeratorRepair.Application.Interfaces; using RefrigeratorRepair.Domain.Entities;
namespace RefrigeratorRepair.Web.Pages;
// سابقه فقط متعلق به تکنسین واردشده است.
public class TechnicianHistoryModel(UserManager<ApplicationUser> users,IRepairJobRepository jobs):PageModel { public List<RepairJob> Items{get;set;}=new(); public async Task OnGetAsync(){var u=await users.GetUserAsync(User);if(u is null)return;using var scope=HttpContext.RequestServices.CreateScope();var db=scope.ServiceProvider.GetRequiredService<RefrigeratorRepair.Infrastructure.Data.ApplicationDbContext>();var t=await db.Technicians.SingleOrDefaultAsync(x=>x.UserId==u.Id);if(t is not null)Items=await jobs.GetHistoryAsync(t.Id); } }

// سفارش‌های پیشنهادی تکنسین.
// شماره تلفن و آدرس قبل از پذیرش نمایش داده نمی‌شوند.
using Microsoft.AspNetCore.Identity;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Technician.Offers;

public class IndexModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users) : PageModel
{
    public List<TechnicianOffer> Items { get; set; } = new();
    public decimal Balance { get; set; }
    public const decimal MinimumOpenBalance = 500_000m;

    private async Task<Technician?> CurrentAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        return user is null ? null : await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
    }

    public async Task OnGetAsync(CancellationToken ct)
    {
        var technician = await CurrentAsync(ct);
        if (technician is null) return;

        Balance = await db.WalletTransactions.Where(x => x.TechnicianId == technician.Id).SumAsync(x => (decimal?)x.Amount, ct) ?? 0m;

        // فقط یک پیشنهاد فعال نمایش داده می‌شود؛ قدیمی‌ترین پیشنهاد اولویت دارد.
        Items = await db.TechnicianOffers
            .Include(x => x.Request).ThenInclude(x => x.Customer)
            .Where(x => x.TechnicianId == technician.Id && x.Status == OfferStatus.Pending && x.ExpiresAt > DateTime.UtcNow)
            .OrderBy(x => x.Request.CreatedAt)
            .Take(1)
            .ToListAsync(ct);
    }

    public async Task<IActionResult> OnPostAcceptAsync(int offerId, CancellationToken ct)
    {
        var technician = await CurrentAsync(ct);
        if (technician is null) return Unauthorized();

        await using var tx = await db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable, ct);

        try
        {
            // کنترل موجودی داخل همان Transaction انجام می‌شود تا بین بررسی
            // موجودی و پذیرش سفارش Race Condition ایجاد نشود.
            var balance = await db.WalletTransactions
                .Where(x => x.TechnicianId == technician.Id)
                .SumAsync(x => (decimal?)x.Amount, ct) ?? 0m;

            if (balance < MinimumOpenBalance)
            {
                TempData["Error"] = $"برای باز کردن اطلاعات کامل سفارش حداقل {MinimumOpenBalance:N0} تومان موجودی لازم است.";
                await tx.RollbackAsync(ct);
                return RedirectToPage();
            }

            var offer = await db.TechnicianOffers
                .Include(x => x.Request)
                .SingleOrDefaultAsync(x => x.Id == offerId && x.TechnicianId == technician.Id && x.Status == OfferStatus.Pending, ct);

            if (offer is null || offer.ExpiresAt <= DateTime.UtcNow)
            {
                TempData["Error"] = "این سفارش دیگر قابل پذیرش نیست.";
                await tx.RollbackAsync(ct);
                return RedirectToPage();
            }

            // اگر تکنسین دیگری زودتر سفارش را گرفته باشد، این شرط مانع تخصیص دوباره می‌شود.
            if (offer.Request.AssignedTechnicianId is not null || offer.Request.Status == RepairRequestStatus.Completed)
            {
                TempData["Error"] = "این سفارش توسط کارشناس دیگری پذیرفته شده است.";
                await tx.RollbackAsync(ct);
                return RedirectToPage();
            }

            var busy = await db.RepairJobs.AnyAsync(x => x.TechnicianId == technician.Id && !x.ReportSubmitted && x.Request.Status != RepairRequestStatus.Cancelled, ct);
            if (busy || technician.Availability != TechnicianAvailability.Available || technician.AccountStatus != TechnicianAccountStatus.Active)
            {
                TempData["Error"] = "در حال حاضر امکان پذیرش سفارش ندارید.";
                await tx.RollbackAsync(ct);
                return RedirectToPage();
            }

            offer.Status = OfferStatus.Accepted;
            offer.Request.AssignedTechnicianId = technician.Id;
            offer.Request.AssignedAt = DateTime.UtcNow;
            offer.Request.Status = RepairRequestStatus.Assigned;
            technician.Availability = TechnicianAvailability.Busy;

            db.RepairJobs.Add(new RepairJob
            {
                RepairRequestId = offer.Request.Id,
                TechnicianId = technician.Id
            });

            await db.TechnicianOffers
                .Where(x => x.RepairRequestId == offer.Request.Id && x.Id != offer.Id && x.Status == OfferStatus.Pending)
                .ExecuteUpdateAsync(s => s.SetProperty(x => x.Status, OfferStatus.Expired), ct);

            await db.SaveChangesAsync(ct);
            await tx.CommitAsync(ct);
            return RedirectToPage("/Technician/Orders/Details", new { jobId = await db.RepairJobs.Where(x => x.RepairRequestId == offer.Request.Id).Select(x => x.Id).SingleAsync(ct) });
        }
        catch (Exception)
        {
            await tx.RollbackAsync(ct);
            TempData["Error"] = "پذیرش سفارش انجام نشد. لطفاً دوباره تلاش کنید.";
            return RedirectToPage();
        }
    }
}

// داشبورد تکنسین: اطلاعات شخصی، موجودی، وضعیت کاری و آمار ماه جاری.
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using RefrigeratorRepair.Infrastructure.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web.Pages.Technician;

public class IndexModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users) : PageModel
{
    public string Name { get; set; } = "تکنسین";
    public string? PhotoPath { get; set; }
    public TechnicianAvailability Availability { get; set; }
    public TechnicianAccountStatus AccountStatus { get; set; }
    public decimal Balance { get; set; }
    public decimal MonthRevenue { get; set; }
    public decimal MonthCommission { get; set; }
    public int MonthCompleted { get; set; }
    public int ActiveOrders { get; set; }
    public List<DayStat> DailyStats { get; set; } = new();
    public List<RecentJob> RecentJobs { get; set; } = new();

    public sealed class RecentJob
    {
        public int Id { get; init; }
        public string TrackingCode { get; init; } = "";
        public string CustomerName { get; init; } = "";
        public string Address { get; init; } = "";
        public string Date { get; init; } = "";
    }

    public sealed class DayStat
    {
        public string Day { get; init; } = "";
        public decimal Revenue { get; init; }
        public int Completed { get; init; }
    }

    public async Task OnGetAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return;

        var technician = await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (technician is null) return;

        Name = $"{technician.FirstName} {technician.LastName}";
        PhotoPath = technician.ProfilePhotoPath;
        Availability = technician.Availability;
        AccountStatus = technician.AccountStatus;
        Balance = await db.WalletTransactions.Where(x => x.TechnicianId == technician.Id).SumAsync(x => (decimal?)x.Amount, ct) ?? 0m;

        var monthStart = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);
        var jobs = await db.RepairJobs
            .Where(x => x.TechnicianId == technician.Id && x.ReportSubmitted && x.RepairDate >= monthStart)
            .ToListAsync(ct);

        MonthRevenue = jobs.Sum(x => x.NetProfitBase - x.CommissionAmount);
        MonthCommission = jobs.Sum(x => x.CommissionAmount);
        MonthCompleted = jobs.Count;
        ActiveOrders = await db.RepairJobs.CountAsync(x => x.TechnicianId == technician.Id && !x.ReportSubmitted && x.Request.Status != RepairRequestStatus.Cancelled, ct);

        DailyStats = jobs
            .GroupBy(x => x.RepairDate!.Value.Date)
            .OrderBy(x => x.Key)
            .Select(g => new DayStat
            {
                Day = g.Key.ToString("MM/dd"),
                Revenue = g.Sum(x => x.NetProfitBase - x.CommissionAmount),
                Completed = g.Count()
            })
            .ToList();

        RecentJobs = await db.RepairJobs
            .AsNoTracking()
            .Where(x => x.TechnicianId == technician.Id && x.ReportSubmitted)
            .OrderByDescending(x => x.RepairDate ?? DateTime.MinValue)
            .Take(5)
            .Select(x => new RecentJob
            {
                Id = x.Id,
                TrackingCode = x.Request.TrackingCode,
                CustomerName = x.Request.Customer.FirstName + " " + x.Request.Customer.LastName,
                Address = x.Request.Address,
                Date = x.RepairDate.HasValue ? x.RepairDate.Value.ToLocalTime().ToString("yyyy/MM/dd") : "-"
            })
            .ToListAsync(ct);
    }

    public async Task<IActionResult> OnPostToggleAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return Unauthorized();

        var technician = await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (technician is null) return NotFound();

        if (technician.AccountStatus != TechnicianAccountStatus.Active)
            return Forbid();

        var hasActiveJob = await db.RepairJobs.AnyAsync(x => x.TechnicianId == technician.Id && !x.ReportSubmitted && x.Request.Status != RepairRequestStatus.Cancelled, ct);
        if (hasActiveJob)
        {
            TempData["Error"] = "تا پایان تعمیر جاری، تغییر وضعیت کاری ممکن نیست.";
            return RedirectToPage();
        }

        technician.Availability = technician.Availability == TechnicianAvailability.Available
            ? TechnicianAvailability.TemporarilyUnavailable
            : TechnicianAvailability.Available;

        await db.SaveChangesAsync(ct);
        return RedirectToPage();
    }
}

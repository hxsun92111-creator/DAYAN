using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Web.Pages.Technician.Reports;

// گزارشات واقعی تکنسین؛ تمام اعداد از RepairJob و WalletTransaction خوانده می‌شوند.
public sealed class IndexModel(ApplicationDbContext db, UserManager<ApplicationUser> users) : PageModel
{
    public decimal Revenue { get; set; }
    public decimal Commission { get; set; }
    public decimal PartsCost { get; set; }
    public int Completed { get; set; }
    public int Cancelled { get; set; }
    public List<Row> Rows { get; set; } = [];

    public sealed record Row(int Id, string TrackingCode, DateTime? Date, decimal Total, decimal Parts, decimal Commission, string Status);

    public async Task OnGetAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return;
        var tech = await db.Technicians.SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (tech is null) return;

        var jobs = db.RepairJobs.AsNoTracking().Where(x => x.TechnicianId == tech.Id);
        Revenue = await jobs.Where(x => x.ReportSubmitted).SumAsync(x => (decimal?)x.NetProfitBase - x.CommissionAmount, ct) ?? 0m;
        Commission = await jobs.Where(x => x.ReportSubmitted).SumAsync(x => (decimal?)x.CommissionAmount, ct) ?? 0m;
        PartsCost = await jobs.Where(x => x.ReportSubmitted).SumAsync(x => (decimal?)x.PartsCost, ct) ?? 0m;
        Completed = await jobs.CountAsync(x => x.ReportSubmitted, ct);
        Cancelled = await db.RepairRequests.CountAsync(x => x.AssignedTechnicianId == tech.Id && x.Status == RepairRequestStatus.Cancelled, ct);

        Rows = await jobs.OrderByDescending(x => x.RepairDate ?? DateTime.MinValue).Take(50)
            .Select(x => new Row(x.Id, x.Request.TrackingCode, x.RepairDate, x.CustomerTotal, x.PartsCost, x.CommissionAmount, x.ReportSubmitted ? "تکمیل شده" : "در حال انجام"))
            .ToListAsync(ct);
    }
}

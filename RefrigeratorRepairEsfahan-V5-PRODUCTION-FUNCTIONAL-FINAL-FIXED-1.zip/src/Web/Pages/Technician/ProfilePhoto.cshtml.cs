// سرویس نمایش امن عکس پروفایل؛ فایل خارج از wwwroot نگهداری می‌شود.
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Web.Pages.Technician;

public class ProfilePhotoModel(
    ApplicationDbContext db,
    UserManager<ApplicationUser> users) : PageModel
{
    public async Task<IActionResult> OnGetAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null)
            return Unauthorized();

        var technician = await db.Technicians
            .SingleOrDefaultAsync(x => x.UserId == user.Id, ct);

        if (technician?.ProfilePhotoPath is null)
            return NotFound();

        var root = Path.GetFullPath(
            Path.Combine(AppContext.BaseDirectory, "App_Data", "ProfilePhotos"))
            + Path.DirectorySeparatorChar;
        var filePath = Path.GetFullPath(technician.ProfilePhotoPath);

        if (!filePath.StartsWith(root, StringComparison.OrdinalIgnoreCase) ||
            !System.IO.File.Exists(filePath))
        {
            return NotFound();
        }

        var contentType = Path.GetExtension(filePath).ToLowerInvariant() switch
        {
            ".png" => "image/png",
            ".jpg" or ".jpeg" => "image/jpeg",
            _ => "application/octet-stream"
        };

        Response.Headers["Cache-Control"] = "private, no-store";
        var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read);
        return File(stream, contentType);
    }
}

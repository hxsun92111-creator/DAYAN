using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;

namespace RefrigeratorRepair.Web.Pages.Technician.Profile;

/// <summary>نمایش اطلاعات پروفایل تکنسین واردشده؛ فقط داده‌های متعلق به کاربر جاری خوانده می‌شود.</summary>
public class IndexModel(ApplicationDbContext db, UserManager<ApplicationUser> users) : PageModel
{
    public string FullName { get; private set; } = "تکنسین";
    public string PhoneNumber { get; private set; } = "-";
    public string Email { get; private set; } = "-";
    public string Address { get; private set; } = "";
    public string Specialization { get; private set; } = "تعمیر یخچال";
    public int ExperienceYears { get; private set; }
    public string? PhotoPath { get; private set; }
    public TechnicianAccountStatus AccountStatus { get; private set; }
    public string AccountStatusText => AccountStatus switch
    {
        TechnicianAccountStatus.Active => "فعال",
        TechnicianAccountStatus.PendingApproval => "در انتظار تأیید",
        TechnicianAccountStatus.Suspended => "تعلیق‌شده",
        TechnicianAccountStatus.Rejected => "ردشده",
        _ => "نامشخص"
    };
    public int CompletedJobs { get; private set; }
    public int ActiveJobs { get; private set; }

    public async Task OnGetAsync(CancellationToken ct)
    {
        var user = await users.GetUserAsync(User);
        if (user is null) return;
        var technician = await db.Technicians.AsNoTracking().SingleOrDefaultAsync(x => x.UserId == user.Id, ct);
        if (technician is null) return;

        FullName = $"{technician.FirstName} {technician.LastName}".Trim();
        PhoneNumber = technician.PhoneNumber;
        Email = user.Email ?? "-";
        Address = technician.Address;
        Specialization = technician.Specialization;
        ExperienceYears = technician.ExperienceYears;
        PhotoPath = technician.ProfilePhotoPath;
        AccountStatus = technician.AccountStatus;
        CompletedJobs = await db.RepairJobs.CountAsync(x => x.TechnicianId == technician.Id && x.ReportSubmitted, ct);
        ActiveJobs = await db.RepairJobs.CountAsync(x => x.TechnicianId == technician.Id && !x.ReportSubmitted && x.Request.Status != RepairRequestStatus.Cancelled, ct);
    }
}

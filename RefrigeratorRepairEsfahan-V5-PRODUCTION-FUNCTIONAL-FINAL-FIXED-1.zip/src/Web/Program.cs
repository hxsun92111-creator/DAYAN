// ================================================================
// Program.cs نقطه شروع برنامه ASP.NET Core است.
// در این نسخه، تنظیمات امنیتی Production به صورت صریح تعریف شده‌اند.
// ================================================================

using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Application.Services;
using RefrigeratorRepair.Infrastructure.Data;
using RefrigeratorRepair.Infrastructure.Identity;
using RefrigeratorRepair.Infrastructure.Payments;
using RefrigeratorRepair.Infrastructure.Repositories;
using RefrigeratorRepair.Web;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------
// Configuration / Secrets
// ---------------------------------------------------------------
// Connection String عمداً رمز عبور را از appsettings.json نمی‌گیرد.
// در Development از User Secrets و در Production از Secret/Environment
// Variable استفاده کنید.
var cs = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException(
        "DefaultConnection تنظیم نشده است. Connection String را در User Secrets یا Environment Variable قرار دهید.");

// ---------------------------------------------------------------
// تنظیمات مالی با Validation در Startup
// ---------------------------------------------------------------
builder.Services
    .AddOptions<PaymentOptions>()
    .Bind(builder.Configuration.GetSection("Payment"));

if (builder.Environment.IsProduction())
{
    builder.Services
        .AddOptions<PaymentOptions>()
        .Validate(x => !string.IsNullOrWhiteSpace(x.MerchantId), "Payment:MerchantId تنظیم نشده است.")
        .Validate(x => Uri.TryCreate(x.PublicBaseUrl, UriKind.Absolute, out var uri) && uri.Scheme == Uri.UriSchemeHttps, "Payment:PublicBaseUrl باید یک URL کامل HTTPS باشد.")
        .ValidateOnStart();
}

builder.Services
    .AddOptions<CommissionOptions>()
    .Bind(builder.Configuration.GetSection("Commission"))
    .Validate(x => x.TechnicianRate > 0m && x.TechnicianRate <= 1m,
        "TechnicianRate باید بزرگ‌تر از صفر و حداکثر ۱ باشد.")
    .Validate(x => x.MinimumWalletTopUp >= 1_000_000m,
        "MinimumWalletTopUp نمی‌تواند کمتر از ۱,۰۰۰,۰۰۰ تومان باشد.")
    .ValidateOnStart();

// ---------------------------------------------------------------
// DbContext
// ---------------------------------------------------------------
// نسخه MySQL از Configuration خوانده می‌شود تا AutoDetect در هر Startup
// به اتصال تشخیصی اضافی نیاز نداشته باشد.
var serverVersionText = builder.Configuration["Database:ServerVersion"]
    ?? "8.0.36-mysql";

var serverVersion = ServerVersion.Parse(serverVersionText);

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(cs, serverVersion));

// ---------------------------------------------------------------
// ASP.NET Core Identity
// ---------------------------------------------------------------
builder.Services
    .AddDefaultIdentity<ApplicationUser>(options =>
    {
        // برای پروژه فعلی، تأیید ایمیل اجباری نیست؛ تأیید تکنسین توسط مدیر انجام می‌شود.
        options.SignIn.RequireConfirmedAccount = false;

        // Password Policy
        options.Password.RequiredLength = 12;
        options.Password.RequireDigit = true;
        options.Password.RequireUppercase = true;
        options.Password.RequireLowercase = true;
        options.Password.RequireNonAlphanumeric = true;

        // جلوگیری از Brute Force روی حساب کاربری.
        options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
        options.Lockout.MaxFailedAccessAttempts = 5;
        options.Lockout.AllowedForNewUsers = true;

        options.User.RequireUniqueEmail = false;
    })
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();

// تنظیمات صریح Cookie احراز هویت.
builder.Services.ConfigureApplicationCookie(options =>
{
    options.Cookie.Name = "RefrigeratorRepair.Auth";
    options.Cookie.HttpOnly = true;
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    options.Cookie.SameSite = SameSiteMode.Lax;

    options.SlidingExpiration = true;
    options.ExpireTimeSpan = TimeSpan.FromHours(8);

    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
});

// ---------------------------------------------------------------
// Razor Pages و Authorization Policies
// ---------------------------------------------------------------
builder.Services.AddRazorPages(options =>
{
    options.Conventions.AuthorizeFolder("/Admin", "AdminOnly");
    options.Conventions.AuthorizeFolder("/Technician", "TechnicianOnly");
});

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", policy =>
        policy.RequireRole(AppRoles.Admin));

    options.AddPolicy("TechnicianOnly", policy =>
        policy.RequireRole(AppRoles.Technician));
});

// ---------------------------------------------------------------
// Rate Limiting
// ---------------------------------------------------------------
// Rate Limit جای Lockout را نمی‌گیرد؛ این دو لایه مکمل هم هستند.
// Lockout بر اساس حساب کاربری است و Rate Limit جلوی حجم بالای Request را می‌گیرد.
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    // محدودیت عمومی برای هر IP.
    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(context =>
        RateLimitPartition.GetFixedWindowLimiter(
            context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 120,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0,
                AutoReplenishment = true
            }));

    // Login محدودتر از سایر صفحات است.
    options.AddPolicy("Auth", context =>
        RateLimitPartition.GetFixedWindowLimiter(
            context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(15),
                QueueLimit = 0,
                AutoReplenishment = true
            }));
});

// ---------------------------------------------------------------
// Dependency Injection
// ---------------------------------------------------------------
builder.Services.AddScoped<IRepairRequestRepository, RepairRequestRepository>();
builder.Services.AddScoped<IServiceCatalogRepository, ServiceCatalogRepository>();
builder.Services.AddScoped<ITechnicianRepository, TechnicianRepository>();
builder.Services.AddScoped<ICustomerRepository, CustomerRepository>();
builder.Services.AddScoped<IRepairJobRepository, RepairJobRepository>();
builder.Services.AddScoped<IWalletRepository, WalletRepository>();
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();

builder.Services.AddScoped<IRepairRequestService, RepairRequestService>();
builder.Services.AddScoped<IRepairJobService, RepairJobService>();
builder.Services.AddScoped<IWalletService, WalletService>();

builder.Services.AddHttpClient<ZarinPalGateway>();
if (builder.Environment.IsDevelopment())
    builder.Services.AddScoped<IPaymentGateway, FakePaymentGateway>();
else
    builder.Services.AddScoped<IPaymentGateway, ZarinPalGateway>();
builder.Services.AddHostedService<OfferDispatchWorker>();

// پرداخت Production از درگاه واقعی استفاده می‌کند؛ در Development نیز همان abstraction فعال است.
// برای تست محلی می‌توان Payment:MerchantId را به Test Merchant بدهید یا Gateway را موقتاً Mock کنید.

var app = builder.Build();

// ---------------------------------------------------------------
// Production Error Handling / HSTS
// ---------------------------------------------------------------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

// ---------------------------------------------------------------
// Security Headers
// ---------------------------------------------------------------
app.Use(async (context, next) =>
{
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["X-Frame-Options"] = "DENY";
    context.Response.Headers["Referrer-Policy"] = "strict-origin-when-cross-origin";
    context.Response.Headers["Permissions-Policy"] =
        "camera=(), microphone=(), geolocation=(self)";

    // صفحات مدیریتی و عملیاتی نباید توسط Browser/Proxy به شکل عمومی Cache شوند.
    if (context.Request.Path.StartsWithSegments("/Admin") ||
        context.Request.Path.StartsWithSegments("/Technician"))
    {
        context.Response.Headers["Cache-Control"] = "no-store, no-cache, must-revalidate";
        context.Response.Headers["Pragma"] = "no-cache";
    }

    // CSP با توجه به Bootstrap، Leaflet، Google Fonts و OpenStreetMap تنظیم شده است.
    // چون نسخه فعلی چند Script inline دارد، unsafe-inline موقتاً لازم است.
    // در نسخه سخت‌گیرانه‌تر بعدی می‌توانیم آن‌ها را با nonce جایگزین کنیم.
    context.Response.Headers["Content-Security-Policy"] =
        "default-src 'self'; " +
        "base-uri 'self'; " +
        "object-src 'none'; " +
        "frame-ancestors 'none'; " +
        "form-action 'self'; " +
        "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com; " +
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com https://fonts.googleapis.com; " +
        "font-src 'self' https://fonts.gstatic.com; " +
        "img-src 'self' data: blob: https://*.tile.openstreetmap.org https://unpkg.com; " +
        "connect-src 'self';";

    await next();
});

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();

// در Production/Development هر دو محیط Migrationهای EF Core را اجرا می‌کنند.
// این کار باعث می‌شود Schema واقعی پروژه از مدل کد عقب نماند.
await using (var scope = app.Services.CreateAsyncScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    await db.Database.MigrateAsync();
}

// Seed فقط در Development اجرا می‌شود.
// در Production هیچ Admin با رمز ثابت ساخته نمی‌شود.
if (app.Environment.IsDevelopment())
{
    await SeedData.InitializeAsync(app.Services);
}

await app.RunAsync();

// Worker پس‌زمینه برای توزیع سفارش‌ها.
// هر دقیقه:
// 1) پیشنهادهای بیشتر از ۳۰ دقیقه را منقضی می‌کند.
// 2) اگر یک درخواست هنوز پذیرفته نشده و کمتر از ۵ پیشنهاد فعال دارد، آن را تکمیل می‌کند.
// 3) تکنسینی که همان روز پیشنهاد گرفته دوباره در همان روز انتخاب نمی‌شود.
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;
using RefrigeratorRepair.Infrastructure.Data;

namespace RefrigeratorRepair.Web;

public sealed class OfferDispatchWorker(IServiceScopeFactory scopeFactory, ILogger<OfferDispatchWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = scopeFactory.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
                var now = DateTime.UtcNow;
                var dayStart = now.Date;

                // پیشنهادهای منقضی‌شده دیگر قابل قبول نیستند.
                await db.TechnicianOffers
                    .Where(x => x.Status == OfferStatus.Pending && x.ExpiresAt <= now)
                    .ExecuteUpdateAsync(x => x.SetProperty(o => o.Status, OfferStatus.Expired), stoppingToken);

                var requests = await db.RepairRequests
                    .Include(x => x.Offers)
                    .Where(x => x.Status == RepairRequestStatus.New || x.Status == RepairRequestStatus.WaitingForAssignment)
                    .Where(x => x.AssignedTechnicianId == null)
                    .OrderBy(x => x.CreatedAt)
                    .Take(100)
                    .ToListAsync(stoppingToken);

                foreach (var request in requests)
                {
                    var pendingCount = request.Offers.Count(x => x.Status == OfferStatus.Pending && x.ExpiresAt > now);
                    var needed = 5 - pendingCount;
                    if (needed <= 0) continue;

                    // Materialize IDs first so EF translates the filter to a simple IN clause.
                    var excludedTechnicianIds = request.Offers
                        .Select(o => o.TechnicianId)
                        .Distinct()
                        .ToList();

                    var available = await db.Technicians
                        .Where(x => x.AccountStatus == TechnicianAccountStatus.Active)
                        .Where(x => x.Availability == TechnicianAvailability.Available)
                        .Where(x => !x.Jobs.Any(j => !j.ReportSubmitted && j.Request.Status != RepairRequestStatus.Cancelled))
                        .Where(x => !x.Offers.Any(o => o.SentAt >= dayStart))
                        .Where(x => !excludedTechnicianIds.Contains(x.Id))
                        .OrderBy(x => x.CreatedAt)
                        .Take(needed)
                        .ToListAsync(stoppingToken);

                    foreach (var technician in available)
                    {
                        request.Offers.Add(new TechnicianOffer
                        {
                            Request = request,
                            TechnicianId = technician.Id,
                            SentAt = now,
                            ExpiresAt = now.AddMinutes(30),
                            Status = OfferStatus.Pending
                        });
                    }

                    if (available.Count > 0)
                        request.Status = RepairRequestStatus.WaitingForAssignment;
                }

                await db.SaveChangesAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                // خطای یک دور توزیع نباید Worker را متوقف کند؛ اما حتماً باید ثبت شود.
                logger.LogError(ex, "Offer dispatch worker iteration failed.");
            }

            await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
        }
    }
}

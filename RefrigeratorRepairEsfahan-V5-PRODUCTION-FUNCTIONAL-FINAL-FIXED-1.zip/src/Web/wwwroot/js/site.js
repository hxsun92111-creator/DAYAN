// این فایل برای رفتارهای کوچک رابط کاربری استفاده می‌شود؛ منطق کسب‌وکار در JS قرار نمی‌گیرد.
document.addEventListener('DOMContentLoaded',()=>document.querySelectorAll('[data-auto-hide]').forEach(x=>setTimeout(()=>x.remove(),5000)));

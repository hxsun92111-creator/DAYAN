// DTOها مدل انتقال داده بین UI و Application هستند.
using System.ComponentModel.DataAnnotations;

namespace RefrigeratorRepair.Application.DTOs;

public sealed class CreateRepairRequestDto
{
    [Required, MaxLength(80)] public string FirstName { get; set; } = "";
    [Required, MaxLength(100)] public string LastName { get; set; } = "";
    [Required, Phone, MaxLength(20)] public string PhoneNumber { get; set; } = "";

    // شناسه واقعی خدمت از ServiceCatalog؛ کاربر نمی‌تواند عنوان دلخواهی به سرور تحمیل کند.
    [Range(1, int.MaxValue)] public int ServiceCatalogId { get; set; }

    [Required, MaxLength(80)] public string DeviceBrand { get; set; } = "";
    [Required, MaxLength(100)] public string DeviceType { get; set; } = "";
    [Required, MaxLength(1000)] public string ProblemDescription { get; set; } = "";
    [Required, MaxLength(1000)] public string Address { get; set; } = "";
    [Range(-90, 90)] public decimal Latitude { get; set; }
    [Range(-180, 180)] public decimal Longitude { get; set; }
    [Required] public DateTime? PreferredVisitDate { get; set; }
    [Required, MaxLength(80)] public string PreferredVisitWindow { get; set; } = "";
}

public sealed class CompleteRepairJobDto
{
    public int JobId { get; set; }
    [Required] public string ServiceDescription { get; set; } = "";
    public string? TechnicianDiagnosis { get; set; }
    [Range(0, double.MaxValue)] public decimal TravelCost { get; set; }
    [Range(0, double.MaxValue)] public decimal LaborCost { get; set; }
    [Range(0, double.MaxValue)] public decimal CustomerTotal { get; set; }
    public List<RepairPartInputDto> Parts { get; set; } = new();
}

public sealed class RepairPartInputDto
{
    [Required] public string PartName { get; set; } = "";
    [Range(1, 1000)] public int Quantity { get; set; } = 1;
    [Range(typeof(decimal), "0", "79228162514264337593543950335")] public decimal UnitPrice { get; set; }
}

public sealed class AddPartDto
{
    public int JobId { get; set; }
    [Required] public string PartName { get; set; } = "";
    [Range(1, 1000)] public int Quantity { get; set; } = 1;
    [Range(typeof(decimal), "0", "79228162514264337593543950335")] public decimal UnitPrice { get; set; }
}

public sealed class TopUpWalletDto
{
    // طبق تصمیم جدید، حداقل شارژ ۱,۰۰۰,۰۰۰ تومان است.
    [Range(typeof(decimal), "1000000", "79228162514264337593543950335")]
    public decimal Amount { get; set; }
}

// اطلاعات پایه‌ای که تکنسین در ثبت‌نام عمومی وارد می‌کند.
// مدارک فیزیکی در Web دریافت و در فضای خصوصی ذخیره می‌شوند.
public sealed class TechnicianRegistrationDto
{
    [Required, MaxLength(80)] public string FirstName { get; set; } = "";
    [Required, MaxLength(100)] public string LastName { get; set; } = "";
    [Required, StringLength(10, MinimumLength = 10)] public string NationalId { get; set; } = "";
    [Required, Phone, MaxLength(20)] public string PhoneNumber { get; set; } = "";
    [Required, MaxLength(1000)] public string Address { get; set; } = "";
    [Range(0, 60)] public int ExperienceYears { get; set; }
    [Required, MaxLength(200)] public string Specialization { get; set; } = "";

    // رمز عبور توسط خود تکنسین انتخاب می‌شود؛ شماره تلفن به عنوان Password استفاده نمی‌شود.
    [Required, MinLength(12)] public string Password { get; set; } = "";
}

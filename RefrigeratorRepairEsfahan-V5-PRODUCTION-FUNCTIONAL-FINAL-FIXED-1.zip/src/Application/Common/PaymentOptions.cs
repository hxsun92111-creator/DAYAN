namespace RefrigeratorRepair.Application.Common;

// تنظیمات درگاه پرداخت واقعی از Secret/Environment خوانده می‌شود.
// MerchantId هرگز نباید داخل سورس‌کد یا Git قرار بگیرد.
public sealed class PaymentOptions
{
    public string MerchantId { get; set; } = "";
    public string ApiBaseUrl { get; set; } = "https://payment.zarinpal.com/pg/v4/payment";
    public string StartPayUrl { get; set; } = "https://www.zarinpal.com/pg/StartPay/{0}";
    public string PublicBaseUrl { get; set; } = "";
}

// تنظیمات مالی برنامه.
// این مقادیر از Configuration خوانده می‌شوند و قبل از اجرا اعتبارسنجی می‌شوند.
namespace RefrigeratorRepair.Application.Common;

public sealed class CommissionOptions
{
    public decimal TechnicianRate { get; set; }

    public decimal MinimumWalletTopUp { get; set; }
}

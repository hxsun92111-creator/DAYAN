namespace RefrigeratorRepair.Application.Common;

// ================================================================
// Result Pattern
// ================================================================
// Result غیر Generic برای عملیات‌هایی که فقط موفق/ناموفق هستند.
// مثال: حذف تکنسین، کسر کمیسیون، تغییر وضعیت و ...
public class Result
{
    public bool Success { get; protected init; }
    public string? Error { get; protected init; }

    protected Result() { }

    public static Result Ok() => new() { Success = true };
    public static Result Fail(string error) => new() { Success = false, Error = error };
}

// Result<T> زمانی استفاده می‌شود که علاوه بر موفقیت، یک Value هم برگردانیم.
public sealed class Result<T> : Result
{
    public T? Value { get; private init; }

    private Result() { }

    public static Result<T> Ok(T value) => new()
    {
        Success = true,
        Value = value
    };

    public new static Result<T> Fail(string error) => new()
    {
        Success = false,
        Error = error
    };
}

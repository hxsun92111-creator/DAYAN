using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.DTOs;

namespace RefrigeratorRepair.Application.Interfaces;

public interface IRepairRequestService
{
    Task<Result<string>> CreateAsync(CreateRepairRequestDto dto, CancellationToken ct = default);
    Task<int> OfferToTechniciansAsync(int requestId, CancellationToken ct = default);
}

public interface IRepairJobService
{
    Task<Result> AddPartAsync(AddPartDto dto, CancellationToken ct = default);
    Task<Result> CompleteAsync(int jobId, CompleteRepairJobDto dto, CancellationToken ct = default);
}

public interface IWalletService
{
    Task<Result<string>> CreateTopUpAsync(int technicianId, decimal amount, CancellationToken ct = default);
    Task<Result> ApplyTopUpAsync(string authority, string referenceId, CancellationToken ct = default);
    Task<Result> DeductCommissionAsync(int technicianId, decimal amount, int jobId, string description, CancellationToken ct = default);
    Task<decimal> GetBalanceAsync(int technicianId, CancellationToken ct = default);
}

public interface IPaymentGateway
{
    Task<PaymentStartResult> StartAsync(decimal amount, string callbackUrl, CancellationToken ct = default);
    Task<PaymentVerifyResult> VerifyAsync(string authority, decimal amount, CancellationToken ct = default);
}

public record PaymentStartResult(bool Success, string? Authority, string? PaymentUrl, string? Error);
public record PaymentVerifyResult(bool Success, string? ReferenceId, string? Error);

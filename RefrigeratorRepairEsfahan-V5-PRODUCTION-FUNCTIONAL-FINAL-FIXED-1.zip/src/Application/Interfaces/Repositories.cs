using RefrigeratorRepair.Domain.Entities;
namespace RefrigeratorRepair.Application.Interfaces;

public interface ICustomerRepository
{
    Task<Customer?> FindByPhoneAsync(string phone, CancellationToken ct = default);
    Task<List<Customer>> GetAllAsync(CancellationToken ct = default);
    Task<Customer?> GetWithHistoryAsync(int id, CancellationToken ct = default);
}

// Repository قرارداد دسترسی به داده است. پیاده‌سازی در Infrastructure قرار دارد.

public interface IServiceCatalogRepository
{
    // فقط خدمات فعال برای فرم عمومی مشتری قابل انتخاب هستند.
    Task<List<ServiceCatalog>> GetActiveAsync(CancellationToken ct = default);
    Task<ServiceCatalog?> GetActiveByIdAsync(int id, CancellationToken ct = default);
}

public interface IRepairRequestRepository
{
    Task AddAsync(RepairRequest request, CancellationToken ct = default);
    Task<RepairRequest?> GetAsync(int id, CancellationToken ct = default);
    Task<List<RepairRequest>> GetActiveAsync(CancellationToken ct = default);
}

public interface ITechnicianRepository
{
    Task<Technician?> GetAsync(int id, CancellationToken ct = default);
    Task<List<Technician>> GetAvailableAsync(CancellationToken ct = default);
    Task<List<Technician>> GetAvailableForOfferAsync(DateTime utcDayStart, int count, CancellationToken ct = default);
    Task<List<Technician>> GetAllAsync(CancellationToken ct = default);
}

public interface IRepairJobRepository
{
    Task<RepairJob?> GetAsync(int id, CancellationToken ct = default);
    Task<List<RepairJob>> GetHistoryAsync(int technicianId, CancellationToken ct = default);
}

public interface IWalletRepository
{
    Task<Technician?> GetTechnicianAsync(int technicianId, CancellationToken ct = default);
    Task<decimal> GetBalanceAsync(int technicianId, CancellationToken ct = default);
    void AddTransaction(WalletTransaction transaction);
    Task<PaymentTransaction?> GetPaymentByAuthorityAsync(string authority, CancellationToken ct = default);
    void AddPayment(PaymentTransaction payment);
}

public interface IUnitOfWork
{
    Task<int> SaveChangesAsync(CancellationToken ct = default);
    Task ExecuteInTransactionAsync(Func<Task> action, CancellationToken ct = default);
}

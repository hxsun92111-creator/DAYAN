// Use Case ثبت پایان تعمیر و محاسبه سهم مرکز.
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.DTOs;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;

namespace RefrigeratorRepair.Application.Services;

public sealed class RepairJobService(
    IRepairJobRepository jobs,
    IUnitOfWork uow,
    IWalletService wallet,
    IOptions<CommissionOptions> commissionOptions,
    ILogger<RepairJobService> logger) : IRepairJobService
{
    private readonly CommissionOptions _options = commissionOptions.Value;

    public async Task<Result> AddPartAsync(
        AddPartDto dto,
        CancellationToken ct = default)
    {
        if (dto.JobId <= 0)
            return Result.Fail("شناسه تعمیر نامعتبر است.");

        if (string.IsNullOrWhiteSpace(dto.PartName))
            return Result.Fail("نام قطعه الزامی است.");

        if (dto.Quantity <= 0 || dto.Quantity > 1000)
            return Result.Fail("تعداد قطعه معتبر نیست.");

        if (dto.UnitPrice < 0 || dto.UnitPrice > 100_000_000m)
            return Result.Fail("قیمت قطعه معتبر نیست.");

        var job = await jobs.GetAsync(dto.JobId, ct);
        if (job is null)
            return Result.Fail("تعمیر پیدا نشد.");

        if (job.ReportSubmitted)
            return Result.Fail("گزارش ثبت‌شده قابل ویرایش نیست.");

        job.Parts.Add(new RepairPart
        {
            PartName = dto.PartName.Trim(),
            Quantity = dto.Quantity,
            UnitPrice = dto.UnitPrice
        });

        // CustomerTotal مبلغی است که واقعاً از مشتری دریافت شده و
        // نباید صرفاً با اضافه شدن یک قطعه به صورت خودکار تغییر کند.
        await uow.SaveChangesAsync(ct);

        logger.LogInformation(
            "Part added to repair job {JobId}. Quantity={Quantity}",
            dto.JobId,
            dto.Quantity);

        return Result.Ok();
    }

    public async Task<Result> CompleteAsync(
        int jobId,
        CompleteRepairJobDto dto,
        CancellationToken ct = default)
    {
        if (jobId <= 0)
            return Result.Fail("شناسه تعمیر نامعتبر است.");

        if (string.IsNullOrWhiteSpace(dto.ServiceDescription))
            return Result.Fail("شرح خدمات انجام‌شده الزامی است.");

        if (dto.Parts.Count > 100)
            return Result.Fail("تعداد قطعات بیش از حد مجاز است.");

        if (dto.TravelCost < 0 ||
            dto.LaborCost < 0 ||
            dto.CustomerTotal < 0)
        {
            return Result.Fail("مبالغ تعمیر نمی‌توانند منفی باشند.");
        }

        foreach (var part in dto.Parts)
        {
            if (string.IsNullOrWhiteSpace(part.PartName) ||
                part.Quantity <= 0 ||
                part.Quantity > 1000 ||
                part.UnitPrice < 0 ||
                part.UnitPrice > 100_000_000m)
            {
                return Result.Fail("اطلاعات یکی از قطعات معتبر نیست.");
            }
        }

        try
        {
            Result? finalResult = null;

            await uow.ExecuteInTransactionAsync(async () =>
            {
                // Job داخل همان Transaction خوانده می‌شود تا بررسی وضعیت
                // و ثبت مالی از هم جدا نباشند.
                var job = await jobs.GetAsync(jobId, ct);

                if (job is null)
                {
                    finalResult = Result.Fail("تعمیر پیدا نشد.");
                    return;
                }

                if (job.ReportSubmitted)
                {
                    finalResult = Result.Fail("گزارش این تعمیر قبلاً ثبت شده است.");
                    return;
                }

                job.Parts.Clear();
                foreach (var part in dto.Parts)
                {
                    job.Parts.Add(new RepairPart
                    {
                        PartName = part.PartName.Trim(),
                        Quantity = part.Quantity,
                        UnitPrice = part.UnitPrice
                    });
                }

                job.ServiceDescription = dto.ServiceDescription.Trim();
                job.TechnicianDiagnosis = dto.TechnicianDiagnosis?.Trim();
                job.TravelCost = dto.TravelCost;
                job.LaborCost = dto.LaborCost;
                job.CustomerTotal = dto.CustomerTotal;
                job.PartsCost = job.Parts.Sum(x => x.TotalPrice);
                job.NetProfitBase = Math.Max(
                    0m,
                    job.CustomerTotal - job.PartsCost - job.TravelCost);

                job.CommissionAmount = Math.Round(
                    job.NetProfitBase * _options.TechnicianRate,
                    0,
                    MidpointRounding.AwayFromZero);

                var commissionResult = await wallet.DeductCommissionAsync(
                    job.TechnicianId,
                    job.CommissionAmount,
                    job.Id,
                    $"کسر {_options.TechnicianRate:P0} سهم مرکز از تعمیر {job.Request.TrackingCode}",
                    ct);

                if (!commissionResult.Success)
                {
                    finalResult = commissionResult;
                    throw new RepairJobOperationException(
                        commissionResult.Error ?? "کسر کمیسیون انجام نشد.");
                }

                job.ReportSubmitted = true;
                job.RepairDate = DateTime.UtcNow;
                job.Request.Status = RepairRequestStatus.Completed;
                job.Request.CompletedAt = DateTime.UtcNow;
                job.Technician.Availability = TechnicianAvailability.Available;

                finalResult = Result.Ok();

                logger.LogInformation(
                    "Repair job {JobId} completed. Commission={CommissionAmount}",
                    jobId,
                    job.CommissionAmount);
            }, ct);

            return finalResult ?? Result.Fail("عملیات انجام نشد.");
        }
        catch (RepairJobOperationException ex)
        {
            return Result.Fail(ex.Message);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to complete repair job {JobId}.", jobId);
            return Result.Fail(
                "ثبت گزارش تعمیر انجام نشد. لطفاً دوباره تلاش کنید.");
        }
    }

    private sealed class RepairJobOperationException(string message)
        : Exception(message);
}

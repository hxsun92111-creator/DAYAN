// منطق کیف پول. موجودی مستقیم روی Technician ذخیره نمی‌شود و از Ledger محاسبه می‌شود.
using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;
using Microsoft.Extensions.Options;

namespace RefrigeratorRepair.Application.Services;

public sealed class WalletService(
    IWalletRepository wallet,
    IPaymentGateway gateway,
    IUnitOfWork uow,
    Microsoft.Extensions.Logging.ILogger<WalletService> logger,
    IOptions<CommissionOptions> commissionOptions) : IWalletService
{
    public async Task<decimal> GetBalanceAsync(int technicianId, CancellationToken ct = default)
        => await wallet.GetBalanceAsync(technicianId, ct);

    public async Task<Result<string>> CreateTopUpAsync(
        int technicianId,
        decimal amount,
        CancellationToken ct = default)
    {
        if (amount < commissionOptions.Value.MinimumWalletTopUp)
            return Result<string>.Fail($"حداقل مبلغ شارژ کیف پول {commissionOptions.Value.MinimumWalletTopUp:N0} تومان است.");

        if (amount > 1_000_000_000_000m)
            return Result<string>.Fail("مبلغ شارژ بیش از سقف مجاز هر تراکنش است.");

        var technician = await wallet.GetTechnicianAsync(technicianId, ct);
        if (technician is null)
            return Result<string>.Fail("تکنسین پیدا نشد.");

        // ابتدا رکورد Pending ساخته می‌شود تا تلاش پرداخت قابل رهگیری باشد.
        var payment = new PaymentTransaction
        {
            TechnicianId = technicianId,
            Amount = amount,
            Authority = null,
            Status = PaymentTransactionStatus.Pending
        };

        wallet.AddPayment(payment);
        await uow.SaveChangesAsync(ct);

        // Callback با PaymentTransaction.Id برمی‌گردد؛ Authority واقعی را خود درگاه تولید می‌کند.
        var result = await gateway.StartAsync(
            amount,
            "/Technician/Wallet/Callback",
            ct);

        if (!result.Success || string.IsNullOrWhiteSpace(result.Authority))
        {
            payment.Status = PaymentTransactionStatus.Failed;
            await uow.SaveChangesAsync(ct);
            return Result<string>.Fail(result.Error ?? "خطای درگاه پرداخت.");
        }

        payment.Authority = result.Authority;
        await uow.SaveChangesAsync(ct);

        return Result<string>.Ok(result.PaymentUrl!);
    }

    public async Task<Result> ApplyTopUpAsync(
        string authority,
        string referenceId,
        CancellationToken ct = default)
    {
        _ = referenceId;

        // تمام تغییرات کیف پول داخل یک Transaction انجام می‌شود.
        Result result = Result.Ok();

        await uow.ExecuteInTransactionAsync(async () =>
        {
            var payment = await wallet.GetPaymentByAuthorityAsync(authority, ct);

            if (payment is null || string.IsNullOrWhiteSpace(payment.Authority))
            {
                result = Result.Fail("تراکنش پرداخت پیدا نشد یا Authority معتبر نیست.");
                return;
            }

            // Callback ممکن است دوبار ارسال شود؛ نباید دوبار کیف پول را شارژ کنیم.
            if (payment.Status == PaymentTransactionStatus.Verified)
            {
                result = Result.Ok();
                return;
            }

            var verify = await gateway.VerifyAsync(authority, payment.Amount, ct);

            if (!verify.Success)
            {
                payment.Status = PaymentTransactionStatus.Failed;
                result = Result.Fail(verify.Error ?? "پرداخت تأیید نشد.");
                return;
            }

            var balance = await wallet.GetBalanceAsync(payment.TechnicianId, ct);
            var newBalance = balance + payment.Amount;

            // ReferenceId معتبر باید از پاسخ Verify درگاه بیاید؛ مقدار Callback
            // صرفاً کمکی است و نباید جایگزین پاسخ معتبر Provider شود.
            if (string.IsNullOrWhiteSpace(verify.ReferenceId))
            {
                payment.Status = PaymentTransactionStatus.Failed;
                result = Result.Fail("شناسه مرجع پرداخت از درگاه دریافت نشد.");
                return;
            }

            payment.ReferenceId = verify.ReferenceId;
            payment.Status = PaymentTransactionStatus.Verified;
            payment.VerifiedAt = DateTime.UtcNow;

            wallet.AddTransaction(new WalletTransaction
            {
                TechnicianId = payment.TechnicianId,
                Type = WalletTransactionType.TopUp,
                Amount = payment.Amount,
                BalanceAfter = newBalance,
                PaymentTransactionId = payment.Id,
                Description = "شارژ کیف پول از طریق درگاه"
            });

            result = Result.Ok();
        }, ct);

        return result;
    }

    public async Task<Result> DeductCommissionAsync(
        int technicianId,
        decimal amount,
        int jobId,
        string description,
        CancellationToken ct = default)
    {
        if (technicianId <= 0 || jobId <= 0)
            return Result.Fail("اطلاعات مالی نامعتبر است.");

        if (amount < 0)
            return Result.Fail("مبلغ کمیسیون نمی‌تواند منفی باشد.");

        var technician = await wallet.GetTechnicianAsync(technicianId, ct);
        if (technician is null)
            return Result.Fail("تکنسین پیدا نشد.");

        var balance = await wallet.GetBalanceAsync(technicianId, ct);
        if (balance < amount)
        {
            return Result.Fail(
                $"موجودی کیف پول کافی نیست. مبلغ لازم برای کمیسیون: {amount:N0} تومان.");
        }

        // حتی برای کمیسیون صفر نیز یک Ledger Entry ثبت می‌کنیم.
        // این رکورد با Unique Index روی RepairJobId جلوی تکمیل دوباره همان Job
        // در شرایط همزمانی را می‌گیرد.
        wallet.AddTransaction(new WalletTransaction
        {
            TechnicianId = technicianId,
            Type = WalletTransactionType.CommissionDebit,
            Amount = -amount,
            BalanceAfter = balance - amount,
            RepairJobId = jobId,
            Description = description
        });

        return Result.Ok();
    }

}

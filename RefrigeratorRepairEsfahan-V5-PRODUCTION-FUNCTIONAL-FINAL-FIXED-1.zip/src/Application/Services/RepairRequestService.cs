// Use Caseهای مربوط به ثبت و توزیع درخواست تعمیر.
using Microsoft.Extensions.Logging;
using RefrigeratorRepair.Application.Common;
using RefrigeratorRepair.Application.DTOs;
using RefrigeratorRepair.Application.Interfaces;
using RefrigeratorRepair.Domain.Entities;
using RefrigeratorRepair.Domain.Enums;

namespace RefrigeratorRepair.Application.Services;

public sealed class RepairRequestService(
    IRepairRequestRepository requests,
    ITechnicianRepository technicians,
    ICustomerRepository customers,
    IServiceCatalogRepository serviceCatalog,
    IUnitOfWork uow,
    ILogger<RepairRequestService> logger) : IRepairRequestService
{
    public async Task<Result<string>> CreateAsync(
        CreateRepairRequestDto dto,
        CancellationToken ct = default)
    {
        try
        {
            var normalizedPhone = NormalizePhone(dto.PhoneNumber);

            if (!IsValidIranianMobile(normalizedPhone))
                return Result<string>.Fail("شماره موبایل معتبر نیست.");

            // خدمت باید از جدول ServiceCatalog و فقط بین خدمات فعال انتخاب شده باشد.
            // این بررسی سمت سرور است و به hidden input یا JavaScript اعتماد نمی‌کند.
            var selectedService = await serviceCatalog.GetActiveByIdAsync(dto.ServiceCatalogId, ct);
            if (selectedService is null)
                return Result<string>.Fail("خدمت انتخاب‌شده معتبر یا فعال نیست.");

            var code = CreateTrackingCode();
            var now = DateTime.UtcNow;
            var existing = await customers.FindByPhoneAsync(normalizedPhone, ct);

            Customer customer;

            if (existing is null)
            {
                customer = new Customer
                {
                    FirstName = dto.FirstName.Trim(),
                    LastName = dto.LastName.Trim(),
                    PhoneNumber = normalizedPhone,
                    CreatedAt = now,
                    LastOrderAt = now
                };
            }
            else
            {
                customer = existing;
                customer.LastOrderAt = now;
            }

            var request = new RepairRequest
            {
                TrackingCode = code,
                Customer = customer,
                ServiceCatalogId = selectedService.Id,
                DeviceBrand = dto.DeviceBrand.Trim(),
                DeviceType = dto.DeviceType.Trim(),
                PreferredVisitDate = dto.PreferredVisitDate?.Date,
                PreferredVisitWindow = string.IsNullOrWhiteSpace(dto.PreferredVisitWindow) ? null : dto.PreferredVisitWindow.Trim(),
                ProblemDescription = dto.ProblemDescription.Trim(),
                Address = dto.Address.Trim(),
                Latitude = dto.Latitude,
                Longitude = dto.Longitude,
                CreatedAt = now,
                Status = RepairRequestStatus.New
            };

            await requests.AddAsync(request, ct);
            await uow.SaveChangesAsync(ct);

            // توزیع اولیه یک کار تکمیلی است؛ اگر موقتاً شکست بخورد،
            // خود درخواست نباید از دید مشتری ناموفق اعلام شود. Worker آن را دوباره بررسی می‌کند.
            try
            {
                await OfferToTechniciansAsync(request.Id, ct);
            }
            catch (Exception ex)
            {
                logger.LogWarning(
                    ex,
                    "Initial technician offer dispatch failed for request {RequestId}; worker will retry.",
                    request.Id);
            }

            return Result<string>.Ok(code);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to create repair request.");
            return Result<string>.Fail("ثبت درخواست انجام نشد. لطفاً دوباره تلاش کنید.");
        }
    }

    public async Task<int> OfferToTechniciansAsync(
        int requestId,
        CancellationToken ct = default)
    {
        var request = await requests.GetAsync(requestId, ct)
            ?? throw new InvalidOperationException("درخواست پیدا نشد.");

        var now = DateTime.UtcNow;
        var selected = await technicians.GetAvailableForOfferAsync(
            now.Date,
            5,
            ct);

        foreach (var technician in selected)
        {
            request.Offers.Add(new TechnicianOffer
            {
                TechnicianId = technician.Id,
                Request = request,
                SentAt = now,
                ExpiresAt = now.AddMinutes(30),
                Status = OfferStatus.Pending
            });
        }

        request.Status = selected.Count > 0
            ? RepairRequestStatus.WaitingForAssignment
            : RepairRequestStatus.New;

        await uow.SaveChangesAsync(ct);
        return selected.Count;
    }

    // شماره موبایل را به یک قالب ثابت برای جستجو و Unique Index تبدیل می‌کند.
    private static string NormalizePhone(string value)
    {
        var phone = value.Trim()
            .Replace("۰", "0").Replace("۱", "1")
            .Replace("۲", "2").Replace("۳", "3")
            .Replace("۴", "4").Replace("۵", "5")
            .Replace("۶", "6").Replace("۷", "7")
            .Replace("۸", "8").Replace("۹", "9");

        if (phone.StartsWith("+98", StringComparison.Ordinal))
            phone = "0" + phone[3..];
        else if (phone.StartsWith("0098", StringComparison.Ordinal))
            phone = "0" + phone[4..];

        return phone;
    }

    private static bool IsValidIranianMobile(string phone)
        => phone.Length == 11 &&
           phone[0] == '0' &&
           phone[1] == '9' &&
           phone.All(char.IsDigit);

    private static string CreateTrackingCode()
        => $"ESF-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid():N}"[..24]
            .ToUpperInvariant();
}

// ================================================================
// Entityهای Domain
// ================================================================
// این کلاس‌ها هویت و داده اصلی کسب‌وکار را تعریف می‌کنند.
// نکته مهم: رمز عبور داخل Domain و جدول Technician نگهداری نمی‌شود.
// احراز هویت توسط ASP.NET Core Identity انجام می‌شود.

using RefrigeratorRepair.Domain.Enums;

namespace RefrigeratorRepair.Domain.Entities;

// پروفایل مدیریتی جدا از Identity.
// رمز عبور اینجا نیست؛ PasswordHash فقط در AspNetUsers نگهداری می‌شود.
public class AdminProfile
{
    public int Id { get; set; }
    public string UserId { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

// ---------------------------------------------------------------
// مشتری
// ---------------------------------------------------------------
public class Customer
{
    public int Id { get; set; }

    // اتصال اختیاری مشتری به Identity؛ سفارش بدون حساب هم همچنان مجاز است.
    public string? UserId { get; set; }
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";

    // در این پروژه شماره موبایل شناسه عملیاتی مشتری است و Index می‌شود.
    public string PhoneNumber { get; set; } = "";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime LastOrderAt { get; set; } = DateTime.UtcNow;

    public ICollection<RepairRequest> Requests { get; set; } = new List<RepairRequest>();
}

// ---------------------------------------------------------------
// تکنسین
// ---------------------------------------------------------------
// این جدول «پروفایل اصلی» تکنسین است؛ حتی قبل از تأیید مدیر.
// بنابراین دیگر نیازی به TechnicianRegistration نداریم.
public class Technician
{
    public int Id { get; set; }

    // اتصال پروفایل عملیاتی به AspNetUsers.
    public string UserId { get; set; } = "";

    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string NationalId { get; set; } = "";
    public string PhoneNumber { get; set; } = "";
    public string Address { get; set; } = "";
    public int ExperienceYears { get; set; }
    public string Specialization { get; set; } = "تعمیر یخچال";
    public string? ProfilePhotoPath { get; set; }

    // PendingApproval یعنی اطلاعات ثبت شده ولی هنوز مدیر تأیید نکرده است.
    public TechnicianAccountStatus AccountStatus { get; set; } = TechnicianAccountStatus.PendingApproval;

    // وضعیت کاری تکنسین؛ مدیر و خود تکنسین می‌توانند آن را تغییر دهند.
    public TechnicianAvailability Availability { get; set; } = TechnicianAvailability.PendingApproval;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // توجه: WalletBalance عمداً حذف شده است.
    // موجودی واقعی از مجموع WalletTransactions محاسبه می‌شود.

    public ICollection<RepairJob> Jobs { get; set; } = new List<RepairJob>();
    public ICollection<TechnicianOffer> Offers { get; set; } = new List<TechnicianOffer>();
    public ICollection<TechnicianDocument> Documents { get; set; } = new List<TechnicianDocument>();
    public ICollection<WalletTransaction> WalletTransactions { get; set; } = new List<WalletTransaction>();
    public ICollection<PaymentTransaction> PaymentTransactions { get; set; } = new List<PaymentTransaction>();
}

// ---------------------------------------------------------------
// درخواست تعمیر مشتری
// ---------------------------------------------------------------
public class RepairRequest
{
    public int Id { get; set; }
    public string TrackingCode { get; set; } = "";

    public int CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;

    // خدمت انتخاب‌شده مستقیماً به ServiceCatalog وصل می‌شود؛
    // بنابراین UI و دیتابیس دیگر از یک لیست ثابت و جداگانه استفاده نمی‌کنند.
    public int? ServiceCatalogId { get; set; }
    public ServiceCatalog? ServiceCatalog { get; set; }

    // این دو فیلد جزئیات دستگاه را از شرح آزاد مشکل جدا می‌کنند.
    public string? DeviceBrand { get; set; }
    public string? DeviceType { get; set; }

    // تاریخ و بازه زمانی پیشنهادی مشتری برای حضور تکنسین.
    // زمان نهایی بعداً با هماهنگی عملیات مشخص می‌شود.
    public DateTime? PreferredVisitDate { get; set; }
    public string? PreferredVisitWindow { get; set; }

    public int? AssignedTechnicianId { get; set; }
    public Technician? AssignedTechnician { get; set; }

    public string ProblemDescription { get; set; } = "";
    public string Address { get; set; } = "";
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? AssignedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public RepairRequestStatus Status { get; set; } = RepairRequestStatus.New;

    public RepairJob? RepairJob { get; set; }
    public ICollection<TechnicianOffer> Offers { get; set; } = new List<TechnicianOffer>();
}

// ---------------------------------------------------------------
// پرونده اجرایی تعمیر
// ---------------------------------------------------------------
public class RepairJob
{
    public int Id { get; set; }
    public int RepairRequestId { get; set; }
    public RepairRequest Request { get; set; } = null!;

    public int TechnicianId { get; set; }
    public Technician Technician { get; set; } = null!;

    public DateTime? RepairDate { get; set; }
    public string? ServiceDescription { get; set; }
    public string? TechnicianDiagnosis { get; set; }
    public decimal TravelCost { get; set; }
    public decimal LaborCost { get; set; }
    public decimal CustomerTotal { get; set; }
    public decimal PartsCost { get; set; }
    public decimal NetProfitBase { get; set; }
    public decimal CommissionAmount { get; set; }
    public bool ReportSubmitted { get; set; }

    public ICollection<RepairPart> Parts { get; set; } = new List<RepairPart>();
}

// قطعات مصرفی تعمیر.
public class RepairPart
{
    public int Id { get; set; }
    public int RepairJobId { get; set; }
    public RepairJob RepairJob { get; set; } = null!;
    public string PartName { get; set; } = "";
    public int Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal TotalPrice => Quantity * UnitPrice;
}

// پیشنهاد یک درخواست به یک تکنسین.
public class TechnicianOffer
{
    public int Id { get; set; }
    public int RepairRequestId { get; set; }
    public RepairRequest Request { get; set; } = null!;
    public int TechnicianId { get; set; }
    public Technician Technician { get; set; } = null!;
    public DateTime SentAt { get; set; } = DateTime.UtcNow;
    public DateTime ExpiresAt { get; set; } = DateTime.UtcNow.AddMinutes(30);
    public OfferStatus Status { get; set; } = OfferStatus.Pending;
}

// ---------------------------------------------------------------
// مدارک تکنسین
// ---------------------------------------------------------------
// اطلاعات اصلی تکنسین در Technician است؛ مدارک متعدد همچنان در جدول جدا می‌مانند.
// دلیل: یک تکنسین می‌تواند چند مدرک داشته باشد و هر مدرک نوع و فایل مستقل دارد.
public class TechnicianDocument
{
    public int Id { get; set; }
    public int TechnicianId { get; set; }
    public Technician Technician { get; set; } = null!;

    public string DocumentType { get; set; } = "";
    public string FilePath { get; set; } = "";
    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;
}

// دفتر حسابداری کیف پول.
public class WalletTransaction
{
    public int Id { get; set; }
    public int TechnicianId { get; set; }
    public Technician Technician { get; set; } = null!;

    public WalletTransactionType Type { get; set; }

    // مبلغ مثبت = افزایش موجودی، مبلغ منفی = کاهش موجودی.
    public decimal Amount { get; set; }

    // Snapshot موجودی بعد از تراکنش؛ برای Audit مفید است.
    public decimal BalanceAfter { get; set; }

    public string Description { get; set; } = "";
    public int? RepairJobId { get; set; }

    // برای شارژ درگاه، تراکنش واقعی کیف پول به پرداخت موفق متصل می‌شود.
    public int? PaymentTransactionId { get; set; }
    public PaymentTransaction? PaymentTransaction { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

// ثبت تلاش پرداخت از درگاه.
public class PaymentTransaction
{
    public int Id { get; set; }
    public int TechnicianId { get; set; }
    public Technician Technician { get; set; } = null!;

    public decimal Amount { get; set; }
    public string? Authority { get; set; } = null;
    public string? ReferenceId { get; set; }
    public PaymentTransactionStatus Status { get; set; } = PaymentTransactionStatus.Pending;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? VerifiedAt { get; set; }

    public ICollection<WalletTransaction> WalletTransactions { get; set; } = new List<WalletTransaction>();
}

// خدمت قابل نمایش در سایت.
public class ServiceCatalog
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string ShortDescription { get; set; } = "";
    public bool IsActive { get; set; } = true;
}

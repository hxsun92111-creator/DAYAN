// Enumهای اصلی Domain. هر Enum مجموعه‌ای محدود و مشخص از وضعیت‌های کسب‌وکار را تعریف می‌کند.
namespace RefrigeratorRepair.Domain.Enums;

// چرخه عمر درخواست مشتری.
public enum RepairRequestStatus
{
    New,
    WaitingForAssignment,
    Assigned,
    TechnicianOnTheWay,
    InProgress,
    Completed,
    Cancelled
}

// وضعیت کاری تکنسین؛ این وضعیت با وضعیت حساب تکنسین فرق دارد.
public enum TechnicianAvailability
{
    Available,
    Busy,
    TemporarilyUnavailable,
    PendingApproval,
    Suspended
}

// وضعیت حساب تکنسین از دید مدیر.
public enum TechnicianAccountStatus
{
    PendingApproval,
    Active,
    Suspended,
    Rejected
}

// وضعیت پیشنهاد یک سفارش برای تکنسین.
public enum OfferStatus
{
    Pending,
    Accepted,
    Declined,
    Expired
}

// انواع تراکنش دفتر حسابداری کیف پول.
public enum WalletTransactionType
{
    TopUp,
    CommissionDebit,
    Refund,
    Adjustment
}

// وضعیت پرداخت درگاه.
public enum PaymentTransactionStatus
{
    Pending,
    Verified,
    Failed
}

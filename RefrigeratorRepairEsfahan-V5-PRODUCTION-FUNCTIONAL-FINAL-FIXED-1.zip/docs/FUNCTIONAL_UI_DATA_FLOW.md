# تطبیق UI با کد و دیتابیس

## اصل طراحی
هیچ دکمه عملیاتی در رابط مشتری صرفاً نمایشی نیست. لینک‌ها به Razor Page واقعی می‌روند و فرم ثبت سفارش با POST واقعی به Application Service ارسال می‌شود.

## مسیر ثبت سفارش
1. `Services/Index.cshtml` انتخاب خدمت، دستگاه، مشتری، زمان و موقعیت را می‌گیرد.
2. `Services/Index.cshtml.cs` لیست خدمت را از `ServiceCatalog` می‌خواند.
3. `CreateRepairRequestDto` داده‌های فرم را با DataAnnotation اعتبارسنجی می‌کند.
4. `RepairRequestService` در سمت سرور دوباره فعال بودن `ServiceCatalogId` را بررسی می‌کند.
5. `RepairRequest` با FK به `ServiceCatalog` و `Customer` ذخیره می‌شود.
6. `OfferToTechniciansAsync` پیشنهاد را به تکنسین‌های واجد شرایط می‌فرستد.
7. `MyOrders` با TrackingCode + Phone سفارش را از دیتابیس می‌خواند و Timeline را از `RepairRequestStatus` می‌سازد.

## نگاشت UI به جدول
- خدمت → `RepairRequest.ServiceCatalogId` → `Services.Id`
- برند → `RepairRequest.DeviceBrand`
- نوع دستگاه → `RepairRequest.DeviceType`
- مشکل → `RepairRequest.ProblemDescription`
- تاریخ پیشنهادی → `RepairRequest.PreferredVisitDate`
- بازه حضور → `RepairRequest.PreferredVisitWindow`
- آدرس → `RepairRequest.Address`
- نقطه نقشه → `RepairRequest.Latitude/Longitude`
- مشتری → `RepairRequest.CustomerId` → `Customers.Id`

## سازگاری دیتابیس قدیمی
`SchemaUpgrade` در Development فقط ستون‌های جدید را به‌صورت idempotent اضافه می‌کند و سفارش‌های قدیمی را که با `[نام خدمت]` شروع شده‌اند، تا حد امکان به `ServiceCatalog` متصل می‌کند.

## نکته امنیتی
JavaScript فقط برای تجربه کاربری است. ID خدمت، اعتبار خدمت، شماره موبایل و سایر داده‌های مهم در سرور دوباره بررسی می‌شوند.

## چیزهایی که عمداً وارد Mockup عملیاتی نشده‌اند
پروفایل مشتری با اطلاعات شخصی در Mockup گرافیکی قابل طراحی است، اما پروژه فعلی برای مشتری حساب Identity ندارد؛ بنابراین بدون ساخت احراز هویت مشتری، آن صفحه نباید وانمود کند که اطلاعات واقعی مشتری را نشان می‌دهد. منوی عملیاتی فقط مسیرهایی را نشان می‌دهد که Backend واقعی دارند.

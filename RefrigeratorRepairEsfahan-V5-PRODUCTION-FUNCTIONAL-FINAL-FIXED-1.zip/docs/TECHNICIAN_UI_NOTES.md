# راهنمای پنل تکنسین

این نسخه رابط پنل تکنسین را بر اساس موکاپ موبایلی طراحی کرده است.

## ساختار
- `Pages/Shared/_Layout.cshtml`: هدر موبایل، منوی کشویی و Sidebar تکنسین.
- `Pages/Technician/Index.cshtml`: داشبورد و آمار واقعی تکنسین.
- `Pages/Technician/Offers/Index.cshtml`: درخواست‌های من و پذیرش سفارش.
- `Pages/Technician/Orders/Details.cshtml`: اطلاعات مشتری و ثبت گزارش تعمیر.
- `Pages/Technician/History/Index.cshtml`: سوابق تعمیرات.
- `Pages/Technician/Status/Index.cshtml`: وضعیت کاری.
- `Pages/Technician/Profile/Index.cshtml`: اطلاعات شخصی و کاری.
- `Pages/Technician/Location/Index.cshtml`: موقعیت آخرین سفارش فعال.
- `Pages/Technician/Wallet/Index.cshtml`: کیف پول و تراکنش‌ها.

## نکات فنی
- هیچ پکیج NuGet جدیدی برای UI اضافه نشده است.
- منوی موبایل با JavaScript ساده و بدون کتابخانه جدید باز و بسته می‌شود.
- داده‌های داشبورد و پروفایل از Entityهای موجود پروژه خوانده می‌شوند.
- موقعیت سفارش از `Latitude` و `Longitude` موجود در `RepairRequest` گرفته می‌شود؛ لینک نقشه همچنان OpenStreetMap است.
- CSP پروژه حفظ شده و برای نمایش نقشه از iframe خارجی استفاده نشده است.
- کنترل دسترسی پوشه `/Technician` همان Policy فعلی `TechnicianOnly` باقی مانده است.

# راه‌اندازی Production

## 1) دیتابیس

Connection String را در Environment/Secret قرار دهید:

`ConnectionStrings__DefaultConnection`

برنامه در Startup `Database.MigrateAsync()` را اجرا می‌کند و Migration پایه MySQL را اعمال می‌کند.
قبل از Production از دیتابیس Backup بگیرید.

## 2) درگاه واقعی

درگاه Production پروژه با ZarinPal پیاده‌سازی شده است.

تنظیمات زیر را در Secret/Environment قرار دهید:

- `Payment__MerchantId`
- `Payment__PublicBaseUrl` (مثلاً `https://repair.example.ir`)

API و StartPay در `appsettings.json` قرار گرفته‌اند و MerchantId هرگز نباید در Git ذخیره شود.

در Development همچنان Fake Gateway استفاده می‌شود تا بدون حساب درگاه بتوان پروژه را تست کرد.
در Production فقط `ZarinPalGateway` ثبت می‌شود و پرداخت موفق فقط بعد از Verify واقعی درگاه به Ledger کیف پول اضافه می‌شود.

## 3) ترتیب جریان پرداخت

1. PaymentTransaction با وضعیت Pending ساخته می‌شود.
2. درخواست پرداخت به درگاه ارسال می‌شود.
3. Authority در PaymentTransaction ذخیره می‌شود.
4. کاربر به صفحه درگاه هدایت می‌شود.
5. Callback فقط در صورت Status=OK وارد Verify می‌شود.
6. Verify با MerchantId و Amount واقعی انجام می‌شود.
7. ReferenceId فقط از پاسخ Verify پذیرفته می‌شود.
8. PaymentTransaction به Verified تغییر می‌کند.
9. WalletTransaction از نوع TopUp داخل Transaction دیتابیس ثبت می‌شود.
10. Callback تکراری به دلیل وضعیت Verified دوباره کیف پول را شارژ نمی‌کند.

## 4) UI/Backend

- داشبورد مدیر: آمار، نمودار، نقشه و جدول از دیتابیس.
- گزارش تکنسین: RepairJob و WalletTransaction واقعی.
- Settings تکنسین: تغییر رمز با Identity و لینک وضعیت کاری واقعی.
- پروفایل مشتری: Customer متصل به AspNetUsers و سفارش‌های واقعی.
- Bottom Navigation موبایل: لینک‌های واقعی Razor Page.
- ثبت سفارش: ServiceCatalog → RepairRequest → TechnicianOffer → RepairJob.

# یادداشت دیتابیس قبل از Production

این نسخه برای Development با `EnsureCreated` و `SchemaUpgrade` سازگار شده است تا دیتابیس‌های قبلی پروژه نیز ستون‌های جدید سفارش را بگیرند.

برای Production بهتر است مدیریت Schema با EF Core Migrations انجام شود و `EnsureCreated` استفاده نشود. دلیل آن این است که Migration تاریخچه تغییرات دیتابیس را ثبت می‌کند و برای محیط واقعی قابل کنترل‌تر است.

فیلدهای جدید `RepairRequests`:
- `ServiceCatalogId` (FK nullable به `Services.Id`)
- `DeviceBrand`
- `DeviceType`
- `PreferredVisitDate`
- `PreferredVisitWindow`

اگر دیتابیس Production از نسخه قبلی ساخته شده است، قبل از Deploy نهایی یک Migration رسمی بسازید یا معادل SQL همین تغییرات را با DBA اجرا کنید.

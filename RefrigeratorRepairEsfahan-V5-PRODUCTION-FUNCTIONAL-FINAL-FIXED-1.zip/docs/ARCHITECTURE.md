# معماری و مدل داده

## لایه‌ها

`Web -> Application -> Domain`

`Infrastructure -> Application + Domain`

Web فقط HTTP/UI را مدیریت می‌کند. Application منطق Use Case را دارد. Domain Entity/Enumها را نگه می‌دارد. Infrastructure EF Core، Identity، Repository و Payment Gateway را پیاده‌سازی می‌کند.

## جدول‌ها و ارتباط‌ها

- `AspNetUsers` / `AspNetRoles` / جداول Identity: احراز هویت و نقش‌ها.
- `Customers`: پروفایل مشتری؛ `UserId` اختیاری و Unique برای حساب مشتری.
- `Technicians`: پروفایل عملیاتی تکنسین؛ `UserId` Unique به Identity متصل است.
- `AdminProfiles`: پروفایل مدیر.
- `ServiceCatalogs`: خدمات فعال سایت.
- `RepairRequests`: سفارش مشتری؛ FK به Customer، ServiceCatalog و Technician.
- `TechnicianOffers`: N پیشنهاد برای هر سفارش و تکنسین.
- `RepairJobs`: پرونده اجرایی تعمیر؛ رابطه 1 به 1 با RepairRequest و N به 1 با Technician.
- `RepairParts`: قطعات مصرفی؛ N به 1 با RepairJob.
- `TechnicianDocuments`: مدارک؛ N به 1 با Technician.
- `PaymentTransactions`: تلاش/پرداخت درگاه؛ N به 1 با Technician.
- `WalletTransactions`: دفتر حسابداری؛ N به 1 با Technician و در صورت شارژ به PaymentTransaction متصل است.

## جریان کامل مشتری تا تکنسین

`ServiceCatalog -> RepairRequest -> TechnicianOffer -> RepairJob -> RepairPart/WalletTransaction -> History`

UI فقط داده را جمع می‌کند؛ اعتبارسنجی اصلی در Application و مالکیت عملیات در Backend انجام می‌شود.
